from display import new_picture, set_pixel, draw_sprite, fill_box, picture_to_lines   # pixel pictures (display.py)
from display import paint, pad_right, center_line, visible_length, cut     # colours and lining up text (display.py)

# =====================================================================
#  FILE 4 of 11:  ART.PY  -  EVERY DRAWING IN THE GAME
#
#  WHAT THIS FILE DOES
#   It holds the drawings (pawn, bomb, extra life, crowns, knights,
#   king, arrows, coins ...), the big pixel letters used for titles,
#   the words written across the river, and the boxes and buttons.
#   (The moving pictures - the animations - are in animations.py.)
#
#  HOW A DRAWING (A "SPRITE") WORKS
#   A sprite is a list of text rows. Each letter stands for a colour,
#   and '.' means see-through. For example, a tiny heart:
#
#       HEART = [                     HEART_COLORS = {
#           ".rr.rr.",                    'r': 196,      # red
#           "rrrrrrr",                }
#           ".rrrrr.",
#           "..rrr..",
#       ]
#
#   The COLOUR LIST (a dictionary) says which colour number each letter
#   means. The same drawing can be painted in different colours just by
#   using a different colour list - that's how the white and black pawns
#   share one drawing.
#
#   Two rows of a sprite fit in one line of the terminal (the pixel
#   trick, display.py PART 2), so a 16 x 16 sprite takes 16 characters
#   x 8 lines on the screen.
#
#  WHAT'S INSIDE (top to bottom)
#   1) colours of the board and colour lists
#   2) the drawings (pawn, bomb, life, hole, crowns, knights, king ...)
#   3) the king and the arrows, already turned (for Flip the King)
#   4) sprite tools        sprite_for_square, make_bigger, sprite_lines
#   5) pixel letters       FONT, text_width, draw_text, big_text
#   6) boxes and buttons   make_button, clock_box, text_box ...
#   7) HP crowns           crown_lines, coin_text
#   8) layout helpers      side_by_side, center_block, widest_line
#   9) guide pictures      tile, picture_story, guide_row
#  10) BANNERS             the words written across the river
# =====================================================================


# =====================================================================
#  1) COLOURS (256-colour numbers, see display.py PART 1)
# =====================================================================
LIGHT_SQUARE = 180          # light wood
DARK_SQUARE = 137           # dark wood
MY_BOMB_LIGHT = 174         # red tint = a bomb YOU hid (only you see it)
MY_BOMB_DARK = 131
MY_LIFE_LIGHT = 151         # green tint = an extra life YOU hid
MY_LIFE_DARK = 108
BURNT_LIGHT = 138           # a bomb that already exploded
BURNT_DARK = 95
LAST_MOVE_LIGHT = 222       # yellow = the last square flipped
LAST_MOVE_DARK = 178
FRAME_COLOR = 94            # wooden frame
RIVER_COLOR = 25            # the blue river
RIVER_WAVE = 32             # the lighter blue waves on it

# The colour lists for the drawings: which colour number each letter means
WHITE_PIECE = {'o': 241, 'w': 255, 'h': 231, 's': 250}
BLACK_PIECE = {'o': 232, 'w': 236, 'h': 243, 's': 234}
BOMB_COLORS = {'k': 236, 'h': 246, 'c': 248, 'f': 223, 'y': 226, 'r': 208}
BOMB_COLORS_SWAPPED = {'k': 236, 'h': 246, 'c': 248, 'f': 223, 'y': 208, 'r': 226}   # the spark flickers: yellow and orange swapped
LIFE_COLORS = {'o': 22, 'g': 34, 'h': 120, 'w': 231}
HOLE_COLORS = {'d': 95, 'D': 236}
GOLD_COLORS = {'y': 220, 'h': 229, 'd': 136, 'b': 94}
LOCK_COLORS = {'o': 250, 'g': 178, 'h': 222, 'k': 236, 'd': 136}
COIN_COLORS = {'y': 220, 'h': 229, 'd': 136}
CROWN_PLAYER_ONE = {'w': 252, 'h': 231}     # white crowns
CROWN_PLAYER_TWO = {'w': 243, 'h': 249}     # dark crowns
CROWN_LOST = {'w': 235, 'h': 237}           # a crown you already lost

# Colour FADES for big titles: 7 colours each, one for each of the
# 7 dot rows of a letter (top row first)
GOLD = [230, 229, 228, 221, 220, 214, 208]
FIRE = [231, 229, 221, 214, 208, 202, 196]
ICE = [231, 195, 159, 123, 117, 81, 75]
MINT = [231, 194, 157, 120, 114, 78, 71]
BLOOD = [224, 217, 210, 203, 196, 160, 124]
STEEL = [255, 253, 251, 249, 247, 245, 243]
PURPLE = [231, 225, 219, 213, 177, 141, 99]


# =====================================================================
#  2) THE DRAWINGS
# =====================================================================

# THE PAWN (a face-down square) in 3 sizes
PAWN_16 = [
    "................",
    "................",
    "......oooo......",
    ".....ohwwso.....",
    ".....owwwso.....",
    "......osso......",
    ".....oooooo.....",
    "......owso......",
    "......owso......",
    ".....ohwwso.....",
    "....ohwwwwso....",
    "...ohwwwwwwso...",
    "..oooooooooooo..",
    "..ohwwwwwwwwso..",
    "..oooooooooooo..",
    "................",
]
PAWN_10 = [
    "..........",
    "...oooo...",
    "...ohso...",
    "...owso...",
    "....os....",
    "...ohso...",
    "..ohwwso..",
    ".ohwwwwso.",
    ".oooooooo.",
    "..........",
]
PAWN_6 = [
    "......",
    "..hw..",
    "..ws..",
    ".hwws.",
    ".oooo.",
    "......",
]

# THE BOMB (the main weapon) in 3 sizes
BOMB_16 = [
    "............y...",
    "..........y.ry..",
    "...........rr...",
    "..........fy.y..",
    ".........f......",
    "........f.......",
    "......cccc......",
    "....kkkkkkkk....",
    "...khhkkkkkkk...",
    "..khhkkkkkkkkk..",
    "..khkkkkkkkkkk..",
    "..kkkkkkkkkkkk..",
    "..kkkkkkkkkkkk..",
    "...kkkkkkkkkk...",
    "....kkkkkkkk....",
    "......kkkk......",
]
BOMB_10 = [
    ".......y..",
    "......ryr.",
    ".....f.y..",
    "....cc....",
    "...kkkk...",
    "..khkkkk..",
    ".khkkkkkk.",
    ".kkkkkkkk.",
    "..kkkkkk..",
    "...kkkk...",
]
BOMB_6 = [
    "....y.",
    "...f..",
    "..kk..",
    ".khkk.",
    ".kkkk.",
    "..kk..",
]

# THE EXTRA LIFE (a green circle with a plus) in 3 sizes
LIFE_16 = [
    "................",
    "................",
    ".....oooooo.....",
    "...ooggggggoo...",
    "..oghgwwwwgggo..",
    ".oghggwwwwggggo.",
    ".oggwwwwwwwwggo.",
    ".oggwwwwwwwwggo.",
    ".oggwwwwwwwwggo.",
    ".oggwwwwwwwwggo.",
    ".oggggwwwwggggo.",
    "..ogggwwwwgggo..",
    "...ooggggggoo...",
    ".....oooooo.....",
    "................",
    "................",
]
LIFE_10 = [
    "..........",
    "...oooo...",
    "..ohwwgo..",
    ".oggwwggo.",
    ".owwwwwwo.",
    ".owwwwwwo.",
    ".oggwwggo.",
    "..ogwwgo..",
    "...oooo...",
    "..........",
]
LIFE_6 = [
    ".gggg.",
    "ggwwgg",
    "gwwwwg",
    "gwwwwg",
    "ggwwgg",
    ".gggg.",
]

# EMPTY HOLE (a safe pawn that was flipped) in 3 sizes
HOLE_16 = [
    "................",
    "................",
    "................",
    "................",
    "................",
    "................",
    "................",
    "......dddd......",
    ".....dDDDDd.....",
    "......dddd......",
    "................",
    "................",
    "................",
    "................",
    "................",
    "................",
]
HOLE_10 = [
    "..........",
    "..........",
    "..........",
    "..........",
    "...dddd...",
    "..dDDDDd..",
    "...dddd...",
    "..........",
    "..........",
    "..........",
]
HOLE_6 = [
    "......",
    "......",
    "..dd..",
    ".dDDd.",
    "......",
    "......",
]

# HP CROWNS: Queen, King, Queen (the King in the middle = your last HP)
KING_ICON = [
    ".....h.....",
    "....hhh....",
    ".....w.....",
    "..wwwwwww..",
    ".whhwwwwww.",
    "..wwwwwww..",
    "...wwwww...",
    "..wwwwwww..",
    "...whwww...",
    "...wwwww...",
    "..wwwwwww..",
    ".wwwwwwwww.",
    "wwwwwwwwwww",
    "...........",
]
QUEEN_ICON = [
    "h....h....h",
    "w...www...w",
    "ww.wwwww.ww",
    ".wwwwwwwww.",
    "..whhwwww..",
    "...wwwww...",
    "..wwwwwww..",
    "...wwwww...",
    "...whwww...",
    "...wwwww...",
    "..wwwwwww..",
    ".wwwwwwwww.",
    "wwwwwwwwwww",
    "...........",
]

# KNIGHTS facing RIGHT (Racing Piece, Tick Tock)
KNIGHT_16_RIGHT = [
    "................",
    ".....o.oo.......",
    "....owowwo......",
    "...owwwwhwo.....",
    "..owwwwowhwo....",
    "..owwwwwwwhwo...",
    "..owwwwwwwwhwo..",
    "..owwwwoowwwwo..",
    "..owwwwo..ooo...",
    "...owwwwo.......",
    "...owwwwwo......",
    "..owwwwwwwo.....",
    "..oooooooooo....",
    "..owwwwwwwwo....",
    "..oooooooooo....",
    "................",
]
KNIGHT_8_RIGHT = [
    ".o.oo...",
    ".owwwo..",
    ".owwowo.",
    ".owwwwwo",
    ".owo.oo.",
    ".owwo...",
    "owwwwo..",
    "oooooo..",
]
# KNIGHT facing LEFT (on the Tick Tock bomb)
KNIGHT_8 = [
    "...oo.o.",
    "..owwwo.",
    ".owowwo.",
    "owwwwwo.",
    ".oo.owo.",
    "...owwo.",
    "..owwwwo",
    "..oooooo",
]

COIN_8 = [
    "..dddd..",
    ".dyyyyd.",
    "dhyyyyyd",
    "dhyddyyd",
    "dyyddyyd",
    "dyyyyyyd",
    ".dyyyyd.",
    "..dddd..",
]

LOCK_12 = [
    "....oooo....",
    "...oo..oo...",
    "..oo....oo..",
    "..o......o..",
    "..o......o..",
    ".gggggggggg.",
    ".ghhhhhhhhg.",
    ".gggggggggg.",
    ".ggggkkgggg.",
    ".ggggkkgggg.",
    ".gggggkgggg.",
    ".gggggggggg.",
    ".dddddddddd.",
    "............",
]

TROPHY_16 = [
    "................",
    "..yyyyyyyyyyyy..",
    "yy.yhhyyyyyyd.yy",
    "y..yhyyyyyyyd..y",
    "y..yhyyyyyyyd..y",
    ".y.yyyyyyyyyd.y.",
    "...yyyyyyyyyy...",
    "....yyyyyyyd....",
    ".....yyyyyd.....",
    "......yyyd......",
    ".......yd.......",
    ".......yd.......",
    ".....yyyyyd.....",
    "....bbbbbbbb....",
    "....bbbbbbbb....",
    "................",
]

LIGHTNING_12 = [
    "........yyy.",
    ".......yyy..",
    "......yyy...",
    ".....yyy....",
    "....yyyyyyy.",
    ".......yyy..",
    "......yyy...",
    ".....yyy....",
    "....yy......",
    "...y........",
]

# The colours of the 4 racing knights (Racing Piece)
KNIGHT_COLORS = [
    {'o': 52, 'w': 203, 'h': 217},     # 1 red
    {'o': 17, 'w': 75, 'h': 153},      # 2 blue
    {'o': 58, 'w': 220, 'h': 229},     # 3 yellow
    {'o': 22, 'w': 77, 'h': 157},      # 4 green
]
KING_COLORS = {'o': 94, 'w': 229, 'h': 231, 's': 178}    # the golden king (Flip the King)

# The round body of the big Tick Tock bomb (made 4 times bigger there)
BOMB_BODY_20 = [
    "........kkkk........",
    ".....kkkkkkkkkk.....",
    "....hhkkkkkkkkkkk...",
    "...hkkkkkkkkkkkkkk..",
    "..hkkkkkkkkkkkkkkkk.",
    "..hkkkkkkkkkkkkkkkk.",
    ".hkkkkkkkkkkkkkkkkkk",
    ".hkkkkkkkkkkkkkkkkkk",
    "kkkkkkkkkkkkkkkkkkkk",
    "kkkkkkkkkkkkkkkkkkkk",
    "kkkkkkkkkkkkkkkkkkkk",
    "kkkkkkkkkkkkkkkkkkkk",
    ".kkkkkkkkkkkkkkkkkkk",
    ".kkkkkkkkkkkkkkkkkkk",
    "..kkkkkkkkkkkkkkkkk.",
    "..kkkkkkkkkkkkkkkkk.",
    "...kkkkkkkkkkkkkkk..",
    "....kkkkkkkkkkkkk...",
    ".....kkkkkkkkkkk....",
    "........kkkk........",
]


# =====================================================================
#  3) THE KING AND THE ARROWS, ALREADY TURNED  (Flip the King)
#   Each turn is its own drawing, so the game never has to work out
#   how to turn a picture: it just picks the right drawing.
#   KING_0 stands up, KING_90 lies on its right side, KING_180 is upside
#   down ... The 45-degree ones are drawn twice as big already.
# =====================================================================
ARROW_UP = [
    ".....oo.....",
    "....owwo....",
    "...owwwwo...",
    "..owwwwwwo..",
    ".owwwwwwwwo.",
    "oooowwwwoooo",
    "...owwwwo...",
    "...owwwwo...",
    "...owwwwo...",
    "...owwwwo...",
    "...owwwwo...",
    "...oooooo...",
]
ARROW_RIGHT = [
    "......o.....",
    "......oo....",
    "......owo...",
    "ooooooowwo..",
    "owwwwwwwwwo.",
    "owwwwwwwwwwo",
    "owwwwwwwwwwo",
    "owwwwwwwwwo.",
    "ooooooowwo..",
    "......owo...",
    "......oo....",
    "......o.....",
]
ARROW_DOWN = [
    "...oooooo...",
    "...owwwwo...",
    "...owwwwo...",
    "...owwwwo...",
    "...owwwwo...",
    "...owwwwo...",
    "oooowwwwoooo",
    ".owwwwwwwwo.",
    "..owwwwwwo..",
    "...owwwwo...",
    "....owwo....",
    ".....oo.....",
]
ARROW_LEFT = [
    ".....o......",
    "....oo......",
    "...owo......",
    "..owwooooooo",
    ".owwwwwwwwwo",
    "owwwwwwwwwwo",
    "owwwwwwwwwwo",
    ".owwwwwwwwwo",
    "..owwooooooo",
    "...owo......",
    "....oo......",
    ".....o......",
]
KING_0 = [
    "........................",
    "........................",
    "...........oo...........",
    "...........ww...........",
    ".........oowwoo.........",
    ".........wwwwww.........",
    "...........ww...........",
    "...........ww...........",
    "........oooooooo........",
    "........ohwwwwso........",
    ".........ohwwso.........",
    ".........ohwwso.........",
    "........oooooooo........",
    ".........ohwwso.........",
    ".........ohwwso.........",
    ".........ohwwso.........",
    "........ohwwwwso........",
    "........ohwwwwso........",
    ".......ohwwwwwwso.......",
    ".......oooooooooo.......",
    "......ohwwwwwwwwso......",
    "......oooooooooooo......",
    "........................",
    "........................",
]
KING_90 = [
    "........................",
    "........................",
    "........................",
    "........................",
    "........................",
    "........................",
    "..oo....................",
    "..ohoo..................",
    "..owohoo...o..oo........",
    "..owowhhooooooho..wo....",
    "..owowwwhhhohhwo..wo....",
    "..owowwwwwwowwwowwwwwo..",
    "..owowwwwwwowwwowwwwwo..",
    "..owowwwsssosswo..wo....",
    "..owowssooooooso..wo....",
    "..owosoo...o..oo........",
    "..osoo..................",
    "..oo....................",
    "........................",
    "........................",
    "........................",
    "........................",
    "........................",
    "........................",
]
KING_180 = [
    "........................",
    "........................",
    "......oooooooooooo......",
    "......oswwwwwwwwho......",
    ".......oooooooooo.......",
    ".......oswwwwwwho.......",
    "........oswwwwho........",
    "........oswwwwho........",
    ".........oswwho.........",
    ".........oswwho.........",
    ".........oswwho.........",
    "........oooooooo........",
    ".........oswwho.........",
    ".........oswwho.........",
    "........oswwwwho........",
    "........oooooooo........",
    "...........ww...........",
    "...........ww...........",
    ".........wwwwww.........",
    ".........oowwoo.........",
    "...........ww...........",
    "...........oo...........",
    "........................",
    "........................",
]
KING_270 = [
    "........................",
    "........................",
    "........................",
    "........................",
    "........................",
    "........................",
    "....................oo..",
    "..................ooso..",
    "........oo..o...oosowo..",
    "....ow..osoooooosswowo..",
    "....ow..owssossswwwowo..",
    "..owwwwwowwwowwwwwwowo..",
    "..owwwwwowwwowwwwwwowo..",
    "....ow..owhhohhhwwwowo..",
    "....ow..ohoooooohhwowo..",
    "........oo..o...oohowo..",
    "..................ooho..",
    "....................oo..",
    "........................",
    "........................",
    "........................",
    "........................",
    "........................",
    "........................",
]
KING_45_BIG = [
    "................................................",
    "................................................",
    "................................................",
    "................................................",
    "................................................",
    "................................................",
    "................................................",
    "................................................",
    "................................................",
    "..............................oo....oo..........",
    ".............................wooo..wooo.........",
    "............................wwwooowwwoo.........",
    ".............................wwwowwwww..........",
    ".......................oo.....wwwwwww...........",
    "......................oooo.....wwwwwo...........",
    ".....................oooooo...wwwwwooo..........",
    "......................ohhooo.wwwwwwwooo.........",
    "......................ohhwooowwww.wwwoo.........",
    "..................o..ooowwwoooww...www..........",
    ".................oooooohhwwwooo.....w...........",
    "..................oooohhhwwwwooo................",
    "..................oooohhwwwwwwooo...............",
    ".................oooooowwwwwwwwooo..............",
    "................ooohhooowwwsswssooo.............",
    "............o..ooohhhwooowsssossooo.............",
    "........o..oooooohhhwwwooossoooooo..............",
    ".......oooooohhohhhwwwwwoooooo..o...............",
    "....o.ooohhohhhwhhwwwwwssoooo...................",
    "...oohooohhwhhwwwwwwwwsssoooo...................",
    "..oohhhooowwwwwwwwwwwsssoooooo..................",
    "..ooohwwooowwwwwwwwwsssooo..o...................",
    "...ooowwwooowwwwwwwwssooo.......................",
    "....ooowwwooowwwwwwwwooo........................",
    ".....ooowwwooowwwwwwsso.........................",
    "......ooowwwooowwwwssso.........................",
    ".......ooowwwooowwwssooo........................",
    "........ooowwwooowwwooo.........................",
    ".........ooowwwooowsso..........................",
    "..........ooowwwooosso..........................",
    "...........ooowwwoooooo.........................",
    "............ooowwwoooo..........................",
    ".............ooowwsoo...........................",
    "..............ooosss............................",
    "...............ooosoo...........................",
    "................oooo............................",
    ".................oo.............................",
    "................................................",
    "................................................",
]
KING_135_BIG = [
    "................................................",
    "................................................",
    ".................oo.............................",
    "................oooo............................",
    "...............ooohoo...........................",
    "..............ooohhh............................",
    ".............ooowwhoo...........................",
    "............ooowwwoooo..........................",
    "...........ooowwwoooooo.........................",
    "..........ooowwwooohho..........................",
    ".........ooowwwooowhho..........................",
    "........ooowwwooowwwooo.........................",
    ".......ooowwwooowwwhhooo........................",
    "......ooowwwooowwwwhhho.........................",
    ".....ooowwwooowwwwwwhho.........................",
    "....ooowwwooowwwwwwwwooo........................",
    "...ooowwwooowwwwwwwwhhooo.......................",
    "..oooswwooowwwwwwwwwhhhooo..o...................",
    "..oosssooowwwwwwwwwwwhhhoooooo..................",
    "...oosooosswsswwwwwwwwhhhoooo...................",
    "....o.ooossossswsswwwwwhhoooo...................",
    ".......oooooossossswwwwwoooooo..o...............",
    "........o..oooooossswwwooohhoooooo..............",
    "............o..ooossswooowhhhohhooo.............",
    "................ooossooowwwhhwhhooo.............",
    ".................oooooowwwwwwwwooo..............",
    "..................oooosswwwwwwooo...............",
    "..................oooossswwwwooo................",
    ".................oooooosswwwooo.....w...........",
    "..................o..ooowwwoooww...www..........",
    "......................osswooowwww.wwwoo.........",
    "......................ossooo.wwwwwwwooo.........",
    ".....................oooooo...wwwwwooo..........",
    "......................oooo.....wwwwwo...........",
    ".......................oo.....wwwwwww...........",
    ".............................wwwowwwww..........",
    "............................wwwooowwwoo.........",
    ".............................wooo..wooo.........",
    "..............................oo....oo..........",
    "................................................",
    "................................................",
    "................................................",
    "................................................",
    "................................................",
    "................................................",
    "................................................",
    "................................................",
    "................................................",
]
KING_225_BIG = [
    "................................................",
    "................................................",
    ".............................oo.................",
    "............................oooo................",
    "...........................oosooo...............",
    "............................sssooo..............",
    "...........................ooswwooo.............",
    "..........................oooowwwooo............",
    ".........................oooooowwwooo...........",
    "..........................ossooowwwooo..........",
    "..........................osswooowwwooo.........",
    ".........................ooowwwooowwwooo........",
    "........................ooosswwwooowwwooo.......",
    ".........................ossswwwwooowwwooo......",
    ".........................osswwwwwwooowwwooo.....",
    "........................ooowwwwwwwwooowwwooo....",
    ".......................ooosswwwwwwwwooowwwooo...",
    "...................o..ooossswwwwwwwwwooowwhooo..",
    "..................oooooossswwwwwwwwwwwooohhhoo..",
    "...................oooossswwwwwwwwhhwhhooohoo...",
    "...................oooosswwwwwhhwhhhohhooo.o....",
    "...............o..oooooowwwwwhhhohhoooooo.......",
    "..............oooooossooowwwhhhoooooo..o........",
    ".............ooossossswooowhhhooo..o............",
    ".............ooosswsswwwooohhooo................",
    "..............ooowwwwwwwwoooooo.................",
    "...............ooowwwwwwhhoooo..................",
    "................ooowwwwhhhoooo..................",
    "...........w.....ooowwwhhoooooo.................",
    "..........www...wwooowwwooo..o..................",
    ".........oowww.wwwwooowhho......................",
    ".........ooowwwwwww.ooohho......................",
    "..........ooowwwww...oooooo.....................",
    "...........owwwww.....oooo......................",
    "...........wwwwwww.....oo.......................",
    "..........wwwwwowww.............................",
    ".........oowwwooowww............................",
    ".........ooow..ooow.............................",
    "..........oo....oo..............................",
    "................................................",
    "................................................",
    "................................................",
    "................................................",
    "................................................",
    "................................................",
    "................................................",
    "................................................",
    "................................................",
]
KING_315_BIG = [
    "................................................",
    "................................................",
    "................................................",
    "................................................",
    "................................................",
    "................................................",
    "................................................",
    "................................................",
    "................................................",
    "..........oo....oo..............................",
    ".........ooow..ooow.............................",
    ".........oowwwooowww............................",
    "..........wwwwwowww.............................",
    "...........wwwwwww.....oo.......................",
    "...........owwwww.....oooo......................",
    "..........ooowwwww...oooooo.....................",
    ".........ooowwwwwww.ooosso......................",
    ".........oowww.wwwwooowsso......................",
    "..........www...wwooowwwooo..o..................",
    "...........w.....ooowwwssoooooo.................",
    "................ooowwwwsssoooo..................",
    "...............ooowwwwwwssoooo..................",
    "..............ooowwwwwwwwoooooo.................",
    ".............ooohhwhhwwwooossooo................",
    ".............ooohhohhhwooowsssooo..o............",
    "..............oooooohhooowwwsssoooooo..o........",
    "...............o..oooooowwwwwsssossoooooo.......",
    "...................oooohhwwwwwsswsssossooo.o....",
    "...................oooohhhwwwwwwwwsswssooosoo...",
    "..................oooooohhhwwwwwwwwwwwooosssoo..",
    "...................o..ooohhhwwwwwwwwwooowwsooo..",
    ".......................ooohhwwwwwwwwooowwwooo...",
    "........................ooowwwwwwwwooowwwooo....",
    ".........................ohhwwwwwwooowwwooo.....",
    ".........................ohhhwwwwooowwwooo......",
    "........................ooohhwwwooowwwooo.......",
    ".........................ooowwwooowwwooo........",
    "..........................ohhwooowwwooo.........",
    "..........................ohhooowwwooo..........",
    ".........................oooooowwwooo...........",
    "..........................oooowwwooo............",
    "...........................oohwwooo.............",
    "............................hhhooo..............",
    "...........................oohooo...............",
    "............................oooo................",
    ".............................oo.................",
    "................................................",
    "................................................",
]


# =====================================================================
#  4) SPRITE TOOLS
# =====================================================================
def sprite_for_square(name, square_pixels):
    # Picks the drawing that fits inside a board square
    #   name          = 'pawn', 'bomb', 'life' or 'hole'
    #   square_pixels = how big the square is (16, 12, 10, 8 or 6)
    if square_pixels >= 16:
        size = 16
    elif square_pixels >= 10:
        size = 10
    else:
        size = 6
    match name:
        case 'pawn':
            if size == 16:
                return PAWN_16
            elif size == 10:
                return PAWN_10
            else:
                return PAWN_6
        case 'bomb':
            if size == 16:
                return BOMB_16
            elif size == 10:
                return BOMB_10
            else:
                return BOMB_6
        case 'life':
            if size == 16:
                return LIFE_16
            elif size == 10:
                return LIFE_10
            else:
                return LIFE_6
        case 'hole':
            if size == 16:
                return HOLE_16
            elif size == 10:
                return HOLE_10
            else:
                return HOLE_6


def king_turned(degrees):
    # The big golden king of Flip the King, turned by 'degrees'
    # (0, 45, 90 ... 315). It just picks the right drawing (part 3 above).
    # The 45-degree drawings are already big; the others are made 2 times bigger.
    match degrees:
        case 45:
            return KING_45_BIG
        case 90:
            return make_bigger(KING_90, 2)
        case 135:
            return KING_135_BIG
        case 180:
            return make_bigger(KING_180, 2)
        case 225:
            return KING_225_BIG
        case 270:
            return make_bigger(KING_270, 2)
        case 315:
            return KING_315_BIG
        case _:
            return make_bigger(KING_0, 2)            # 0 (or 360): standing up


def lane_color(lane):
    # Racing Piece: the lanes take turns, light brown and dark brown
    if lane % 2 == 0:
        return 137
    else:
        return 130


def draw_finish_line(picture, left, right, top, bottom):
    # Racing Piece: a black-and-white checkered strip (each check is 2 x 2 pixels)
    for from_top in range(top, bottom):
        for from_left in range(left, right):
            if (from_left // 2 + from_top // 2) % 2 == 0:        # the checks take turns every 2 pixels
                set_pixel(picture, from_left, from_top, 231)     # white
            else:
                set_pixel(picture, from_left, from_top, 232)     # black


def make_bigger(sprite, times):
    # Every letter becomes a 'times' x 'times' block, so the drawing grows.
    # make_bigger([".k"], 2) -> ["..kk", "..kk"]
    bigger = []                                 # the bigger drawing
    for row in sprite:                          # every row of the drawing:
        wide_row = ""                           # the row made wider
        for letter in row:                      # every letter in the row:
            wide_row = wide_row + letter * times    # "k" * 2 = "kk"
        for repeat in range(times):             # add the wide row 'times' times
            bigger.append(wide_row)
    return bigger


def sprite_lines(sprite, colors):
    # A drawing straight to text lines, ready to print
    height = len(sprite)                # how tall the drawing is
    if height % 2 == 1:                 # an odd number of rows?
        height = height + 1             # make it even: 2 pixels make 1 line
    picture = new_picture(len(sprite[0]), height)     # an empty picture just big enough
    draw_sprite(picture, sprite, 0, 0, colors)        # draw the drawing in it
    return picture_to_lines(picture)                  # turn it into text lines


# =====================================================================
#  5) PIXEL LETTERS (5 x 7) used for every big title
#   Every letter is 5 dots wide and 7 dots tall. '#' = a dot.
# =====================================================================
FONT = {
    'A': [".###.", "#...#", "#...#", "#####", "#...#", "#...#", "#...#"],
    'B': ["####.", "#...#", "#...#", "####.", "#...#", "#...#", "####."],
    'C': [".###.", "#...#", "#....", "#....", "#....", "#...#", ".###."],
    'D': ["####.", "#...#", "#...#", "#...#", "#...#", "#...#", "####."],
    'E': ["#####", "#....", "#....", "####.", "#....", "#....", "#####"],
    'F': ["#####", "#....", "#....", "####.", "#....", "#....", "#...."],
    'G': [".###.", "#...#", "#....", "#.###", "#...#", "#...#", ".####"],
    'H': ["#...#", "#...#", "#...#", "#####", "#...#", "#...#", "#...#"],
    'I': [".###.", "..#..", "..#..", "..#..", "..#..", "..#..", ".###."],
    'J': ["..###", "...#.", "...#.", "...#.", "#..#.", "#..#.", ".##.."],
    'K': ["#...#", "#..#.", "#.#..", "##...", "#.#..", "#..#.", "#...#"],
    'L': ["#....", "#....", "#....", "#....", "#....", "#....", "#####"],
    'M': ["#...#", "##.##", "#.#.#", "#.#.#", "#...#", "#...#", "#...#"],
    'N': ["#...#", "#...#", "##..#", "#.#.#", "#..##", "#...#", "#...#"],
    'O': [".###.", "#...#", "#...#", "#...#", "#...#", "#...#", ".###."],
    'P': ["####.", "#...#", "#...#", "####.", "#....", "#....", "#...."],
    'Q': [".###.", "#...#", "#...#", "#...#", "#.#.#", "#..#.", ".##.#"],
    'R': ["####.", "#...#", "#...#", "####.", "#.#..", "#..#.", "#...#"],
    'S': [".####", "#....", "#....", ".###.", "....#", "....#", "####."],
    'T': ["#####", "..#..", "..#..", "..#..", "..#..", "..#..", "..#.."],
    'U': ["#...#", "#...#", "#...#", "#...#", "#...#", "#...#", ".###."],
    'V': ["#...#", "#...#", "#...#", "#...#", "#...#", ".#.#.", "..#.."],
    'W': ["#...#", "#...#", "#...#", "#.#.#", "#.#.#", "#.#.#", ".#.#."],
    'X': ["#...#", "#...#", ".#.#.", "..#..", ".#.#.", "#...#", "#...#"],
    'Y': ["#...#", "#...#", ".#.#.", "..#..", "..#..", "..#..", "..#.."],
    'Z': ["#####", "....#", "...#.", "..#..", ".#...", "#....", "#####"],
    '0': [".###.", "#...#", "#..##", "#.#.#", "##..#", "#...#", ".###."],
    '1': ["..#..", ".##..", "..#..", "..#..", "..#..", "..#..", ".###."],
    '2': [".###.", "#...#", "....#", "...#.", "..#..", ".#...", "#####"],
    '3': ["####.", "....#", "....#", ".###.", "....#", "....#", "####."],
    '4': ["...#.", "..##.", ".#.#.", "#..#.", "#####", "...#.", "...#."],
    '5': ["#####", "#....", "####.", "....#", "....#", "#...#", ".###."],
    '6': ["..##.", ".#...", "#....", "####.", "#...#", "#...#", ".###."],
    '7': ["#####", "....#", "...#.", "..#..", ".#...", ".#...", ".#..."],
    '8': [".###.", "#...#", "#...#", ".###.", "#...#", "#...#", ".###."],
    '9': [".###.", "#...#", "#...#", ".####", "....#", "...#.", ".##.."],
    ' ': [".....", ".....", ".....", ".....", ".....", ".....", "....."],
    '!': ["..#..", "..#..", "..#..", "..#..", "..#..", ".....", "..#.."],
    '?': [".###.", "#...#", "....#", "...#.", "..#..", ".....", "..#.."],
    '-': [".....", ".....", ".....", "#####", ".....", ".....", "....."],
    '+': [".....", "..#..", "..#..", "#####", "..#..", "..#..", "....."],
    ':': [".....", "..#..", "..#..", ".....", "..#..", "..#..", "....."],
    '.': [".....", ".....", ".....", ".....", ".....", "..#..", "..#.."],
}


def text_width(text, size=1):
    # How many pixels wide the text will be.
    # Each letter is 5 dots + 1 dot of gap = 6 (times the size),
    # minus the gap after the last letter.
    if text == "":
        return 0
    else:
        return len(text) * 6 * size - size


def draw_text(picture, text, from_left, from_top, colors, size=1, shadow=None):
    # Writes big pixel letters into a picture.
    #   colors = ONE colour number (like 252), or a FADE of 7 colours (like GOLD)
    #   shadow = a colour for a shadow 1 pixel down-right (None = no shadow)
    if shadow != None:                                  # a shadow first ...
        draw_letters(picture, text, from_left + 1, from_top + 1, shadow, size)
    draw_letters(picture, text, from_left, from_top, colors, size)   # ... the letters on top


def draw_letters(picture, text, from_left, from_top, colors, size):
    # Draws the letters one after another, dot by dot.
    # Each dot is a small square of 'size' x 'size' pixels.
    for letter in text.upper():                         # every letter (as a CAPITAL)
        if letter in FONT:
            dots = FONT[letter]                         # the 7 rows of this letter
        else:
            dots = FONT[' ']                            # a letter we don't have: a space
        for dot_row in range(7):                        # the 7 rows of the letter
            # the colour of this row: one colour number, or row number 'dot_row' of the fade
            if type(colors) == list:
                color = colors[dot_row]
            else:
                color = colors
            for dot_column in range(5):                 # the 5 dots in this row
                if dots[dot_row][dot_column] == '#':    # a dot here? draw it:
                    dot_left = from_left + dot_column * size
                    dot_top = from_top + dot_row * size
                    fill_box(picture, dot_left, dot_top, size, size, color)
        from_left = from_left + 6 * size                # move right to the next letter


def big_text(text, colors, size=2, shadow=None):
    # A title on its own, as text lines ready to print
    width = text_width(text, size) + 1  # the text's width + 1 for the shadow
    height = 7 * size + 1               # the letters' height + 1 for the shadow
    if height % 2 == 1:
        height = height + 1             # make it even: 2 pixels make 1 line
    picture = new_picture(width, height)
    draw_text(picture, text, 0, 0, colors, size, shadow)
    return picture_to_lines(picture)


# =====================================================================
#  6) BUTTONS, BOXES, THE CHESS-CLOCK TYPING BOX
# =====================================================================
def make_button(label, width=24, border=223, enabled=True):
    # A double-line box with a dark shadow:    ╔══════╗
    #                                          ║ [1]  ║█
    #                                          ╚══════╝█
    if enabled == True:
        text = 231                      # white words
        shadow = 238                    # dark grey shadow
    else:                               # a locked button is all grey
        border = 240
        text = 243
        shadow = 236
    label_text = pad_right("  " + label, width)       # the label, with spaces up to the box width
    line_1 = paint("╔" + "═" * width + "╗", border) + " "
    line_2 = paint("║", border) + paint(label_text, text, bold=enabled) + paint("║", border) + paint("█", shadow)
    line_3 = paint("╚" + "═" * width + "╝", border) + paint("█", shadow)
    line_4 = " " + paint("▀" * (width + 2), shadow)
    return [line_1, line_2, line_3, line_4]


# You type from the 4th character of the clock's typing line
CLOCK_BOX_TYPING_COLUMN = 4


def clock_box(content="", width=26, color=223, content_color=231):
    # Looks like a chess clock: two buttons on top, a display below.
    # Typing happens on line 3.
    line_1 = "   " + paint("▄▄▄▄", 137) + " " * (width - 10) + paint("▄▄▄▄", 137) + "   "   # the 2 buttons
    line_2 = paint("╔" + "═" * width + "╗", color)
    line_3 = paint("║", color) + paint(" : ", 222, bold=True) + paint(pad_right(content, width - 3), content_color, bold=True) + paint("║", color)
    line_4 = paint("╚" + "═" * width + "╝", color)
    return [line_1, line_2, line_3, line_4]


# The thin rounded boxes:   ╭── TITLE ──╮   box_top
#                           │ some text │   box_row
#                           ├───────────┤   box_middle
#                           ╰───────────╯   box_bottom
def box_top(width, title="", color=244):
    return line_with_title("╭", "╮", width, title, color)


def box_middle(width, title="", color=244):
    return line_with_title("├", "┤", width, title, color)


def line_with_title(left_corner, right_corner, width, title, color):
    # A line like   ╭──── TITLE ────╮   with the title in the middle
    inside = width - 2                              # the room between the two corners
    if title == "":
        return paint(left_corner + "─" * inside + right_corner, color)
    label = " " + title + " "
    dashes_left = (inside - len(label)) // 2
    dashes_right = inside - len(label) - dashes_left
    left_part = paint(left_corner + "─" * dashes_left, color)
    middle_part = paint(label, 230, bold=True)
    right_part = paint("─" * dashes_right + right_corner, color)
    return left_part + middle_part + right_part


def box_row(text, width, color=244):
    # One line inside a box:   │ some text      │
    return paint("│", color) + " " + pad_right(text, width - 4) + " " + paint("│", color)


def box_bottom(width, color=244):
    # The bottom of a box:   ╰─────────╯
    return paint("╰" + "─" * (width - 2) + "╯", color)


def text_box(title, rows, width, color=244):
    # A box with a title and some lines of text.
    #   rows = a list of [text, colour] pairs
    lines = []
    lines.append(box_top(width, title, color))
    for row in rows:                                # every line of text:
        text = row[0]                               # [0] = the text
        text_color = row[1]                         # [1] = its colour
        short_text = cut(text, width - 4)           # shortened if it's too long
        lines.append(box_row(paint(short_text, text_color), width, color))
    lines.append(box_bottom(width, color))
    return lines


# =====================================================================
#  7) HP AS CROWNS:  3 HP = Queen King Queen,  2 HP = Queen King,  1 HP = King
#   Lost crowns stay as dark shadows so you can see what's gone.
# =====================================================================
def crown_lines(health, is_player_one):
    if is_player_one == True:
        colors = CROWN_PLAYER_ONE        # white crowns
    else:
        colors = CROWN_PLAYER_TWO        # dark crowns
    left_queen = CROWN_LOST              # start with all three dark ...
    king = CROWN_LOST
    right_queen = CROWN_LOST
    if health >= 1:                      # ... then light them up:
        king = colors                    # 1 HP or more: the king
    if health >= 2:
        left_queen = colors              # 2 HP or more: the left queen too
    if health >= 3:
        right_queen = colors             # 3 HP: the right queen too
    picture = new_picture(37, 14)                         # room for 3 crowns side by side
    draw_sprite(picture, QUEEN_ICON, 0, 0, left_queen)    # queen at the left
    draw_sprite(picture, KING_ICON, 13, 0, king)          # king in the middle
    draw_sprite(picture, QUEEN_ICON, 26, 0, right_queen)  # queen at the right
    return picture_to_lines(picture)


def coin_text(amount):
    # ($) 350 COINS
    return paint("(", 136) + paint("$", 220, bold=True) + paint(")", 136) + paint(" " + str(amount) + " COINS", 220, bold=True)


# =====================================================================
#  8) LAYOUT HELPERS
#   A "block" is a list of text lines (a picture, a box, a title ...).
# =====================================================================
def side_by_side(blocks, gap=2):
    # Puts several blocks next to each other, left to right,
    # with 'gap' spaces between them.
    # STEP 1: how tall is the tallest block?
    tallest = 0
    for block in blocks:
        if len(block) > tallest:
            tallest = len(block)
    # STEP 2: build the result one line at a time
    result = []
    for line_number in range(tallest):              # every line, top to bottom:
        line = ""
        for index in range(len(blocks)):            # every block, left to right:
            block = blocks[index]
            if line_number < len(block):            # does this block have this line?
                piece = block[line_number]
            else:
                piece = ""                          # no: a shorter block is empty below
            piece = pad_right(piece, widest_line(block))   # fill it up to the block's width
            if index > 0:                           # not the first block:
                line = line + " " * gap             # put the gap in front
            line = line + piece
        result.append(line)
    return result


def center_block(lines, width):
    # Centres every line of a block inside the given width
    centered = []
    for line in lines:
        centered.append(center_line(line, width))
    return centered


def widest_line(lines):
    # How wide the widest line looks on the screen
    widest = 0
    for line in lines:
        if visible_length(line) > widest:
            widest = visible_length(line)
    return widest


def empty_lines(how_many):
    # A block of empty lines (used to push another block down)
    lines = []
    for number in range(how_many):
        lines.append("")
    return lines


# =====================================================================
#  9) PICTURE PIECES FOR THE GUIDES
# =====================================================================
def tile(sprite, colors, square_color=LIGHT_SQUARE, size=16):
    # One chess square with a drawing on it, e.g. tile(BOMB_16, BOMB_COLORS)
    picture = new_picture(size, size, square_color)   # a square filled with its colour
    left = (size - len(sprite[0])) // 2               # the drawing in the middle
    top = (size - len(sprite)) // 2
    draw_sprite(picture, sprite, left, top, colors)
    return picture_to_lines(picture)


def arrow_between(height_in_lines):
    # A small yellow arrow, pushed down so it sits between two pictures
    arrow = sprite_lines(ARROW_RIGHT, {'o': 94, 'w': 220})
    lines_above = (height_in_lines - len(arrow)) // 2
    return empty_lines(lines_above) + arrow


def picture_story(pieces, gap=2):
    # Puts pictures in a row with arrows between them: A -> B -> C
    blocks = []
    for index in range(len(pieces)):                  # every picture:
        if index > 0:                                 # not the first one? an arrow before it
            blocks.append(arrow_between(len(pieces[index])))
        blocks.append(pieces[index])
    return side_by_side(blocks, gap)


def guide_row(picture_lines, words, color=231, picture_width=60):
    # A picture on the left, an explanation on the right
    lines_above = len(picture_lines) // 2 - len(words) // 2    # so the words sit in the middle
    if lines_above < 0:
        lines_above = 0
    words_block = empty_lines(lines_above)
    for word_line in words:
        words_block.append(paint(word_line, color, bold=True))
    return side_by_side([center_block(picture_lines, picture_width), words_block], 3)


# =====================================================================
#  10) BANNERS: the words written across the river
#   Every banner is just a DRAWING made of block characters
#   (█ = full block, ▀ = top half, ▄ = bottom half), 3 lines tall.
#   The board prints it in gold on top of the blue river.
#   BANNERS["BOOM!"] = the 3 lines of the BOOM! banner.
# =====================================================================
BANNERS = {

    "ENTER 1ST BOMB": [
        "█▀▀ █▀▄ ▀█▀ █▀▀ █▀▄    ▄█  ▄▀▀ ▀█▀    █▀▄ ▄▀▄ █▄█ █▀▄",
        "█▀  █ █  █  █▀  █▀▄     █   ▀▄  █     █▀▄ █ █ █▀█ █▀▄",
        "▀▀▀ ▀ ▀  ▀  ▀▀▀ ▀ ▀    ▀▀▀ ▀▀   ▀     ▀▀   ▀  ▀ ▀ ▀▀ ",
    ],

    "ENTER 2ND BOMB": [
        "█▀▀ █▀▄ ▀█▀ █▀▀ █▀▄    ▀▀▄ █▀▄ █▀▄    █▀▄ ▄▀▄ █▄█ █▀▄",
        "█▀  █ █  █  █▀  █▀▄    ▄▀  █ █ █ █    █▀▄ █ █ █▀█ █▀▄",
        "▀▀▀ ▀ ▀  ▀  ▀▀▀ ▀ ▀    ▀▀▀ ▀ ▀ ▀▀     ▀▀   ▀  ▀ ▀ ▀▀ ",
    ],

    "ENTER 3RD BOMB": [
        "█▀▀ █▀▄ ▀█▀ █▀▀ █▀▄    ▀▀▄ █▀▄ █▀▄    █▀▄ ▄▀▄ █▄█ █▀▄",
        "█▀  █ █  █  █▀  █▀▄     ▀▄ █▀▄ █ █    █▀▄ █ █ █▀█ █▀▄",
        "▀▀▀ ▀ ▀  ▀  ▀▀▀ ▀ ▀    ▀▀  ▀ ▀ ▀▀     ▀▀   ▀  ▀ ▀ ▀▀ ",
    ],

    "ENTER 4TH BOMB": [
        "█▀▀ █▀▄ ▀█▀ █▀▀ █▀▄    █ █ ▀█▀ █ █    █▀▄ ▄▀▄ █▄█ █▀▄",
        "█▀  █ █  █  █▀  █▀▄    ▀▀█  █  █▀█    █▀▄ █ █ █▀█ █▀▄",
        "▀▀▀ ▀ ▀  ▀  ▀▀▀ ▀ ▀      ▀  ▀  ▀ ▀    ▀▀   ▀  ▀ ▀ ▀▀ ",
    ],

    "ENTER 5TH BOMB": [
        "█▀▀ █▀▄ ▀█▀ █▀▀ █▀▄    █▀▀ ▀█▀ █ █    █▀▄ ▄▀▄ █▄█ █▀▄",
        "█▀  █ █  █  █▀  █▀▄    ▀▀▄  █  █▀█    █▀▄ █ █ █▀█ █▀▄",
        "▀▀▀ ▀ ▀  ▀  ▀▀▀ ▀ ▀    ▀▀   ▀  ▀ ▀    ▀▀   ▀  ▀ ▀ ▀▀ ",
    ],

    "ENTER 6TH BOMB": [
        "█▀▀ █▀▄ ▀█▀ █▀▀ █▀▄    ▄▀▀ ▀█▀ █ █    █▀▄ ▄▀▄ █▄█ █▀▄",
        "█▀  █ █  █  █▀  █▀▄    █▀█  █  █▀█    █▀▄ █ █ █▀█ █▀▄",
        "▀▀▀ ▀ ▀  ▀  ▀▀▀ ▀ ▀    ▀▀▀  ▀  ▀ ▀    ▀▀   ▀  ▀ ▀ ▀▀ ",
    ],

    "ENTER 7TH BOMB": [
        "█▀▀ █▀▄ ▀█▀ █▀▀ █▀▄    ▀▀█ ▀█▀ █ █    █▀▄ ▄▀▄ █▄█ █▀▄",
        "█▀  █ █  █  █▀  █▀▄     █   █  █▀█    █▀▄ █ █ █▀█ █▀▄",
        "▀▀▀ ▀ ▀  ▀  ▀▀▀ ▀ ▀     ▀   ▀  ▀ ▀    ▀▀   ▀  ▀ ▀ ▀▀ ",
    ],

    "ENTER 8TH BOMB": [
        "█▀▀ █▀▄ ▀█▀ █▀▀ █▀▄    █▀█ ▀█▀ █ █    █▀▄ ▄▀▄ █▄█ █▀▄",
        "█▀  █ █  █  █▀  █▀▄    █▀█  █  █▀█    █▀▄ █ █ █▀█ █▀▄",
        "▀▀▀ ▀ ▀  ▀  ▀▀▀ ▀ ▀    ▀▀▀  ▀  ▀ ▀    ▀▀   ▀  ▀ ▀ ▀▀ ",
    ],

    "ENTER 9TH BOMB": [
        "█▀▀ █▀▄ ▀█▀ █▀▀ █▀▄    █▀█ ▀█▀ █ █    █▀▄ ▄▀▄ █▄█ █▀▄",
        "█▀  █ █  █  █▀  █▀▄    ▀▀█  █  █▀█    █▀▄ █ █ █▀█ █▀▄",
        "▀▀▀ ▀ ▀  ▀  ▀▀▀ ▀ ▀    ▀▀   ▀  ▀ ▀    ▀▀   ▀  ▀ ▀ ▀▀ ",
    ],

    "ENTER 10TH BOMB": [
        "█▀▀ █▀▄ ▀█▀ █▀▀ █▀▄    ▄█  █▀█ ▀█▀ █ █    █▀▄ ▄▀▄ █▄█ █▀▄",
        "█▀  █ █  █  █▀  █▀▄     █  █ █  █  █▀█    █▀▄ █ █ █▀█ █▀▄",
        "▀▀▀ ▀ ▀  ▀  ▀▀▀ ▀ ▀    ▀▀▀ ▀▀▀  ▀  ▀ ▀    ▀▀   ▀  ▀ ▀ ▀▀ ",
    ],

    "ENTER 11TH BOMB": [
        "█▀▀ █▀▄ ▀█▀ █▀▀ █▀▄    ▄█  ▄█  ▀█▀ █ █    █▀▄ ▄▀▄ █▄█ █▀▄",
        "█▀  █ █  █  █▀  █▀▄     █   █   █  █▀█    █▀▄ █ █ █▀█ █▀▄",
        "▀▀▀ ▀ ▀  ▀  ▀▀▀ ▀ ▀    ▀▀▀ ▀▀▀  ▀  ▀ ▀    ▀▀   ▀  ▀ ▀ ▀▀ ",
    ],

    "ENTER 12TH BOMB": [
        "█▀▀ █▀▄ ▀█▀ █▀▀ █▀▄    ▄█  ▀▀▄ ▀█▀ █ █    █▀▄ ▄▀▄ █▄█ █▀▄",
        "█▀  █ █  █  █▀  █▀▄     █  ▄▀   █  █▀█    █▀▄ █ █ █▀█ █▀▄",
        "▀▀▀ ▀ ▀  ▀  ▀▀▀ ▀ ▀    ▀▀▀ ▀▀▀  ▀  ▀ ▀    ▀▀   ▀  ▀ ▀ ▀▀ ",
    ],

    "ENTER 13TH BOMB": [
        "█▀▀ █▀▄ ▀█▀ █▀▀ █▀▄    ▄█  ▀▀▄ ▀█▀ █ █    █▀▄ ▄▀▄ █▄█ █▀▄",
        "█▀  █ █  █  █▀  █▀▄     █   ▀▄  █  █▀█    █▀▄ █ █ █▀█ █▀▄",
        "▀▀▀ ▀ ▀  ▀  ▀▀▀ ▀ ▀    ▀▀▀ ▀▀   ▀  ▀ ▀    ▀▀   ▀  ▀ ▀ ▀▀ ",
    ],

    "ENTER EXTRA LIFE": [
        "█▀▀ █▀▄ ▀█▀ █▀▀ █▀▄    █▀▀ █ █ ▀█▀ █▀▄ ▄▀▄    █   ▀█▀ █▀▀ █▀▀",
        "█▀  █ █  █  █▀  █▀▄    █▀  ▄▀▄  █  █▀▄ █▀█    █    █  █▀  █▀ ",
        "▀▀▀ ▀ ▀  ▀  ▀▀▀ ▀ ▀    ▀▀▀ ▀ ▀  ▀  ▀ ▀ ▀ ▀    ▀▀▀ ▀▀▀ ▀   ▀▀▀",
    ],

    "ALL HIDDEN!": [
        "▄▀▄ █   █      █ █ ▀█▀ █▀▄ █▀▄ █▀▀ █▀▄ █",
        "█▀█ █   █      █▀█  █  █ █ █ █ █▀  █ █ ▀",
        "▀ ▀ ▀▀▀ ▀▀▀    ▀ ▀ ▀▀▀ ▀▀  ▀▀  ▀▀▀ ▀ ▀ ▀",
    ],

    "PICK ENEMY PAWN": [
        "█▀▄ ▀█▀ ▄▀▀ █ █    █▀▀ █▀▄ █▀▀ █▄█ █ █    █▀▄ ▄▀▄ █ █ █▀▄",
        "█▀   █  █   █▀▄    █▀  █ █ █▀  █▀█  █     █▀  █▀█ █▄█ █ █",
        "▀   ▀▀▀  ▀▀ ▀ ▀    ▀▀▀ ▀ ▀ ▀▀▀ ▀ ▀  ▀     ▀   ▀ ▀ ▀ ▀ ▀ ▀",
    ],

    "SACRIFICE BOMB": [
        "▄▀▀ ▄▀▄ ▄▀▀ █▀▄ ▀█▀ █▀▀ ▀█▀ ▄▀▀ █▀▀    █▀▄ ▄▀▄ █▄█ █▀▄",
        " ▀▄ █▀█ █   █▀▄  █  █▀   █  █   █▀     █▀▄ █ █ █▀█ █▀▄",
        "▀▀  ▀ ▀  ▀▀ ▀ ▀ ▀▀▀ ▀   ▀▀▀  ▀▀ ▀▀▀    ▀▀   ▀  ▀ ▀ ▀▀ ",
    ],

    "SCAN ENEMY PAWN": [
        "▄▀▀ ▄▀▀ ▄▀▄ █▀▄    █▀▀ █▀▄ █▀▀ █▄█ █ █    █▀▄ ▄▀▄ █ █ █▀▄",
        " ▀▄ █   █▀█ █ █    █▀  █ █ █▀  █▀█  █     █▀  █▀█ █▄█ █ █",
        "▀▀   ▀▀ ▀ ▀ ▀ ▀    ▀▀▀ ▀ ▀ ▀▀▀ ▀ ▀  ▀     ▀   ▀ ▀ ▀ ▀ ▀ ▀",
    ],

    "BOOM!": [
        "█▀▄ ▄▀▄ ▄▀▄ █▄█ █",
        "█▀▄ █ █ █ █ █▀█ ▀",
        "▀▀   ▀   ▀  ▀ ▀ ▀",
    ],

    "EXTRA LIFE!": [
        "█▀▀ █ █ ▀█▀ █▀▄ ▄▀▄    █   ▀█▀ █▀▀ █▀▀ █",
        "█▀  ▄▀▄  █  █▀▄ █▀█    █    █  █▀  █▀  ▀",
        "▀▀▀ ▀ ▀  ▀  ▀ ▀ ▀ ▀    ▀▀▀ ▀▀▀ ▀   ▀▀▀ ▀",
    ],

    "OVERFLOW!": [
        "▄▀▄ █ █ █▀▀ █▀▄ █▀▀ █   ▄▀▄ █ █ █",
        "█ █ █ █ █▀  █▀▄ █▀  █   █ █ █▄█ ▀",
        " ▀   ▀  ▀▀▀ ▀ ▀ ▀   ▀▀▀  ▀  ▀ ▀ ▀",
    ],

    "SAFE": [
        "▄▀▀ ▄▀▄ █▀▀ █▀▀",
        " ▀▄ █▀█ █▀  █▀ ",
        "▀▀  ▀ ▀ ▀   ▀▀▀",
    ],

    "SCANNED": [
        "▄▀▀ ▄▀▀ ▄▀▄ █▀▄ █▀▄ █▀▀ █▀▄",
        " ▀▄ █   █▀█ █ █ █ █ █▀  █ █",
        "▀▀   ▀▀ ▀ ▀ ▀ ▀ ▀ ▀ ▀▀▀ ▀▀ ",
    ],

    "BOT ATTACKS": [
        "█▀▄ ▄▀▄ ▀█▀    ▄▀▄ ▀█▀ ▀█▀ ▄▀▄ ▄▀▀ █ █ ▄▀▀",
        "█▀▄ █ █  █     █▀█  █   █  █▀█ █   █▀▄  ▀▄",
        "▀▀   ▀   ▀     ▀ ▀  ▀   ▀  ▀ ▀  ▀▀ ▀ ▀ ▀▀ ",
    ],

    "YOU WIN!": [
        "█ █ ▄▀▄ █ █    █ █ ▀█▀ █▀▄ █",
        " █  █ █ █ █    █▄█  █  █ █ ▀",
        " ▀   ▀  ▀▀▀    ▀ ▀ ▀▀▀ ▀ ▀ ▀",
    ],

    "YOU LOSE!": [
        "█ █ ▄▀▄ █ █    █   ▄▀▄ ▄▀▀ █▀▀ █",
        " █  █ █ █ █    █   █ █  ▀▄ █▀  ▀",
        " ▀   ▀  ▀▀▀    ▀▀▀  ▀  ▀▀  ▀▀▀ ▀",
    ],

    "PLAYER 1 WINS!": [
        "█▀▄ █   ▄▀▄ █ █ █▀▀ █▀▄    ▄█     █ █ ▀█▀ █▀▄ ▄▀▀ █",
        "█▀  █   █▀█  █  █▀  █▀▄     █     █▄█  █  █ █  ▀▄ ▀",
        "▀   ▀▀▀ ▀ ▀  ▀  ▀▀▀ ▀ ▀    ▀▀▀    ▀ ▀ ▀▀▀ ▀ ▀ ▀▀  ▀",
    ],

    "PLAYER 2 WINS!": [
        "█▀▄ █   ▄▀▄ █ █ █▀▀ █▀▄    ▀▀▄    █ █ ▀█▀ █▀▄ ▄▀▀ █",
        "█▀  █   █▀█  █  █▀  █▀▄    ▄▀     █▄█  █  █ █  ▀▄ ▀",
        "▀   ▀▀▀ ▀ ▀  ▀  ▀▀▀ ▀ ▀    ▀▀▀    ▀ ▀ ▀▀▀ ▀ ▀ ▀▀  ▀",
    ],
}
