# CHESS BOMB  -  by RSMRV PRODUCTIONS

A chess-board minefield game that runs entirely inside the terminal (no game
window). Hide bombs under your pawns, flip the enemy's pawns, and protect
your king.

**Everything is in this one file:**

1. [Start the game](#1-start-the-game)
2. [How to play](#2-how-to-play)
3. [The files](#3-the-files)
4. [How the code works (for people who don't code)](#4-how-the-code-works-for-people-who-dont-code)
5. [How it works inside](#5-how-it-works-inside)
6. [Change the game yourself](#6-change-the-game-yourself)
7. [**Troubleshooting**](#7-troubleshooting)

---

## 1. Start the game

### What you need

- **Python 3.10 or newer.** Check by typing `python --version` in a terminal.
  (Get it from python.org. On Windows, tick **"Add python.exe to PATH"** while installing.)
- **pygame** for the music and sounds (optional: without it the game is silent).
- **A terminal window of at least 192 x 54 characters.** The game asks for
  that size when it starts, and has a safety net if the window is smaller.
  See [The window](#the-window) below.

### Start it

Open **Windows Terminal, PowerShell or Command Prompt** (not IDLE) in the
`chess_bomb` folder and type:

```
pip install pygame
python main.py
```

You only need `pip install pygame` once.

### The window

Every screen is made for **192 characters wide x 54 lines tall**.

- When the game starts it **asks** the terminal for a 192 x 54 window (the old
  Command Prompt and Mac/Linux terminals listen; Windows Terminal and VS Code don't).
- **The safety net:** before every screen, the game measures the window again.
  If you zoom in or the window is too small, the screen is **trimmed to fit**
  (the bottom part, where you type, is kept) instead of breaking. Zoom back
  out and the whole screen comes back on the next screen.

For the full picture, make the window that big:

- Press **F11** (full screen), and if it still doesn't fit, zoom out with
  **Ctrl and minus (-)**.
- Or set the size yourself: see [the first problem in Troubleshooting](#the-picture-is-broken-lines-wrap-the-screen-scrolls-the-box-bends).

To check the size, type this in the terminal:

```
python -c "import shutil; print(shutil.get_terminal_size())"
```

It must say `columns=192` (or more) and `lines=54` (or more).

---

## 2. How to play

### The rules (that's all of them)

| | |
|---|---|
| **Pawn** | Every square starts as a face-down pawn. You hide your traps under your own pawns. |
| **Bomb** | Whoever flips an enemy bomb **loses 1 HP**. |
| **Extra life** | Whoever flips an enemy extra life **heals 1 HP**. |
| **Overflow** | Find an extra life while your HP is already full, and the **enemy loses 1 HP** instead. |
| **Sacrifice scan** | From level 5 up: blow up one of your own hidden bombs to look under one enemy pawn safely. |
| **HP** | Shown as **Queen, King, Queen** (3 HP). You lose the queens first; the King is your last HP. |

**You win** by taking all the enemy's HP, or by flipping every one of their safe pawns.

### Answering

Every answer is typed and then confirmed with **Enter**.
The only exception is the **Bonus Stage**: there you just press **A** or **D**.

### The main menu

| Type | What happens |
|---|---|
| `1` START | The campaign map: 10 levels against the Bot |
| `2` PVP | 1V1: two players on one computer |
| `3` GUIDE | 3 pages of rules, with pictures (Enter = next page, `0` = back) |
| `4` MINI GAMES | The 3 mini games (they unlock from campaign level 5) |
| `5` EXIT | Closes the game. Then type `1` + Enter to come back, or just Enter to leave. |

### The campaign

1. **Pick a level** on the map (type `1` to `10`). Green = cleared, gold = open,
   a padlock = locked. `0` = back to the menu.
2. **Hide your traps.** The river says "ENTER 1ST BOMB", "ENTER 2ND BOMB" ...
   then "ENTER EXTRA LIFE". Type one of your squares each time, like `a1`.
3. **Battle.** You and the Bot take turns. On your turn, type an enemy square
   to flip it.
   - **How to type a square:** the letter is the column (letters under the
     board), the number is the row (yellow numbers on the left). `a1` and `1a`
     both work.
   - **On each side of the river, the rows count 1, 2, 3 ... from the top down.**
     The enemy's row 1 is the very top row of the board. Your row 1 is the first
     row under the river.
   - Your own bombs are shown with a red tint, your extra life with a green tint.
     Only you can see them.
   - `1` = the sacrifice scan (level 5 and up), `0` = quit the battle.
4. **The end.** The whole board is shown.
   - **YOU WIN:** +100 coins, the next level unlocks, and sometimes a "NEW MINI GAME!"
     animation plays.
   - **YOU LOSE:** type `1` to try again, or Enter to go back to the map.

### How big are the boards?

The board grows **every** level. Each level adds 1 column, and every 2nd level
also adds 1 row on each side. The bombs start at 4 and go up by 1 each level:

| Level | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 |
|---|---|---|---|---|---|---|---|---|---|---|
| Pawns each | 12 | 14 | 24 | 27 | 40 | 44 | 60 | 65 | 84 | 90 |
| Bombs | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13 |

### 1V1 (PVP)

Pick a board: `1` SMALL (like level 1), `2` MEDIUM (like level 4) or `3` LARGE
(like level 9). Player One hides their traps while Player Two looks away, then
the other way round. Before every turn a "look away!" screen comes up, so you
can pass the computer over.

### Coins

- You start with **50 coins**. Winning a campaign level gives **+100**.
- Coins are spent and won in the mini games and the bonus stage.

### The Bonus Stage

It pops up at random: before a level (20% chance) or after a win (30% chance).
Your pawn runs down the board while bombs and coins fall toward it, faster and
faster. Press **A** (left) or **D** (right) to dodge the bombs and grab the
coins (+10 each). **No Enter needed:** the pawn moves the moment you press the
key. Survive **20 seconds**! A bomb ends the stage early, but you keep your coins.

### The mini games

They unlock in the campaign: **Racing Piece** at level 5, **Tick Tock** at
level 7, **Flip the King** at level 9 (a lock animation plays when one opens).
Each one starts with a short intro, then START (`1`) / GUIDE (`2`) / MENU (`3`).

| Mini game | How to play |
|---|---|
| **Racing Piece** | Pick a knight (`1`-`4`), then bet coins (at least 10). If your knight comes 1st, you win **3x your bet**. |
| **Tick Tock** | A bomb ticks from 0:30. A knight sits on a small a-e / 1-4 board: type its square (like `c3`). Get 4 right to defuse it (+30 coins + 1 per second left). A wrong square or running out of time = BOOM. The clock is checked when you press Enter. |
| **Flip the King** | An arrow appears: press its letter, **`w`** = up, **`a`** = left, **`s`** = down, **`d`** = right (**no Enter needed**), before the time bar runs out (3 seconds, less after every flip). 8 right answers = 1 full flip = +5 coins. A wrong letter or too slow = the king falls (-10 coins). |

### Secret codes (type them on the main menu)

| Code | What it does |
|---|---|
| `l` | X-ray: see every hidden trap (type it again to switch it off). Also works on the map and in a battle. |
| `p` | Unlock all 10 levels (type it again to go back to your real level). |
| `69` | Start over like a new player (asks you to type `yes` first). |

### No save file

Your coins, levels and best scores are kept **only while the game is running**.
When you close the game, the next game starts fresh.

---

## 3. The files

All the code is in **one folder**, with only the `sounds` folder next to it:

```
chess_bomb/
  main.py           START HERE: python main.py
  settings.py       every number of the game + what it remembers (coins, levels)
  display.py        colours, pixel pictures, showing screens, asking questions
  art.py            every drawing, the big letters, boxes, buttons, river words
  animations.py     every moving picture (the intro, BOOM, victory ...)
  menus.py          the main menu, the guide, the campaign, 1V1
  battle.py         the board, the rules, the battle, the bonus stage
  mini_games.py     the mini games menu and the 3 mini games
  sound.py          plays the music and sound effects
  controls.py       the CONTROLS boxes (which keys to type)
  cheats.py         the secret codes l, p and 69
  sounds/           the music and sound effects (.wav files)
  README.md         this file
  requirements.txt  what to install (pygame)
```

**Read the files in this order** (it's also the "FILE 1 of 11" number at the
top of every file):

| # | File | What it does |
|---|---|---|
| 1 | `main.py` | Start here: you type `python main.py` |
| 2 | `settings.py` | Every setting and what the game remembers. **Change the game here.** |
| 3 | `display.py` | Colours, pixel pictures, showing every screen, asking your questions |
| 4 | `art.py` | Every drawing you see, and the words on the river |
| 5 | `animations.py` | The intro, BOOM, victory ... (flip books of pixel pictures) |
| 6 | `menus.py` | The title screen, the guide, the campaign map, 1V1 |
| 7 | `battle.py` | The battle, the rules, the bonus stage |
| 8 | `mini_games.py` | [4] MINI GAMES: Racing Piece, Tick Tock, Flip the King |
| 9 | `sound.py` | Plays the music and sounds |
| 10 | `controls.py` | The CONTROLS boxes |
| 11 | `cheats.py` | The secret codes |

**How the files use each other:**

```
                     main.py   (START HERE)
                        │
                     menus.py  ── main menu, guide, campaign, 1V1
            ┌───────────┼─────────────┐
       battle.py   mini_games.py   cheats.py
     (the battle,   (3 mini games)  (l, p, 69)
      bonus stage)
            │
   ┌────────┼───────────┬───────────┬──────────┐
 animations art.py   controls.py  sound.py   settings.py
   .py     (drawings) (key boxes)  (music)   (numbers, coins)
            │
        display.py  ── colours, pixel pictures, shows every screen
```

Because every file is in the same folder, `import art` simply finds `art.py`
next to it.

---

## 4. How the code works (for people who don't code)

You don't need to know Python to follow this. Every file starts with a box
that says **what the file does**, the lines have comments in plain English,
and inside every file the code is in the order things happen.

The code only uses **basic Python**: variables, `if` / `elif` / `else`,
`match` / `case`, `for` and `while` loops, lists and dictionaries.

### Words you'll see in the code

| You see | It means |
|---|---|
| `# some words` | A **comment**. Python ignores it; it's a note for people. |
| `coins = 50` | A **variable**: remember the value `50` under the name `coins`. |
| `"hello"` | **Text** (called a *string*). |
| `[1, 2, 3]` | A **list**: several things in order. `lines[0]` is the first one. |
| `{'coins': 50, 'level': 3}` | A **dictionary**: things looked up by name. `game_memory['coins']` gives `50`. |
| `(2, 3)` | A **pair** (a *tuple*). The board uses `(row, column)` pairs for squares. `square[0]` is the row, `square[1]` the column. |
| `def draw_bomb(...):` | Makes a **function**: a named list of steps. |
| `draw_bomb(...)` | **Calls** (runs) that function. |
| `return x` | The function is finished and **gives back** `x`. |
| `if ... :` / `elif ... :` / `else:` | Do something **only if** something is true. |
| `match choice:` / `case '1':` | Python's **switch case**: look at `choice` and run only the `case` that matches it. `case '1' \| '2':` = "1 or 2". `case _:` = "anything else". |
| `for x in ...:` | **Repeat** the steps for every item. |
| `while ...:` | **Repeat** the steps as long as something is true. |
| `while True:` ... `break` | Repeat forever ... until `break` leaves the loop. |
| `continue` | Skip the rest of the loop and start the next round. |
| `True` / `False` / `None` | Yes / No / Nothing. |
| `import art` | **Borrow** the code from another file (`art.py`). |
| `a % b` | The **remainder** of `a ÷ b`. `7 % 2` is `1`, so `x % 2 == 0` means "x is even". |
| `a // b` | Divide and **drop the decimals**. `7 // 2` is `3`. |
| `text[0:3]` | The first 3 letters of the text. |
| `"=" * 5` | The text `"="` written 5 times: `"====="`. |
| `try:` ... `finally:` | The `finally` part ALWAYS runs at the end, even after an error or Ctrl+C. |
| `global name` | Inside a function: change the value kept at the top of the file. |
| `"\x1b[38;5;196m"` | A secret message to the terminal (a colour). See `display.py` PART 1. |

Indentation (the spaces at the start of a line) matters in Python: the lines
pushed in under an `if`, `for`, `while`, `match` or `def` belong to it.

### Lines you'll see again and again

| You see | It means |
|---|---|
| `lines = []` | Start an empty list of text lines (a screen being built). |
| `lines.append(x)` | Add `x` at the **end** of the list (one more line at the bottom). |
| `lines.append("")` | Add an empty line. |
| `lines = lines + more` | Put all of `more` below what's already there. |
| `paint("Hi", 196)` | The text "Hi" in colour 196 (red). |
| `center_line(text, 80)` | Spaces on both sides so the text sits in the middle of 80 characters. |
| `present(lines)` | **Show** the screen (`display.py`). |
| `ask(...)` / `ask_in_box(...)` | Show a question and wait for the player to type and press Enter. |
| `wait_for_enter()` | "Press Enter to continue..." |
| `play_sound('boom')` | Play the sound effect `sounds/sfx_boom.wav`. |
| `new_picture(100, 50)` | An empty pixel picture, 100 pixels wide and 50 tall. |
| `fill_box(picture, left, top, width, height, color)` | Colour a rectangle in the picture. |
| `draw_sprite(picture, drawing, left, top, colors)` | Copy a drawing from `art.py` onto the picture, its top-left corner at (left, top). |
| `picture_to_lines(picture)` | Turn the pixel picture into coloured text lines. |
| `show_frame(picture, caption, color, seconds)` | Show one frame of an animation, then wait (`animations.py`). |
| `for row in range(5):` | Repeat 5 times, with `row` = 0, 1, 2, 3, 4. |
| `len(something)` | How many items (or letters) there are. |
| `str(5)` / `int("5")` | Number to text / text to number. |

### The hardest parts (and how to think about them)

1. **The ▀ trick** (`display.py` PART 2): one character shows two pixels, one
   on top of the other.
2. **Terminal codes** (`display.py` PART 1): hidden messages like
   `"\x1b[38;5;196m"` that the terminal obeys instead of printing.
3. **Reading a key without Enter** (`battle.py`, the bonus stage): the keyboard
   is switched to "one key at a time" for 20 seconds, then back to normal.
4. **The state dictionary** (`battle.py`): one dictionary that remembers
   everything about a battle. Once you know its boxes, the rest is easy.

---

## 5. How it works inside

### What happens when you play, step by step

The path through the code from `python main.py` to the first BOOM:

1. **`main.py`** checks your Python version, turns the colours on
   (`setup_window`), starts the music (`start_audio`) and plays the intro
   (`play_intro`).
2. **`menus.launch_main_menu()`** shows the title screen and waits for you to
   type. You type `1`.
3. **`menus.open_campaign_map()`** shows the map. You type `1` for level 1.
4. **`menus.start_campaign_level(1)`** maybe plays a BONUS STAGE first (a dice
   roll), then asks **`battle.make_a_new_match()`** for a fresh battle.
5. **`battle.let_the_player_hide_their_traps()`** asks where to hide each bomb. The river says
   "ENTER 1ST BOMB" (a drawing from `art.py`, `BANNERS`). You type `b1` in the
   chess-clock box (`display.ask_in_box`). The game writes it down:
   `state['traps'][(3, 1)] = 'bomb'`.
6. **`battle.let_the_bot_hide_its_traps()`** hides the Bot's traps at random.
7. **`battle.play_the_whole_battle()`** is the battle. It repeats your turn
   (`play_one_turn_of_a_person`), then the Bot's turn (`play_one_turn_of_the_bot`), until someone wins.
8. You type `c4`. **`battle.flip_the_pawn_and_use_the_rules()`** looks under the pawn. It's the
   Bot's bomb, so **you lose 1 HP** and **`animations.play_bomb_animation()`**
   shows the explosion.
9. When the battle is over, **`menus.finish_campaign_match()`** shows YOU WIN
   (coins, the next level unlocks, maybe a NEW MINI GAME animation) or YOU LOSE
   (type 1 to TRY AGAIN).
10. Your coins and unlocked levels are kept in **`settings.game_memory`** until
    you close the game.

### How a picture gets on the screen

1. **A drawing (sprite)** is written as letters in `art.py`. Each letter is a
   colour, `.` is see-through:
   ```
   ".kk."      k = black
   "kwwk"      w = white
   ```
2. **A picture** is a grid of colour numbers (`display.new_picture`). Drawings
   are copied onto it (`draw_sprite`), rectangles are filled (`fill_box`).
3. **The ▀ trick** (`display.picture_to_lines`): one character `▀` shows **two**
   pixels: the top one in the text colour, the bottom one in the background
   colour. So the picture becomes lines of coloured `▀`.
4. **`display.present(lines)`** prints all the lines at once, centred in the
   window. It does not check whether they fit: the window must be 192 x 54.

### How the battle remembers everything

One battle is one dictionary called **`state`** (made by `battle.make_a_new_match`).
A square is written as a pair `(row, column)`, counted from the top-left,
starting at 0. So `(3, 1)` is the 4th row down, 2nd column.

| In `state` | What it holds |
|---|---|
| `'rows'`, `'columns'` | How big the board is |
| `'river_row'` | The row number of the river (always the middle row) |
| `'traps'` | Only the squares that hide something: `(3, 1): 'bomb'`, `(0, 4): 'life'`. A square that isn't in here is an empty pawn. |
| `'flipped'` | A list of every square that was already flipped |
| `'players'` | `1` = you, `2` = the Bot (or Player Two). Each has a `'name'`, `'hp'` and the `'rows'` on their side of the river. |
| `'turn'` | `1` or `2`: whose turn it is |

Who owns a trap? Whoever owns that side of the river: you can only hide traps
on your own side. Player Two has the rows above the river, Player One the rows below.

**All the rules are in one function, `battle.flip_the_pawn_and_use_the_rules()`**, written as a
`match` / `case`: bomb = the flipper loses 1 HP · extra life = the flipper heals
1 HP · extra life at full HP = OVERFLOW, the enemy loses 1 HP · anything else = safe.

**Every question in a battle** ("hide a bomb", "flip an enemy pawn", "pick your
bomb to sacrifice", "pick a pawn to scan") goes through **one** function,
`battle.keep_asking_until_a_good_square_is_typed()`. It shows the screen, reads what you typed, checks it,
and if something is wrong shows a red message and asks again.

### How the animations work

An animation is a **flip book**: a pixel picture (a frame) is drawn, shown,
then after a tiny pause (`time.sleep`) the next frame is drawn a little
different and shown on top of it. Every frame is made the same way:

1. `picture = new_picture(...)` makes an empty picture.
2. `fill_box`, `draw_sprite` and `set_pixel` paint things on it.
3. `show_frame(picture, caption, color, seconds)` shows it and waits.

There is no hard maths:

- **Something moving** (the falling bomb, the racing knights) is drawn a few
  pixels further along in every frame.
- **A circle** (the fireball, the radar): a pixel is inside the circle when
  `across * across + down * down <= radius * radius` (Pythagoras without the
  square root).
- **Things flying out in a circle** (fireworks, sparkles) fly toward a list
  of 14 ready-made spots on a circle, `CIRCLE_POINTS`.
- **The radar line** points at a list of 12 ready-made spots, `RADAR_ENDS`,
  one for each frame.
- **The spinning king** (Flip the King) is a ready-made drawing for every
  turn in `art.py`, so nothing has to be turned by maths.

Each new frame is painted on top of the old one (`present(..., clear=False)`),
so it doesn't flicker.

### How typing works

Every answer is read with Python's own `input()`: you type, then press Enter
(`display.ask`). For the chess-clock box, the game first moves the cursor inside
the box (`display.ask_in_box`), so your letters appear there. The timed mini
games (Tick Tock, Flip the King) look at the clock when you press Enter, to see
how long you took.

The **Bonus Stage** and **Flip the King** don't use Enter. For those 20 seconds, the
keyboard is switched to "one key at a time" (`read_keys_without_enter`), the game
takes a quick look for a key many times a second (`which_key_was_just_pressed`), and at
the end it switches the keyboard back (`put_the_keyboard_back_to_normal`). Windows uses a
tool called `msvcrt` for this; Mac and Linux use `termios` and `select`.

### How the sound works

The music and sound effects are finished `.wav` files in the `sounds` folder.
`sound.py` plays them with pygame's sound part only (pygame never opens a window).

---

## 6. Change the game yourself

Open **`settings.py`**, change a number, save, and run `python main.py` again:

| Try changing | What happens |
|---|---|
| `BOMBS_ON_LEVEL_1 = 4` | How many bombs level 1 has |
| `EXTRA_BOMBS_PER_LEVEL = 1` | How many more bombs every level adds |
| `LEVEL_1_ROWS_PER_SIDE = 2` | How many rows each player has on level 1 |
| `LEVEL_1_COLUMNS = 6` | How wide the level 1 board is |
| `EXTRA_COLUMNS_PER_LEVEL = 1` | How many columns every new level adds |
| `LEVELS_PER_EXTRA_ROW = 2` | Every how many levels each side gets one more row |
| `STARTING_HEALTH = 3` | How much HP everyone starts with |
| `COINS_FOR_WINNING_A_LEVEL = 100` | Coins for winning a level |
| `STARTING_COINS = 50` | Coins a new player starts with |
| `RACING_PIECE_UNLOCK = 5` | When the first mini game unlocks |
| `BONUS_CHANCE_AFTER_WIN = 30` | % chance of a bonus stage after a win |

More things to change:

- A **drawing**: edit its letters in `art.py`.
- A **river message**: edit its drawing in `art.py` (`BANNERS`, at the bottom).
- An **animation**: `animations.py`. For example, change the colours in a
  `[231, 226, 208]` list, or the `time.sleep` / seconds numbers to make it faster or slower.
- The **Bonus Stage**: `HOW_MANY_SECONDS_THE_BONUS_STAGE_LASTS`, `COINS_FOR_EACH_COIN_GRABBED` and `CHANCE_OF_A_COIN_IN_PERCENT` at the
  start of its part in `battle.py`.
- The **CONTROLS boxes**: `controls.py`.
- The **secret codes**: `cheats.py`.
- The **volume**: `MUSIC_VOLUME` and `EFFECTS_VOLUME` at the top of `sound.py`.
- A **song**: put your own `.wav` file in the `sounds` folder and change its
  file name in `SONGS` in `sound.py`.

---

## 7. Troubleshooting

### The picture is broken: lines wrap, the screen scrolls, the box bends

**The window is too small, or you zoomed in.** The game needs **192 x 54**.
Its safety net trims every screen to fit a smaller window, so you may see the
board cut off at the top or on the right. Make the window bigger (or zoom out)
and the next screen is shown in full:

- **Windows Terminal / PowerShell:** press **F11** for full screen. Still too
  small? Zoom out with **Ctrl and minus (-)** (Ctrl and 0 resets the zoom).
  To make it permanent: Settings → Startup → **Launch size**: Columns `192`, Rows `54`.
- **The old black Command Prompt:** type this first, then start the game:
  ```
  mode con: cols=192 lines=54
  python main.py
  ```
- **VS Code:** its terminal panel is usually much too small. Either run the game
  in Windows Terminal instead, or make the panel as big as possible: click the
  **^** (Maximize Panel Size) at the top right of the terminal panel, and zoom
  out with **Ctrl and minus (-)**.
- **Mac Terminal:** Terminal → Settings → Profiles → Window → Columns `192`,
  Rows `54`, or zoom out with **Cmd and minus (-)**.

Then check the size:

```
python -c "import shutil; print(shutil.get_terminal_size())"
```

It must show `columns=192` (or more) and `lines=54` (or more). Then restart the
game. If you change the size **while** the game runs, the game notices it on
the next screen.

### My letters appear outside the chess-clock box

Same cause: the window is too small, so the screen moved. Make the window
192 x 54 (see above). Also keep answers short: a very long answer runs past
the edge of the box.

### "python" is not recognized / command not found

Python isn't installed, or it isn't on the PATH.
- Install it from python.org and tick **"Add python.exe to PATH"**.
- On Windows you can also try `py main.py` instead of `python main.py`.
- On Mac/Linux try `python3 main.py`.

### "CHESS BOMB needs Python 3.10 or newer" / SyntaxError near `match`

Your Python is too old. The game uses `match` / `case`, which arrived in
Python 3.10. Install a newer Python from python.org and check with `python --version`.

### ModuleNotFoundError: No module named 'display' (or 'art', 'battle' ...)

- Start the game with **`python main.py`** from **inside** the `chess_bomb` folder.
- All the `.py` files must stay together in that one folder. Don't move one into
  another folder or rename it.

### There's no sound

- Install pygame: `pip install pygame` (or `py -m pip install pygame`).
  If that fails on a very new Python, try `pip install pygame-ce` (it works the same).
- Check that the `sounds` folder is next to `main.py` and full of `.wav` files.
- Check your computer's volume. The game's own volume is `MUSIC_VOLUME` /
  `EFFECTS_VOLUME` in `sound.py`.

### I see junk like `[38;5;196m` instead of colours

The terminal doesn't understand colour codes.
- Don't use **IDLE**: it can't show colours. Use Windows Terminal, PowerShell
  or Command Prompt.
- On an old Windows (7 or older), the old Command Prompt can't show them.
  Install Windows Terminal.

### The blocks (▀ ▄ █ ╔) show as `?` or empty boxes

The terminal's font or text setting can't show them.
- Use a font like **Cascadia Mono** or **Consolas** (terminal settings → font).
- In the old Command Prompt, type `chcp 65001` before `python main.py`.

### Bonus Stage: my pawn doesn't move

- Press **A** or **D** on their own: no Enter needed.
- Make sure **Caps Lock** is off and you're not pressing the arrow keys
  (only A and D move the pawn).
- Click inside the terminal window first, so it gets your keys.
- In **IDLE** or some editor "Run" panels, keys can't be read one at a time.
  Run the game in Windows Terminal, PowerShell or Command Prompt.

### Letters I typed during an animation show up in my next answer

Keys pressed while an animation plays wait in line and appear in the next
question. Just delete them with Backspace before pressing Enter.

### The x-ray suddenly turned on (or off)

Typing `l` on its own on the main menu, the map or in a battle switches the
x-ray cheat. Type `l` again to switch it back.

### Flip the King: the arrow keys don't work

That's normal: press the letter instead, **w** (up), **a** (left), **s** (down),
**d** (right). No Enter needed. Make sure Caps Lock is off.

### Tick Tock: it said "TIME'S UP" but the clock still showed time

The clock on the screen shows the time when the question appeared. The game
checks the real time when you press Enter, so if you took longer than the
time left, it's too late.

### The mini games are locked

They unlock in the campaign: Racing Piece at level 5, Tick Tock at level 7,
Flip the King at level 9. (Or use the secret code `p`.)

### My coins and levels are gone

There is no save file: everything is kept only while the game runs. Closing
the game starts fresh next time.

### The game is slow or flickers

- Windows Terminal is the fastest. The old Command Prompt and VS Code are slower.
- Close other heavy programs.
- The biggest levels (9 and 10) have the most squares to draw.

### The terminal looks strange after the game closed or crashed

Type `cls` (Windows) or `reset` (Mac / Linux) and press Enter. To close the game
at any time, press **Ctrl + C**.

---

*CHESS BOMB - made by RSMRV PRODUCTIONS.*