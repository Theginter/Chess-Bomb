from settings import game_memory, forget_everything   # what the game remembers (settings.py)
from display import ask, paint                        # asking a question (display.py)

# =====================================================================
#  FILE 11 of 11:  CHEATS.PY  -  THE SECRET CODES
#
#  Type them on the main menu:
#     l    X-RAY: see every hidden trap      (type it again = off)
#          (also works on the level map and in a battle)
#     p    unlock all 10 levels              (type it again = undo)
#     69   start over like a new player      (asks "yes" first)
#
#  WHAT'S INSIDE
#   use_cheat_code(code)       does the cheat and gives back a message
#   switch_xray()              l
#   switch_all_levels()        p
#   start_over()               69
#   xray_is_on()               True while the x-ray is on (battle.py asks this)
# =====================================================================


def use_cheat_code(code):
    # Does the cheat for this code. Gives back a message to show ("" = none).
    match code:
        case 'l':
            switch_xray()
            return ""
        case 'p':
            return switch_all_levels()
        case '69':
            return start_over()
        case _:
            return ""


def switch_xray():
    # 'l': see every trap. Typed again: off.
    if game_memory['cheat_active'] == True:
        game_memory['cheat_active'] = False
    else:
        game_memory['cheat_active'] = True


def xray_is_on():
    # True while the x-ray cheat is on
    if game_memory['cheat_active'] == True:
        return True
    else:
        return False


def switch_all_levels():
    # 'p' unlocks all levels. 'p' again puts you back where you really were.
    if game_memory['level_before_cheat'] == 0:          # the cheat is off: switch it ON
        game_memory['level_before_cheat'] = game_memory['highest_unlocked_level']   # remember the real level
        game_memory['highest_unlocked_level'] = 10      # every level open
        return "--- CHEAT ON: ALL LEVELS UNLOCKED (press p again to undo) ---"
    else:                                               # the cheat is on: switch it OFF
        game_memory['highest_unlocked_level'] = game_memory['level_before_cheat']   # back to the real level
        game_memory['level_before_cheat'] = 0           # the cheat is off
        return "--- CHEAT OFF: back to level " + str(game_memory['highest_unlocked_level']) + " ---"


def start_over():
    # '69': start over like a new player (only if you type yes)
    answer = ask(paint("Type 'yes' to start over (coins and levels back to the start):", 203, bold=True))
    if answer == 'yes':
        forget_everything()                             # the memory goes back to a new player
        return "Everything reset: you start like a new player!"
    else:
        return ""                                       # anything else: nothing happens
