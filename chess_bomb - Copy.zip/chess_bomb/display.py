import os        # os = facts about the computer (is it Windows?)
import sys       # sys.stdout = the screen we print on
import shutil    # shutil = has a tool that measures the size of the window
from settings import SCREEN_COLUMNS, SCREEN_LINES   # the game's screen size: 192 x 54
import sound     # the little "click" when you press Enter (sound.py)

# =====================================================================
#  FILE 3 of 11:  DISPLAY.PY  -  COLOURS, PIXEL PICTURES, SHOWING SCREENS
#
#  PART 1: COLOURS            paint, visible_length, pad_right, center_line ...
#  PART 2: PIXEL PICTURES     new_picture, fill_box, draw_sprite, picture_to_lines
#  PART 3: SHOWING A SCREEN   setup_window, present
#  PART 4: ASKING QUESTIONS   ask, ask_in_box, wait_for_enter
#
#  Every other file builds a screen as a LIST OF TEXT LINES.
#  This file is the only one that actually PRINTS them.
#
#  THE WINDOW AND THE SAFETY NET
#   Every screen is made for a window of 192 x 54.
#   1) When the game starts, it ASKS the terminal for a 192 x 54 window
#      (setup_window, STEP 4).
#   2) THE SAFETY NET: before every screen is printed, the window is
#      measured again. If you zoomed in (or the window is too small), the
#      screen is CUT to fit (shrink_to_window), so lines never wrap, the
#      picture never bends, and your typing stays inside the box.
#      Zoom back out and the whole screen comes back on the next screen.
# =====================================================================


# =====================================================================
#  PART 1: COLOURS
#
#  A terminal normally prints exactly what you give it. But if you print
#  the special character ESC (written "\x1b") followed by a short code,
#  the terminal does NOT print it: it obeys it. For example:
#
#       "\x1b[38;5;196m"   = make the TEXT colour number 196 (red)
#       "\x1b[48;5;25m"    = make the BACKGROUND colour number 25 (blue)
#       "\x1b[1m"          = bold
#       "\x1b[0m"          = back to normal (RESET)
#
#  THE 256 COLOUR NUMBERS
#       0 - 15     basic colours (black, red, green ... white)
#      16 - 231    all kinds of colours (196 = red, 46 = green, 220 = gold)
#     232 - 255    greys, from almost black to almost white
# =====================================================================
RESET = "\x1b[0m"          # "back to normal colours"


def text_color(number):
    # The code for "make the TEXT this colour"
    # text_color(196) gives back "\x1b[38;5;196m"
    return "\x1b[38;5;" + str(number) + "m"


def back_color(number):
    # The code for "make the BACKGROUND this colour"
    # back_color(25) gives back "\x1b[48;5;25m"
    return "\x1b[48;5;" + str(number) + "m"


def paint(text, color=None, background=None, bold=False):
    # Puts colour codes around some text, then RESETS so the colour stops.
    # paint("Hi", 196) -> a red "Hi".   None = not used.
    codes = ""                                  # the codes to put in front
    if bold == True:                            # bold asked for?
        codes = codes + "\x1b[1m"
    if color != None:                           # a text colour asked for?
        codes = codes + text_color(color)
    if background != None:                      # a background colour asked for?
        codes = codes + back_color(background)
    if codes == "":                             # nothing asked for:
        return text                             # give the text back as it is
    else:
        return codes + text + RESET             # codes + text + "back to normal"


def visible_length(text):
    # How wide the text LOOKS on the screen.
    # The colour codes take no room, so we skip them while counting:
    # a code starts with ESC ("\x1b") and ends with a letter (like the m).
    count = 0                                   # letters we can see, so far
    inside_a_code = False                       # are we in the middle of a colour code?
    for letter in text:                         # look at every letter:
        if letter == "\x1b":                    # ESC: a code starts here
            inside_a_code = True
        elif inside_a_code == True:             # we are inside a code:
            if letter.isalpha():                # a letter (a-z, A-Z) ends the code
                inside_a_code = False
        else:                                   # a normal letter you can see:
            count = count + 1
    return count


def pad_right(text, width):
    # Adds spaces on the right until the text is 'width' wide
    missing = width - visible_length(text)      # how many spaces are missing
    if missing > 0:
        return text + " " * missing             # " " * 3 = 3 spaces
    else:
        return text                             # wide enough already


def pad_left(text, width):
    # Adds spaces on the LEFT until the text is 'width' wide ("2" -> "  2")
    missing = width - visible_length(text)
    if missing > 0:
        return " " * missing + text
    else:
        return text


def center_line(text, width):
    # Adds spaces on both sides so the text sits in the middle
    missing = width - visible_length(text)      # how many spaces are missing in total
    if missing <= 0:                            # none missing:
        return text
    left = missing // 2                         # half on the left (// = divide, no decimals)
    right = missing - left                      # the rest on the right
    return " " * left + text + " " * right


def cut(text, width):
    # Too long? Shorten it and end with "..."
    if len(text) <= width:
        return text
    else:
        return text[0:width - 3] + "..."        # the first letters + "..."


def turn_on_colors():
    # Windows only understands the colour codes after a switch is turned
    # on (Mac and Linux don't need it). Without it you'd see junk like [38;5;180m
    if os.name != "nt":                         # "nt" = Windows
        return                                  # not Windows: nothing to do
    try:
        import ctypes                           # ctypes lets Python talk to Windows itself
        kernel32 = ctypes.windll.kernel32                     # the part of Windows that runs the console
        screen_handle = kernel32.GetStdHandle(-11)            # -11 = the screen
        current_mode = ctypes.c_uint32()                      # an empty box for a number
        kernel32.GetConsoleMode(screen_handle, ctypes.byref(current_mode))   # read the screen's settings
        # "| 4" = keep every setting that is on, and ALSO switch on setting number 4 (the colour codes)
        kernel32.SetConsoleMode(screen_handle, current_mode.value | 4)
    except Exception:                           # anything went wrong:
        os.system("")                           # an old trick that also turns it on


# =====================================================================
#  PART 2: PIXEL PICTURES
#
#  THE PIXEL TRICK
#   One character on the screen is tall: about twice as high as it is wide.
#   The character ▀ only fills its TOP half. Give it a TEXT colour (red)
#   and a BACKGROUND colour (blue): the top half is red, the bottom half
#   is blue. That's TWO square pixels in ONE character!
#
#  WHAT A PICTURE IS
#   A picture is a dictionary:
#     picture['width'], picture['height']          its size in pixels
#     picture['pixels'][from_top][from_left]       the colour of one pixel
#   None = see-through (nothing there).
#     from_left = how many pixels from the LEFT edge   (0 = the left edge)
#     from_top  = how many pixels from the TOP edge    (0 = the top edge)
# =====================================================================
NO_BACKGROUND = "\x1b[49m"                 # the code for "no background colour"


def new_picture(width, height, color=None):
    # Makes an empty picture: 'height' rows, each with 'width' pixels
    pixels = []                                    # the list of rows
    for from_top in range(height):                 # make every row:
        row = []                                   # an empty row ...
        for from_left in range(width):             # ... gets 'width' pixels
            row.append(color)
        pixels.append(row)                         # add the finished row
    picture = {}                                   # the picture is a dictionary
    picture['width'] = width
    picture['height'] = height
    picture['pixels'] = pixels
    return picture


def set_pixel(picture, from_left, from_top, color):
    # Colours one pixel. Pixels off the edge are ignored.
    if color == None:                              # no colour = nothing to paint
        return
    if from_left < 0 or from_left >= picture['width']:     # off the left or right edge?
        return
    if from_top < 0 or from_top >= picture['height']:      # off the top or bottom edge?
        return
    picture['pixels'][from_top][from_left] = color         # paint it


def fill_box(picture, left, top, width, height, color):
    # Colours a whole rectangle. Its top-left corner is (left, top).
    for from_top in range(top, top + height):              # every row of the rectangle
        for from_left in range(left, left + width):        # every pixel along that row
            set_pixel(picture, from_left, from_top, color)


def draw_sprite(picture, sprite, left, top, colors):
    # A SPRITE is a small drawing written as letters, for example
    #     ".kk."        k = black, w = white, '.' = see-through
    #     "kwwk"
    # 'colors' is a dictionary that says which colour each letter is.
    # The sprite's top-left corner goes at (left, top).
    for row_number in range(len(sprite)):          # every row of the drawing
        row = sprite[row_number]                   # e.g. ".kk."
        for column_number in range(len(row)):      # every letter in that row
            letter = row[column_number]            # e.g. "k"
            if letter != "." and letter in colors: # not see-through, and we know its colour:
                set_pixel(picture, left + column_number, top + row_number, colors[letter])


def picture_to_lines(picture):
    # Turns a pixel picture into text: 2 pixels (one on top of the other)
    # become ONE character (the pixel trick above).
    lines = []                                     # the text lines we make
    from_top = 0
    while from_top < picture['height']:            # rows 0, 2, 4 ... (two at a time)
        line = ""                                  # this text line, built bit by bit
        last_code = ""                             # the colour code we sent last
        for from_left in range(picture['width']):  # every column:
            top = picture['pixels'][from_top][from_left]          # the upper pixel
            if from_top + 1 < picture['height']:                  # is there a row below?
                bottom = picture['pixels'][from_top + 1][from_left]   # the lower pixel
            else:
                bottom = None                                     # no: nothing below
            code = pixel_code(top, bottom)
            if code != last_code:                  # only send a code when the colour changes
                line = line + code
                last_code = code
            line = line + pixel_character(top, bottom)
        lines.append(line + RESET)                 # end the line with "normal colours"
        from_top = from_top + 2                    # the next pair of rows
    return lines


def pixel_code(top, bottom):
    # The colour code for one character made of 2 pixels
    if top == None and bottom == None:             # both empty
        return RESET
    if top == bottom:                              # both the same colour
        return back_color(top)
    if top == None:                                # only the bottom one
        return NO_BACKGROUND + text_color(bottom)
    if bottom == None:                             # only the top one
        return NO_BACKGROUND + text_color(top)
    return text_color(top) + back_color(bottom)    # two different colours


def pixel_character(top, bottom):
    # The character for one character made of 2 pixels
    if top == None and bottom == None:             # both empty: a space
        return " "
    if top == bottom:                              # same colour: a coloured space
        return " "
    if top == None:                                # only the bottom one: ▄
        return "▄"
    return "▀"                                     # the top one (and maybe the bottom): ▀


# =====================================================================
#  PART 3: SHOWING A SCREEN
# =====================================================================
CLEAR_EVERYTHING = "\x1b[2J\x1b[3J\x1b[H"   # erase the screen + the scroll history, go to the top-left
GO_TO_TOP_LEFT = "\x1b[H"                  # move the cursor to the top-left corner
ERASE_REST_OF_LINE = "\x1b[K"              # rub out everything to the right of the cursor
ERASE_EVERYTHING_BELOW = "\x1b[J"          # rub out everything below the cursor
SHOW_CURSOR = "\x1b[?25h"                  # show the blinking cursor again
NEXT_LINE = "\r\n"                         # \r = back to the left edge, \n = one line down

# Things this file remembers about the last screen it showed
# (ask and ask_in_box use them to put your typing in the right spot)
left_margin = 0          # how many spaces the last screen was pushed right (to centre it)
top_margin = 0           # how many empty lines are above the last screen
lines_drawn = 0          # how many lines are REALLY on the screen now (maybe fewer, if it was cut)
last_screen = []         # the last screen that will get a question under it


def move_cursor_to(line, column):
    # The code that jumps the cursor to a spot: "\x1b[12;40H" = line 12, column 40
    return "\x1b[" + str(line) + ";" + str(column) + "H"


def setup_window():
    # main.py calls this first.
    # STEP 1: let Python print the block characters ▀ ▄ █ ╔
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass                                   # a very old Python: just carry on

    # STEP 2: IDLE can't show colours, so warn about it
    if "idlelib" in sys.modules or sys.stdout.isatty() == False:
        print("CHESS BOMB needs a real terminal (not IDLE) to show colours.")
        print("Open Command Prompt / PowerShell / Windows Terminal in this folder and type:")
        print("    python main.py")
        input("Press Enter to try anyway...")

    # STEP 3: switch the colours on
    turn_on_colors()

    # STEP 4: ask for a 192 x 54 window
    if os.name == "nt":                                   # "nt" = Windows
        # "mode con" only works well in the OLD black Command Prompt window.
        # Inside VS Code or Windows Terminal it would make the game THINK the
        # window is 192 x 54 while you really see a smaller one, so there we skip it.
        inside_vs_code = False
        if os.environ.get("TERM_PROGRAM") == "vscode":    # VS Code sets this
            inside_vs_code = True
        inside_windows_terminal = False
        if "WT_SESSION" in os.environ:                    # Windows Terminal sets this
            inside_windows_terminal = True
        if inside_vs_code == False and inside_windows_terminal == False:   # the old black window:
            # os.system runs a command, like typing it yourself: "make the window 192 x 54"
            os.system("mode con: cols=" + str(SCREEN_COLUMNS) + " lines=" + str(SCREEN_LINES))
        os.system("title CHESS BOMB")                     # the name on top of the window
    else:                                                 # Mac or Linux:
        # a terminal command that asks for a window of 54 lines x 192 columns
        sys.stdout.write("\x1b[8;" + str(SCREEN_LINES) + ";" + str(SCREEN_COLUMNS) + "t")
    sys.stdout.flush()


def present(lines, extra_below=1, clear=True):
    #   lines        = the screen, one text line per item
    #   extra_below  = how many lines will be printed after it (a question)
    #   clear=False  = paint OVER the old screen instead of erasing first
    #                  (that's how animations avoid flickering)
    global left_margin, top_margin, lines_drawn    # these 3 are changed for the whole file
    if extra_below > 0:                        # a question will be asked under it:
        remember_screen(lines)                 # remember it, so ask() can show it again

    # STEP 1: how wide is the widest line?
    widest = 0
    for line in lines:
        if visible_length(line) > widest:
            widest = visible_length(line)

    # STEP 2: how big is the window RIGHT NOW? (if it can't be measured: 192 x 54)
    # It's measured before every screen, so zooming in or out is noticed at once.
    size = shutil.get_terminal_size((SCREEN_COLUMNS, SCREEN_LINES))

    # STEP 3: THE SAFETY NET
    # Is the screen bigger than the window (too wide OR too tall)?
    # Then cut off what doesn't fit, instead of letting long lines wrap
    # onto the next line (that bends the picture and scrolls the screen).
    # We keep 1 column free on the right, because some Windows terminals
    # jump to the next line as soon as you print in the very last column.
    room_across = size.columns - 1                   # the columns we may use
    room_down = size.lines - extra_below             # the lines we may use (minus the question)
    if widest > room_across or len(lines) > room_down:
        lines = shrink_to_window(lines, room_across, room_down)    # cut it to fit
        if widest > room_across:
            widest = room_across                     # now it's only this wide

    # STEP 4: the empty space that centres the screen
    left_margin = (size.columns - widest) // 2
    if left_margin < 0:
        left_margin = 0
    top_margin = (size.lines - len(lines) - extra_below) // 2
    if top_margin < 0:
        top_margin = 0

    # STEP 5: build everything into ONE piece of text and print it at once
    if clear == True:                                # a brand-new screen:
        output = RESET + CLEAR_EVERYTHING            # erase everything first
    else:                                            # an animation frame:
        output = RESET + GO_TO_TOP_LEFT              # just go back to the top-left
    for empty_line in range(top_margin):             # the empty lines above
        output = output + ERASE_REST_OF_LINE + NEXT_LINE
    spaces = " " * left_margin                       # the empty space on the left
    for number in range(len(lines)):                 # every line of the screen:
        output = output + spaces + lines[number] + RESET + ERASE_REST_OF_LINE
        if number < len(lines) - 1:                  # not the last line:
            output = output + NEXT_LINE              # go down to the next line
    if extra_below > 0:                              # room for a question below:
        output = output + NEXT_LINE
    output = output + ERASE_EVERYTHING_BELOW         # rub out leftovers of the old screen
    sys.stdout.write(output)                         # print it all ...
    sys.stdout.flush()                               # ... right now
    lines_drawn = len(lines)                         # remember how many lines are really on screen


def shrink_to_window(lines, width, height):
    # The safety net: makes the screen fit a smaller window.
    #  - Too tall? Keep the BOTTOM lines (that's where you type) and
    #    drop the lines at the top that don't fit.
    #  - Too wide? Cut every line to the window width (cut_keeping_colors).
    if height < 1:
        height = 1                                   # always keep at least 1 line
    if width < 1:
        width = 1                                    # and at least 1 column
    first_kept_line = len(lines) - height            # the first line that still fits
    if first_kept_line < 0:
        first_kept_line = 0                          # it all fits from the top
    result = []
    for number in range(first_kept_line, len(lines)):    # from the first kept line to the last:
        result.append(cut_keeping_colors(lines[number], width))
    return result


def cut_keeping_colors(text, width):
    # Cuts a line to 'width' letters, like scissors.
    # The colour codes take no room on the screen, so they are KEPT and
    # not counted; only the letters you can see are counted.
    if visible_length(text) <= width:                # it already fits:
        return text                                  # give it back as it is
    result = ""                                      # the cut line, built bit by bit
    shown = 0                                        # how many visible letters are in it so far
    inside_a_code = False                            # are we in the middle of a colour code?
    for letter in text:                              # look at every letter:
        if letter == "\x1b":                         # ESC: a colour code starts here
            inside_a_code = True
            result = result + letter                 # keep it (it takes no room)
        elif inside_a_code == True:                  # inside a colour code:
            result = result + letter                 # keep it too
            if letter.isalpha():                     # a letter (like the m) ends the code
                inside_a_code = False
        elif shown < width:                          # a visible letter, and there's still room:
            result = result + letter
            shown = shown + 1
        # a visible letter with NO room left: it is simply left out
    return result + RESET                            # end with "normal colours"


def remember_screen(lines):
    # Keeps a copy of the screen, so a question can be added under it later
    global last_screen
    last_screen = []
    for line in lines:
        last_screen.append(line)


def restore_window():
    # Back to a normal-looking terminal: normal colours, cursor on, screen erased
    sys.stdout.write(RESET + SHOW_CURSOR + "\x1b[2J" + GO_TO_TOP_LEFT)
    sys.stdout.flush()


# =====================================================================
#  PART 4: ASKING A QUESTION
#  Python's input("") waits until the player presses Enter and gives
#  back what they typed.
# =====================================================================
def ask(question):
    # Shows the last screen with the question on the line under it
    screen = []
    for line in last_screen:
        screen.append(line)
    screen.append(question + " ")
    present(screen, extra_below=0)
    return read_answer()


def ask_in_box(lines, column):
    # Shows the screen and lets the player type INSIDE the chess-clock box
    # (the box's typing line is the 2nd line from the bottom of the screen).
    #   column = how many characters from the left of the screen the typing starts
    remember_screen(lines)
    present(lines, extra_below=0)
    line_on_screen = top_margin + lines_drawn - 1           # the 2nd line from the bottom (of what's really on screen)
    column_on_screen = left_margin + column + 1             # the spot inside the box
    sys.stdout.write(move_cursor_to(line_on_screen, column_on_screen))   # put the cursor there
    return read_answer()


def wait_for_enter(message="Press Enter to continue..."):
    # Shows "Press Enter to continue..." in grey and waits for Enter
    ask(paint(message, 250))


def read_answer():
    # Waits for Enter. Gives back what was typed, in small letters,
    # without spaces at the ends ("  B2 " -> "b2").
    sys.stdout.flush()                       # make sure everything is on the screen first
    typed = input("")                        # wait for the player to type and press Enter
    sound.play_sound('select')               # a little "click"
    typed = typed.strip()                    # remove spaces at the ends
    typed = typed.lower()                    # small letters
    return typed
