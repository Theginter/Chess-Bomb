import time      # time.sleep = wait a moment between frames
import random    # random = dice rolls, for sparkles and fire
from display import present, wait_for_enter                                   # showing screens (display.py)
from display import new_picture, set_pixel, fill_box, draw_sprite, picture_to_lines   # pixel pictures (display.py)
from display import paint, center_line                                        # colours and lining up text (display.py)
import art                                            # every drawing (art.py)
from sound import play_sound, play_jingle, play_music # sounds and music (sound.py)

# =====================================================================
#  FILE 5 of 11:  ANIMATIONS.PY  -  EVERY MOVING PICTURE IN THE GAME
#
#  HOW AN ANIMATION WORKS
#   An animation is a FLIP BOOK. We draw a pixel picture (a frame),
#   show it, wait a tiny bit (time.sleep), then draw the next frame a
#   little different and show it on top of the old one, and so on.
#
#   Every frame is drawn the same way:
#     1) picture = new_picture(...)       an empty picture
#     2) fill_box / draw_sprite / set_pixel   paint things on it
#     3) show_frame(picture, ...)          show it, then wait a moment
#
#  WHERE THINGS ARE: from_left and from_top
#   A picture is like squared paper. (0, 0) is the top-left corner.
#     from_left = how many pixels from the LEFT edge
#     from_top  = how many pixels from the TOP edge
#
#  HOW WE DRAW A CIRCLE (WITHOUT ANY HARD MATHS)
#   A pixel is inside a circle when it is close enough to the middle.
#   "Close enough" is checked with Pythagoras, but WITHOUT the square root:
#       across = how far right of the middle      (from_left - middle_left)
#       down   = how far below the middle         (from_top - middle_top)
#       inside the circle if:  across * across + down * down <= radius * radius
#
#  HOW THINGS FLY OUT IN A CIRCLE
#   CIRCLE_POINTS is a list of 14 spots on a circle around the middle,
#   10 pixels away: (how far right, how far down). Fireworks and
#   sparkles fly out toward these spots. To put a spark 20 pixels out
#   instead of 10, we use the spot x 20 // 10.
#
#  IN THE ORDER YOU SEE THEM
#   1) play_intro                RSMRV PRODUCTIONS presents ... CHESS BOMB
#   2) play_bomb_animation       BOOM! (someone flipped a bomb)
#   3) play_heal_animation       +1 HP (someone flipped an extra life)
#   4) play_overflow_animation   OVERFLOW! (lightning)
#   5) play_scan_animation       the Sacrifice Scan radar
#   6) play_victory_animation    trophy + fireworks
#   7) play_unlock_animation     NEW MINI GAME! (a lock shakes and opens)
#   8) the 3 mini game intros    racing knights, ticking bomb, spinning king
#      ... and at the bottom the small helpers they all share.
# =====================================================================

INTRO_WIDTH = 140            # the intro pictures are 140 x 64 pixels
INTRO_HEIGHT = 64
WIDE_WIDTH = 160             # the unlock and mini game intro pictures are 160 x 64
WIDE_HEIGHT = 64

# 14 spots on a circle, 10 pixels from the middle: (how far right, how far down)
CIRCLE_POINTS = [(10, 0), (9, 4), (6, 8), (2, 10), (-2, 10), (-6, 8), (-9, 4),
                 (-10, 0), (-9, -4), (-6, -8), (-2, -10), (2, -10), (6, -8), (9, -4)]


# =====================================================================
#  1) THE INTRO:  RSMRV PRODUCTIONS presents... CHESS BOMB
#  A short "movie trailer" in 3 parts (about 10 seconds).
# =====================================================================
def play_intro():
    play_music('intro', False)              # the intro song, played once
    intro_logo()                            # part 1
    intro_trailer()                         # part 2
    intro_title()                           # part 3


# How far along the flying pixels are in each frame, in percent.
# They move FAST at first and slow down at the end, for a soft landing.
LOGO_PROGRESS = [0, 17, 32, 45, 56, 66, 74, 81, 87, 91, 94, 96, 98, 99, 100]


def intro_logo():
    # PART 1: hundreds of pixels fly in and build the letters R S M R V
    dice = random.Random(5)                  # a dice that rolls the same numbers every time

    # The finished logo: where every pixel must land
    target = new_picture(INTRO_WIDTH, INTRO_HEIGHT)
    text_in_middle(target, "RSMRV", 12, art.PURPLE, 4, 54)

    # Every pixel of the logo gets a random starting spot above or below
    # the screen. Each flying pixel is a list:
    #   [start_left, start_top, end_left, end_top, colour]
    flying = []
    for from_top in range(INTRO_HEIGHT):                 # every pixel of the logo picture:
        for from_left in range(INTRO_WIDTH):
            color = target['pixels'][from_top][from_left]
            if color != None:                            # only pixels that are part of the logo
                start_left = dice.randint(0, INTRO_WIDTH - 1)          # a random spot left-to-right
                if dice.randint(0, 1) == 0:                            # flip a coin:
                    start_top = dice.randint(-30, -1)                  # above the screen ...
                else:
                    start_top = dice.randint(INTRO_HEIGHT, INTRO_HEIGHT + 30)   # ... or below it
                flying.append([start_left, start_top, from_left, from_top, color])

    # One frame for every number in LOGO_PROGRESS
    for percent in LOGO_PROGRESS:
        picture = new_picture(INTRO_WIDTH, INTRO_HEIGHT)
        for pixel in flying:
            # where it is now = its start + (the whole trip x percent / 100)
            from_left = pixel[0] + (pixel[2] - pixel[0]) * percent // 100
            from_top = pixel[1] + (pixel[3] - pixel[1]) * percent // 100
            set_pixel(picture, from_left, from_top, pixel[4])
        show_frame(picture, "", 231, 0.06)

    # A flash of white light ...
    show_frame(new_picture(INTRO_WIDTH, INTRO_HEIGHT, 231), "", 231, 0.05)

    # ... then the word PRODUCTIONS types itself out, one more letter each frame
    word = "PRODUCTIONS"
    for letters in range(len(word) + 1):                 # 0, 1, 2 ... 11 letters
        picture = new_picture(INTRO_WIDTH, INTRO_HEIGHT)
        text_in_middle(picture, "RSMRV", 12, art.PURPLE, 4, 54)
        word_left = (INTRO_WIDTH - art.text_width(word, 1)) // 2
        art.draw_text(picture, word[0:letters], word_left, 46, art.GOLD, 1)   # e.g. "PROD"
        for sparkle in range(12):                        # 12 random twinkles
            sparkle_left = dice.randint(0, INTRO_WIDTH - 1)
            sparkle_top = dice.randint(0, INTRO_HEIGHT - 1)
            set_pixel(picture, sparkle_left, sparkle_top, dice.choice([231, 225, 219]))
        if letters > 0:
            play_sound('tick')                           # a "tick" for every new letter
        show_frame(picture, "", 231, 0.07)
    show_frame(picture, "p r e s e n t s", 250, 1.4)    # the last frame + "presents"


def intro_trailer():
    # PART 2: four quick scenes, like a game preview

    # Scene A: a bomb falls from the sky and hides under a pawn
    for step in range(10):                               # 10 frames
        picture = new_picture(INTRO_WIDTH, INTRO_HEIGHT)
        left = draw_pawn_row(picture, art.WHITE_PIECE, [0, 2, 4])   # 5 squares, white pawns on squares 0, 2 and 4
        bomb_top = step * 5 - 6                          # it falls 5 pixels a frame ...
        if bomb_top > 40:
            bomb_top = 40                                # ... and stops at the board
        draw_sprite(picture, art.BOMB_16, left + 16, bomb_top, art.BOMB_COLORS)   # above square 2
        show_frame(picture, "HIDE YOUR BOMBS...", 203, 0.06)
    show_frame(picture, "HIDE YOUR BOMBS...", 203, 0.8)  # hold the last frame

    # Scene B: the middle enemy pawn flips over (thinner, then wider) and shows an extra life
    for step in range(12):                               # 12 frames
        picture = new_picture(INTRO_WIDTH, INTRO_HEIGHT)
        left = draw_pawn_row(picture, art.BLACK_PIECE, [0, 1, 3, 4])  # black pawns, the middle square (2) empty
        if step < 6:
            # the first 6 frames: the pawn gets thinner (16, 13, 11 ... pixels wide)
            sprite = squish(art.PAWN_16, 16 - step * 16 // 6)
            colors = art.BLACK_PIECE
        else:
            # the last 6 frames: the extra life gets wider
            sprite = squish(art.LIFE_16, (step - 5) * 16 // 6)
            colors = art.LIFE_COLORS
        draw_sprite(picture, sprite, left + 32, 40, colors)   # on the middle square
        if step == 6:
            play_sound('flip')                           # half-way through the flip
        show_frame(picture, "FLIP THE ENEMY PAWNS...", 231, 0.06)
    play_sound('heal')
    show_frame(picture, "FIND AN EXTRA LIFE...", 120, 0.9)

    # Scene C: ...or blow up!
    dice = random.Random(3)                              # the same fire every time
    play_sound('boom')
    for step in range(7):                                # 7 frames of a growing fireball
        picture = explosion_picture(INTRO_WIDTH, INTRO_HEIGHT, INTRO_WIDTH // 2, 40, 4 + step * 6, step, dice)
        show_frame(picture, "...OR BLOW UP!", 208, 0.07)

    # Scene D: protect your king (lose a queen, then another)
    for health in [3, 2, 1]:                             # 3 HP, then 2, then 1
        picture = new_picture(INTRO_WIDTH, INTRO_HEIGHT)
        left_queen = art.CROWN_PLAYER_ONE                # all 3 bright ...
        right_queen = art.CROWN_PLAYER_ONE
        if health < 3:
            right_queen = art.CROWN_LOST                 # ... the right queen falls first ...
        if health < 2:
            left_queen = art.CROWN_LOST                  # ... then the left queen
        draw_sprite(picture, art.make_bigger(art.QUEEN_ICON, 3), 16, 12, left_queen)
        draw_sprite(picture, art.make_bigger(art.KING_ICON, 3), 54, 12, art.CROWN_PLAYER_ONE)
        draw_sprite(picture, art.make_bigger(art.QUEEN_ICON, 3), 92, 12, right_queen)
        if health < 3:
            play_sound('thud')                           # a crown was just lost
        show_frame(picture, "PROTECT YOUR KING!", 222, 0.7)


def intro_title():
    # PART 3: the title drops in and bounces, then GET READY... blinks
    bounce = [-30, -18, -8, 0, 4, 0, -2, 0]         # how far from its place, frame by frame
    for number in range(len(bounce)):               # one frame per number in the list
        picture = new_picture(INTRO_WIDTH, INTRO_HEIGHT)
        text_in_middle(picture, "CHESS", 8 + bounce[number], art.STEEL, 3, 238)   # comes from above
        text_in_middle(picture, "BOMB", 34 - bounce[number], art.FIRE, 3, 52)     # comes from below
        if number == 3:
            play_sound('boom')                      # the moment they hit their places
        show_frame(picture, "", 231, 0.06)
    for blink in range(6):                          # blink 6 times
        if blink % 2 == 0:                          # % 2 == 0 means "every other time"
            caption = "GET READY..."
        else:
            caption = ""                            # the other times: nothing (that's the blink)
        show_frame(picture, caption, 220, 0.45)


def draw_pawn_row(picture, colors, pawn_spots):
    # 5 chess squares in a row.
    # pawn_spots = the squares that get a pawn, e.g. [0, 2, 4]
    # Gives back where the row starts (left).
    left = (INTRO_WIDTH - 5 * 16) // 2               # the row in the middle of the picture
    for index in range(5):                           # every square:
        if index % 2 == 0:
            square_color = art.LIGHT_SQUARE          # light and dark squares take turns
        else:
            square_color = art.DARK_SQUARE
        fill_box(picture, left + index * 16, 40, 16, 16, square_color)
        if index in pawn_spots:
            draw_sprite(picture, art.PAWN_16, left + index * 16, 40, colors)
    return left


def squish(sprite, new_width):
    # Makes a 16-wide drawing thinner (new_width = 16 is normal, 8 is half,
    # 0 is a thin line), so it looks like a coin being flipped over.
    # It keeps some letters of each row and skips the others, with
    # see-through '.' on both sides so the drawing stays in the middle.
    if new_width < 1:
        new_width = 1                               # at least 1 pixel wide
    empty_left = (16 - new_width) // 2              # see-through space on the left
    empty_right = 16 - empty_left - new_width       # ... and on the right
    squished = []
    for row in sprite:                              # every row of the drawing:
        new_row = "." * empty_left
        for column in range(new_width):             # every letter of the thinner row:
            old_column = column * 16 // new_width   # which old letter goes here
            new_row = new_row + row[old_column]
        squished.append(new_row + "." * empty_right)
    return squished


# =====================================================================
#  2) BOOM  (someone flipped a bomb)
#   - 4 frames of the bomb with its fuse flickering
#   - 7 frames of a growing fireball
#   - 4 frames of smoke clearing, then the word BOOM!
# =====================================================================
def play_bomb_animation(caption="BOOM!  -1 HP"):
    play_sound('boom')
    dice = random.Random()                         # a dice (different every time)
    big_bomb = art.make_bigger(art.BOMB_16, 2)     # the bomb, twice as big

    for flicker in range(4):                       # the fuse sparkles
        picture = new_picture(100, 48)
        if flicker % 2 == 0:                       # every other frame: yellow and orange swap
            draw_sprite(picture, big_bomb, 34, 4, art.BOMB_COLORS)
        else:
            draw_sprite(picture, big_bomb, 34, 4, art.BOMB_COLORS_SWAPPED)
        show_frame(picture, "", 231, 0.07)

    for step in range(7):                          # the blast grows 5 pixels a frame
        picture = explosion_picture(100, 48, 50, 20, 4 + step * 5, step, dice)
        show_frame(picture, "", 231, 0.07)

    for fade in range(4):                          # the smoke clears: fewer grey dots each frame
        picture = new_picture(100, 48)
        for from_top in range(48):                 # every pixel:
            for from_left in range(100):
                across = from_left - 50
                down = from_top - 20
                if across * across + down * down <= 38 * 38:     # within 38 pixels of the middle?
                    if dice.randint(1, 100) <= 55 - fade * 12:   # a smaller chance every frame
                        set_pixel(picture, from_left, from_top, dice.choice([236, 238, 240, 242]))
        if fade == 3:                              # the last frame: the word BOOM!
            text_in_middle(picture, "BOOM!", 10, art.FIRE, 3, 52)
            show_frame(picture, caption, 203, 1.1)
        else:
            show_frame(picture, "", 231, 0.07)


# =====================================================================
#  3) EXTRA LIFE FOUND  (+1 HP)
#   The extra life blinks while sparkles fly out around it in a ring
# =====================================================================
def play_heal_animation(caption="EXTRA LIFE!  +1 HP"):
    play_sound('heal')
    dice = random.Random()                         # a dice (different every time)
    big_life = art.make_bigger(art.LIFE_16, 2)     # the extra life, twice as big
    bright_green = {'o': 28, 'g': 40, 'h': 157, 'w': 231}
    for step in range(8):                          # 8 frames
        picture = new_picture(100, 52)
        if step % 2 == 0:                          # normal green and bright green take turns
            draw_sprite(picture, big_life, 34, 0, art.LIFE_COLORS)
        else:
            draw_sprite(picture, big_life, 34, 0, bright_green)

        # Sparkles on a ring around the extra life. The ring gets bigger every frame.
        inner = 18 + step * 2                      # the inside edge of the ring
        outer = inner + 4                          # the outside edge
        sparkles = 0
        while sparkles < 10 + step * 3:            # more sparkles every frame
            from_left = dice.randint(0, 99)        # try a random spot ...
            from_top = dice.randint(0, 51)
            across = from_left - 50
            down = from_top - 16
            distance = across * across + down * down
            if distance >= inner * inner and distance <= outer * outer:   # ... is it on the ring?
                set_pixel(picture, from_left, from_top, dice.choice([231, 194, 157, 120]))
                sparkles = sparkles + 1

        if step >= 4:                              # from frame 4 on: "+1 HP"
            text_in_middle(picture, "+1 HP", 36, art.MINT, 2, 22)
            show_frame(picture, caption, 157, 0.11)
        else:
            show_frame(picture, "", 231, 0.11)
    time.sleep(0.9)                                # keep the last frame up a moment


# =====================================================================
#  4) OVERFLOW  (found an extra life while already at full HP)
#   A big lightning bolt, small random lightning, and the sky flashing
# =====================================================================
def play_overflow_animation(caption="OVERFLOW!  THE ENEMY TAKES 1 DAMAGE!"):
    play_sound('zap')
    dice = random.Random()
    bolt = art.make_bigger(art.LIGHTNING_12, 3)    # the lightning bolt, 3 times bigger
    for step in range(9):                          # 9 frames
        picture = new_picture(120, 52)
        if step % 3 == 1:                          # every 3rd frame:
            fill_box(picture, 0, 0, 120, 34, 17)   # a flash of dark blue sky
        for line in range(3):                      # 3 little lightning lines
            from_left = dice.randint(4, 116)       # each starts at a random spot at the top
            for from_top in range(32):             # and zig-zags down 32 pixels
                set_pixel(picture, from_left, from_top, dice.choice([117, 159, 231]))
                from_left = from_left + dice.choice([-1, 0, 1])   # a step left, none, or right
        if step % 2 == 1:
            draw_sprite(picture, bolt, 42, 2, {'y': 231})   # the bolt flashes white ...
        else:
            draw_sprite(picture, bolt, 42, 2, {'y': 226})   # ... and yellow
        if step >= 4:                              # from frame 4 on: the word OVERFLOW!
            text_in_middle(picture, "OVERFLOW!", 37, art.ICE, 2, 18)
            show_frame(picture, caption, 159, 0.09)
        else:
            show_frame(picture, "", 231, 0.09)
    time.sleep(1.0)


# =====================================================================
#  5) SACRIFICE SCAN  (a radar sweep)
#   A green circle with a line that turns round, like a radar screen.
#   RADAR_ENDS = where the end of the line is in each of the 12 frames
#   (how far right, how far down from the middle): one full turn.
# =====================================================================
RADAR_ENDS = [(17, 0), (15, 8), (9, 15), (0, 17), (-8, 15), (-15, 8),
              (-17, 0), (-15, -8), (-9, -15), (0, -17), (9, -15), (15, -9)]


def play_scan_animation(caption="SCAN COMPLETE"):
    play_sound('scan')
    for step in range(12):                         # 12 frames
        picture = new_picture(100, 52)
        draw_radar_circle(picture)                 # the dark green circle with 2 rings

        # Where was the line 1 and 2 frames ago? (before frame 0 comes frame 11)
        one_ago = step - 1
        if one_ago < 0:
            one_ago = one_ago + 12
        two_ago = step - 2
        if two_ago < 0:
            two_ago = two_ago + 12

        # The glowing tail behind the line: the space between where the line
        # was 1 frame ago and where it is now, filled with lines in green
        draw_radar_wedge(picture, RADAR_ENDS[two_ago], RADAR_ENDS[one_ago], 22)   # older: dark green
        draw_radar_wedge(picture, RADAR_ENDS[one_ago], RADAR_ENDS[step], 28)      # newer: green
        draw_radar_line(picture, RADAR_ENDS[step], 120)                           # the line now: bright green

        if step >= 6:                              # from frame 6 on: the word SCAN
            text_in_middle(picture, "SCAN", 38, art.MINT, 2, 22)
            show_frame(picture, caption, 120, 0.08)
        else:
            show_frame(picture, "", 231, 0.08)
    time.sleep(1.2)


def draw_radar_circle(picture):
    # A dark green circle (middle 50, 18 - radius 17) with an outer and an inner ring
    for from_top in range(36):
        for from_left in range(100):
            across = from_left - 50
            down = from_top - 18
            distance = across * across + down * down
            if distance <= 17 * 17:                      # inside the circle
                set_pixel(picture, from_left, from_top, 22)      # dark green
            if distance >= 16 * 16 and distance <= 17 * 17:      # the outer ring
                set_pixel(picture, from_left, from_top, 34)
            if distance >= 8 * 8 and distance <= 9 * 9:          # the inner ring
                set_pixel(picture, from_left, from_top, 34)


def draw_radar_wedge(picture, start_end, finish_end, color):
    # Fills the space between two radar lines: 6 lines in between,
    # each one a bit further from the first line toward the second.
    for part in range(7):                          # part 0, 1 ... 6
        end_right = start_end[0] + (finish_end[0] - start_end[0]) * part // 6
        end_down = start_end[1] + (finish_end[1] - start_end[1]) * part // 6
        draw_radar_line(picture, (end_right, end_down), color)


def draw_radar_line(picture, end, color):
    # A line from the middle (50, 18) to the end point, drawn dot by dot
    for step in range(18):                         # 18 dots along the line
        from_left = 50 + end[0] * step // 17       # end[0] = how far right
        from_top = 18 + end[1] * step // 17        # end[1] = how far down
        set_pixel(picture, from_left, from_top, color)


# =====================================================================
#  6) VICTORY  (trophy + fireworks)
#   Each firework is a list:  [from_left, from_top, age, colour]
#   Every frame it gets older (age + 1): its 14 sparks fly further out
#   in a circle (CIRCLE_POINTS), turn grey when it gets old, and after
#   6 frames it's gone.
# =====================================================================
def play_victory_animation(caption="VICTORY ROYALE!"):
    play_jingle('victory')
    dice = random.Random()
    trophy = art.make_bigger(art.TROPHY_16, 2)      # the trophy, twice as big
    fireworks = []                                  # the fireworks in the sky right now
    for step in range(16):                          # 16 frames
        picture = new_picture(120, 56)
        if step % 2 == 0:                           # a new firework every 2 frames
            new_left = dice.randint(8, 112)         # a random spot ...
            new_top = dice.randint(4, 24)           # ... in the sky
            new_color = dice.choice([196, 46, 51, 201, 226, 208])   # a random colour
            fireworks.append([new_left, new_top, 0, new_color])

        still_burning = []                          # the fireworks that stay for the next frame
        for firework in fireworks:                  # draw every firework:
            if firework[2] < 4:                     # young: its own colour
                spark_color = firework[3]
            else:
                spark_color = 240                   # old: grey
            spread = firework[2] * 2                # older = the sparks are further out
            for point in CIRCLE_POINTS:             # 14 sparks in a circle
                spark_left = firework[0] + point[0] * spread // 10
                spark_top = firework[1] + point[1] * spread // 10
                set_pixel(picture, spark_left, spark_top, spark_color)
            firework[2] = firework[2] + 1           # one frame older
            if firework[2] < 6:                     # younger than 6: it stays
                still_burning.append(firework)
        fireworks = still_burning

        draw_sprite(picture, trophy, 44, 2, art.GOLD_COLORS)          # the trophy on top
        text_in_middle(picture, "VICTORY", 38, art.GOLD, 2, 94)       # and the word VICTORY
        show_frame(picture, caption, 222, 0.09)
    time.sleep(1.3)


# =====================================================================
#  7) NEW MINI GAME UNLOCKED!
#   Plays when you beat a level that opens a mini game.
#    1) a big golden lock shakes          (the "tick tick" sound)
#    2) the top of the lock pops open     (zap!)
#    3) a white flash
#    4) the lock falls away, gold sparkles fly out, and the mini game's
#       picture grows in the middle
#    5) "NEW MINI GAME!" and its name flash in big letters
# =====================================================================
LOCK_TOP = art.make_bigger(art.LOCK_12[0:5], 3)     # rows 0-4 of the lock, 3 times bigger: the bent bar on top
LOCK_BODY = art.make_bigger(art.LOCK_12[5:14], 3)   # rows 5-13: the box with the keyhole


def play_unlock_animation(game_name):
    # game_name = "RACING PIECE", "TICK TOCK" or "FLIP THE KING"
    # Which picture goes with the name?
    match game_name:
        case "RACING PIECE":
            icon = art.KNIGHT_16_RIGHT
            icon_colors = art.KNIGHT_COLORS[0]       # a red knight
        case "TICK TOCK":
            icon = art.BOMB_16
            icon_colors = art.BOMB_COLORS
        case _:
            icon = art.KING_0
            icon_colors = art.KING_COLORS

    # 1) THE LOCK SHAKES: pushed left and right a little each frame
    shakes = [0, -2, 2, -3, 3, -2, 2, -1, 1, 0]
    for push in shakes:
        picture = new_picture(WIDE_WIDTH, WIDE_HEIGHT, 233)    # 233 = very dark grey
        draw_lock(picture, push, 0, 0)
        play_sound('tick')
        show_frame(picture, "?  ?  ?", 244, 0.08)

    # 2) THE TOP POPS OPEN: the bent bar rises a bit more each frame
    play_sound('zap')
    for lift in [3, 6, 9, 10]:
        picture = new_picture(WIDE_WIDTH, WIDE_HEIGHT, 233)
        draw_lock(picture, 0, lift, 0)
        show_frame(picture, "CLICK!", 222, 0.07)

    # 3) WHITE FLASH: white, cream, then yellow
    for flash_color in [231, 229, 222]:
        show_frame(new_picture(WIDE_WIDTH, WIDE_HEIGHT, flash_color), "", 231, 0.05)

    # 4) THE LOCK FALLS, SPARKLES FLY OUT, THE MINI GAME APPEARS
    play_sound('coin')
    dice = random.Random(7)                         # the same sparkles every time
    sparkles = []                                   # each: [which circle point, speed]
    for number in range(40):
        sparkles.append([dice.randint(0, 13), dice.randint(15, 40)])
    for step in range(12):                          # 12 frames
        picture = new_picture(WIDE_WIDTH, WIDE_HEIGHT, 233)
        draw_lock(picture, 0, 10 + step * 2, step * step)    # step x step: falls faster and faster
        for sparkle in sparkles:                    # every sparkle flies outward
            point = CIRCLE_POINTS[sparkle[0]]       # the direction it flies in
            distance = sparkle[1] * step // 10      # speed x frames (speed 15 = 1.5 pixels a frame)
            sparkle_left = 80 + point[0] * distance * 2 // 10   # (x 2: they spread wider than tall)
            sparkle_top = 32 + point[1] * distance // 10
            set_pixel(picture, sparkle_left, sparkle_top, art.GOLD[step % 7])   # a different gold each frame
        if step < 4:
            size = 1                                # the mini game's picture grows:
        else:
            size = 2                                # 1 x, then 2 x as big
        big_icon = art.make_bigger(icon, size)
        draw_sprite(picture, big_icon, 80 - len(big_icon[0]) // 2, 32 - len(big_icon) // 2, icon_colors)
        show_frame(picture, "", 231, 0.07)

    # 5) "NEW MINI GAME!" on top, the picture, and the name flashing gold / fire
    play_jingle('victory')
    big_icon = art.make_bigger(icon, 2)
    for step in range(8):                           # 8 frames
        picture = new_picture(WIDE_WIDTH, WIDE_HEIGHT, 233)
        text_in_middle(picture, "NEW MINI GAME!", 2, art.MINT, 1, 22)
        draw_sprite(picture, big_icon, 80 - len(big_icon[0]) // 2, 12 + (34 - len(big_icon)) // 2, icon_colors)
        if step % 2 == 0:                           # the name switches colour every frame
            text_in_middle(picture, game_name, WIDE_HEIGHT - 16, art.GOLD, 2, 94)
        else:
            text_in_middle(picture, game_name, WIDE_HEIGHT - 16, art.FIRE, 2, 94)
        show_frame(picture, "Find it in [4] MINI GAMES on the main menu", 250, 0.12)
    wait_for_enter()                                # "Press Enter to continue..."


def draw_lock(picture, push_sideways, top_lift, body_drop):
    # push_sideways = how far the whole lock is pushed sideways (shaking)
    # top_lift      = how high the top bar has popped up
    # body_drop     = how far the lock has fallen down
    left = (WIDE_WIDTH - len(LOCK_BODY[0])) // 2 + push_sideways     # centred, then pushed sideways
    top = 12 + body_drop                                             # 12 from the top, then dropped
    draw_sprite(picture, LOCK_TOP, left, top - top_lift, art.LOCK_COLORS)            # the bar (lifted)
    draw_sprite(picture, LOCK_BODY, left, top + len(LOCK_TOP), art.LOCK_COLORS)      # the box below it


# =====================================================================
#  8) THE MINI GAME INTROS
#   Each one: a short scene -> its name flashes on a dark strip ->
#   chess squares sweep across the screen (the "chessboard wipe")
# =====================================================================
def play_racing_intro():
    # The four knights gallop across, then "RACING PIECE" flashes
    dice = random.Random(4)                         # the same race every time
    # How fast each knight gallops, in tenths of a pixel per frame (30 = 3 pixels)
    speeds = [dice.randint(30, 55), dice.randint(30, 55), dice.randint(30, 55), dice.randint(30, 55)]

    for step in range(30):                          # 30 frames of galloping
        picture = new_picture(WIDE_WIDTH, WIDE_HEIGHT)
        for lane in range(4):                       # every lane:
            fill_box(picture, 0, lane * 16, WIDE_WIDTH, 16, art.lane_color(lane))   # the ground
            art.draw_finish_line(picture, WIDE_WIDTH - 10, WIDE_WIDTH - 4, lane * 16, lane * 16 + 16)
            knight_left = -16 + speeds[lane] * step // 10
            if knight_left > WIDE_WIDTH - 26:
                knight_left = WIDE_WIDTH - 26       # it stops at the finish
            draw_sprite(picture, art.KNIGHT_16_RIGHT, knight_left, lane * 16, art.KNIGHT_COLORS[lane])
        if step == 0:
            play_sound('go')                        # the start
        elif step % 3 == 0:
            play_sound('step')                      # hoof sounds every 3rd frame
        show_frame(picture, "", 231, 0.07)

    for flash in range(10):                         # the title flashes 10 times
        picture = new_picture(WIDE_WIDTH, WIDE_HEIGHT)
        for lane in range(4):                       # the knights stand at the finish
            fill_box(picture, 0, lane * 16, WIDE_WIDTH, 16, art.lane_color(lane))
            draw_sprite(picture, art.KNIGHT_16_RIGHT, WIDE_WIDTH - 26, lane * 16, art.KNIGHT_COLORS[lane])
        flash_title(picture, "RACING PIECE", flash)
    chessboard_wipe(picture)


def play_tick_tock_intro():
    # A big bomb counts down 3... 2... 1... then "TICK TOCK" flashes
    big_bomb = art.make_bigger(art.BOMB_16, 3)      # the bomb, 3 times bigger
    for number in ["3", "2", "1"]:                  # count down ...
        play_sound('tick')
        for flicker in range(5):                    # ... 5 frames per number
            picture = new_picture(WIDE_WIDTH, WIDE_HEIGHT)
            if flicker % 2 == 0:                    # the spark flickers
                draw_sprite(picture, big_bomb, 14, 8, art.BOMB_COLORS)
            else:
                draw_sprite(picture, big_bomb, 14, 8, art.BOMB_COLORS_SWAPPED)
            if number == "1":
                art.draw_text(picture, number, 90, 14, art.BLOOD, 5, 18)   # the last second is red
            else:
                art.draw_text(picture, number, 90, 14, art.ICE, 5, 18)
            show_frame(picture, "", 231, 0.07)

    play_sound('beep')
    for flash in range(8):                          # the title flashes 8 times
        picture = new_picture(WIDE_WIDTH, WIDE_HEIGHT)
        draw_sprite(picture, big_bomb, 14, 8, art.BOMB_COLORS)
        flash_title(picture, "TICK TOCK", flash)
    chessboard_wipe(picture)


def play_flip_intro():
    # The king spins all the way around while arrows fly past, then "FLIP THE KING"
    arrows = [art.ARROW_UP, art.ARROW_RIGHT, art.ARROW_DOWN, art.ARROW_LEFT]   # the 4 flying arrows
    arrow_heights = [4, 48, 16, 36]                 # how high each one flies
    king_left = (WIDE_WIDTH - 48) // 2              # the king in the middle
    grey = {'o': 240, 'w': 250}                     # grey arrows

    for step in range(9):                           # 9 frames: 0, 45, 90 ... 360 degrees
        picture = new_picture(WIDE_WIDTH, WIDE_HEIGHT)
        for index in range(4):                      # the 4 flying arrows
            # each arrow moves 18 pixels a frame; when it flies off the right, it starts again on the left
            arrow_left = step * 18 + index * 37
            if arrow_left > WIDE_WIDTH:
                arrow_left = arrow_left - WIDE_WIDTH - 12
            draw_sprite(picture, arrows[index], arrow_left, arrow_heights[index], grey)
        draw_sprite(picture, art.king_turned(step * 45), king_left, 8, art.KING_COLORS)   # turned 45 degrees more each frame
        if step % 2 == 0:
            play_sound('whoosh')
        show_frame(picture, "", 231, 0.1)

    play_sound('coin')
    for flash in range(8):                          # the title flashes 8 times
        picture = new_picture(WIDE_WIDTH, WIDE_HEIGHT)
        draw_sprite(picture, art.king_turned(0), king_left, 8, art.KING_COLORS)   # the king standing up
        flash_title(picture, "FLIP THE KING", flash)
    chessboard_wipe(picture)


def flash_title(picture, title, flash):
    # A dark strip with the title in big letters, gold and fire taking turns
    fill_box(picture, 0, 21, picture['width'], 20, 233)       # the dark strip
    if flash % 2 == 0:
        text_in_middle(picture, title, 24, art.GOLD, 2, 94)
    else:
        text_in_middle(picture, title, 24, art.FIRE, 2, 94)
    show_frame(picture, "", 231, 0.07)


def chessboard_wipe(picture):
    # Chess squares sweep across from left to right, one more column of
    # squares every frame, covering the last picture of the intro.
    play_sound('whoosh')
    for columns_covered in range(17):               # 0, 1, 2 ... 16 columns of 10-pixel squares
        for row in range(7):                        # 7 rows of squares cover the 64 pixels
            column = columns_covered - 1            # the newest column
            if column >= 0:
                if (row + column) % 2 == 0:
                    color = art.LIGHT_SQUARE        # light and dark squares take turns
                else:
                    color = art.DARK_SQUARE
                fill_box(picture, column * 10, row * 10, 10, 10, color)
        show_frame(picture, "", 231, 0.07)


# =====================================================================
#  THE SMALL HELPERS ALL THE ANIMATIONS SHARE
# =====================================================================
def show_frame(picture, caption, caption_color, seconds):
    # Shows one frame: the picture, an empty line, and a caption under it.
    # Then waits that many seconds.
    lines = picture_to_lines(picture)               # the picture as text lines
    lines.append("")
    lines.append(center_line(paint(caption, caption_color, bold=True), picture['width']))
    # extra_below=1 keeps a copy of the frame, so wait_for_enter() can ask under it.
    # clear=False paints over the old frame instead of erasing it first (no flicker).
    present(lines, extra_below=1, clear=False)
    time.sleep(seconds)


def text_in_middle(picture, text, from_top, colors, size, shadow):
    # Big pixel letters, centred left-to-right, 'from_top' pixels from the top
    from_left = (picture['width'] - art.text_width(text, size)) // 2   # half the spare room on the left
    art.draw_text(picture, text, from_left, from_top, colors, size, shadow)


def explosion_picture(width, height, middle_left, middle_top, radius, step, dice):
    # A fireball: rings of colour by how far from the middle -
    # white in the middle, then yellow, orange, red, dark red.
    # A little randomness makes the rings ragged, like real fire.
    picture = new_picture(width, height)
    for from_top in range(height):                  # every pixel:
        for from_left in range(width):
            across = from_left - middle_left
            down = from_top - middle_top
            distance = across * across + down * down              # (Pythagoras, without the square root)
            if distance <= radius * radius:                       # inside the fireball:
                # how far out, in percent (0 = the middle, 100 = the edge),
                # plus a random wobble so the rings look ragged
                ring = distance * 100 // (radius * radius) + dice.randint(-8, 12)
                if step == 0 or ring < 9:
                    color = 231          # white
                elif ring < 30:
                    color = 220          # yellow
                elif ring < 56:
                    color = 208          # orange
                elif ring < 90:
                    color = 196          # red
                else:
                    color = 88           # dark red
                set_pixel(picture, from_left, from_top, color)
            elif distance <= (radius + 4) * (radius + 4):         # just outside: a few sparks
                if dice.randint(1, 100) <= 12:
                    set_pixel(picture, from_left, from_top, dice.choice([214, 220, 202]))
    return picture
