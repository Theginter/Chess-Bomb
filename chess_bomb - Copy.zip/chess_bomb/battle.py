import os                                                   # os = facts about the computer (is it Windows?)
import sys                                                  # sys.stdin = the keyboard (for the bonus stage)
import random                                               # random = dice rolls (the Bot's choices, the bonus stage)
import time                                                 # time = waiting (time.sleep) and the clock (time.time)
from settings import *                                      # every setting, e.g. STARTING_HEALTH
from display import present, ask, ask_in_box, wait_for_enter   # showing screens and asking
from display import new_picture, fill_box, draw_sprite, picture_to_lines   # pixel pictures
from display import paint, pad_right, pad_left, center_line   # colours and lining up text
import art                                                  # every drawing (art.py)
from animations import play_bomb_animation, play_heal_animation, play_overflow_animation, play_scan_animation
from sound import play_music, play_sound                    # music and sounds
import controls                                             # the CONTROLS boxes (controls.py)
import cheats                                               # the x-ray cheat (cheats.py)

# =====================================================================
#  FILE 7 of 11:  BATTLE.PY  -  THE BOARD, THE BATTLE AND THE BONUS STAGE
#
#  THE RULES (that's all of them)
#   PAWN        every square starts as a face-down pawn
#   BOMB        flip an enemy bomb and YOU lose 1 HP
#   EXTRA LIFE  flip an enemy extra life and YOU heal 1 HP
#   OVERFLOW    find an extra life while at full HP -> the ENEMY loses 1 HP
#   SACRIFICE SCAN (level 5 and up): blow up one of your own hidden
#               bombs to safely look under one enemy pawn
#   You win by taking all enemy HP, or by flipping all their safe pawns.
#
# ---------------------------------------------------------------------
#  HOW THE GAME REMEMBERS A BATTLE: the "state"
# ---------------------------------------------------------------------
#   Everything about one battle is kept in ONE dictionary called state.
#   state['level'] is the box labelled 'level'. The boxes are:
#
#     state['rows'], state['columns']   how big the board is
#     state['river_row']                the row number of the river
#
#     state['traps']    the HIDDEN traps. A square is written as a pair
#                       (row, column), like (3, 1). Only squares with a
#                       trap are in here:
#                           state['traps'][(3, 1)] = 'bomb'
#                           state['traps'][(0, 4)] = 'life'
#                       A square that isn't in it is an empty pawn.
#
#     state['flipped']  a list of every square that was flipped already
#
#     state['players']  the two players:
#                           state['players'][1]  = Player One (you)
#                           state['players'][2]  = Player Two (or the Bot)
#                       each with their 'name', their 'hp' and the 'rows'
#                       on their side of the river.
#
#     state['turn']     whose turn it is: 1 or 2
#     state['last_move']  the square flipped last (drawn yellow)
#     state['notice']   a red message under the board ("" = none)
#
#   Rows are counted from the TOP of the board, starting at 0.
#   Player Two has the rows above the river, Player One the rows below.
#
# ---------------------------------------------------------------------
#  READ IT IN THIS ORDER (it's the order a match happens in)
# ---------------------------------------------------------------------
#   1) A NEW MATCH           make_a_new_match
#   2) HIDING TRAPS          let_the_player_hide_their_traps, let_the_bot_hide_its_traps
#   3) THE BATTLE            play_the_whole_battle (turn after turn), find_winner
#   4) ONE TURN              let_the_player_take_their_turn, play_one_turn_of_the_bot
#   5) ASKING FOR A SQUARE   keep_asking_until_a_good_square_is_typed, turn_what_was_typed_into_a_square, is_square_allowed
#   6) FLIPPING A PAWN       flip_the_pawn_and_use_the_rules  <- the rules happen here
#   7) SACRIFICE SCAN        do_the_sacrifice_scan
#   8) THE END               show_the_whole_board_at_the_end
#   9) THE BATTLE SCREEN     show_the_battle_screen_and_ask, show_the_battle_screen_for_a_moment, put_the_battle_screen_together
#  10) DRAWING THE BOARD     draw_the_whole_board
#  11) THE SIDE PANEL        build_the_side_panel (crowns + the CONTROLS box)
#  12) SMALL HELPERS         which_side_owns_this_row, count_the_safe_pawns_left, name_of_the_square ...
#  13) THE BONUS STAGE       play_the_bonus_stage
# =====================================================================

LETTERS_OF_THE_COLUMNS = "abcdefghijklmnopqrstuvwxyz"       # the column letters
WIDTH_OF_THE_SIDE_PANEL = 46                                # width of the side panel, in characters

# The coloured bar at the top of the battle screen: [text colour, background colour]
TOP_BAR_COLORS_FOR_PLAYER_ONE = [16, 255]                   # black on white
TOP_BAR_COLORS_FOR_PLAYER_TWO = [255, 238]                  # white on dark grey
TOP_BAR_COLORS_YELLOW = [16, 220]                           # black on yellow
TOP_BAR_COLORS_RED = [231, 124]                             # white on red


# =====================================================================
#  1) A NEW MATCH
# =====================================================================
def make_a_new_match(level_number, is_a_1v1_match, title_in_the_panel):
    # Builds the state of a brand-new battle (see the top of this file)
    number_of_rows = how_many_rows_for_this_level(level_number)   # how many rows this level's board has
    number_of_columns = how_many_columns_for_this_level(level_number)   # how many columns
    row_of_the_river = number_of_rows // 2                  # the middle row (// = divide, drop the decimals)

    # The rows on each side of the river. Example, a board with 5 rows:
    #     rows 0 and 1 = above the river (Player Two)
    #     row 2        = the river
    #     rows 3 and 4 = below the river (Player One)
    rows_above_river = []
    for which_row in range(0, row_of_the_river):            # from the top row up to the river
        rows_above_river.append(which_row)
    rows_below_river = []
    for which_row in range(row_of_the_river + 1, number_of_rows):   # from just after the river to the bottom
        rows_below_river.append(which_row)

    # The names: in 1V1 both players are people, otherwise Player Two is the Bot
    if is_a_1v1_match == True:
        name_of_player_one = "PLAYER ONE"
        name_of_player_two = "PLAYER TWO"
    else:
        name_of_player_one = "YOU"
        name_of_player_two = "BOT"

    player_one = {}                                         # everything about Player One:
    player_one['name'] = name_of_player_one
    player_one['hp'] = STARTING_HEALTH                      # starts with 3 HP
    player_one['rows'] = rows_below_river                   # your side: the bottom half
    player_one['pawn_word'] = "white pawns"                 # shown in the side panel
    player_one['header_colors'] = TOP_BAR_COLORS_FOR_PLAYER_ONE   # the colour of the bar on top in their turn

    player_two = {}                                         # everything about Player Two / the Bot:
    player_two['name'] = name_of_player_two
    player_two['hp'] = STARTING_HEALTH
    player_two['rows'] = rows_above_river                   # the enemy side: the top half
    player_two['pawn_word'] = "black pawns"
    player_two['header_colors'] = TOP_BAR_COLORS_FOR_PLAYER_TWO

    # How many bombs each player hides.
    # Against the Bot you get EXTRA_BOMBS_FOR_YOU more. In 1V1 both get the same.
    if is_a_1v1_match == True:
        player_one['bomb_count'] = how_many_bombs_for_this_level(level_number)
    else:
        player_one['bomb_count'] = how_many_bombs_for_this_level(level_number) + EXTRA_BOMBS_FOR_YOU
    player_two['bomb_count'] = how_many_bombs_for_this_level(level_number)

    state_of_the_game = {}                                  # the whole state:
    state_of_the_game['level'] = level_number
    state_of_the_game['title'] = title_in_the_panel         # shown in the side panel, e.g. "LEVEL 3"
    state_of_the_game['is_pvp'] = is_a_1v1_match            # True = 1V1, False = against the Bot
    state_of_the_game['rows'] = number_of_rows
    state_of_the_game['columns'] = number_of_columns
    state_of_the_game['river_row'] = row_of_the_river
    state_of_the_game['bomb_count'] = how_many_bombs_for_this_level(level_number)   # how many bombs each player hides
    state_of_the_game['traps'] = {}                         # nothing hidden yet
    state_of_the_game['flipped'] = []                       # nothing flipped yet
    state_of_the_game['players'] = {1: player_one, 2: player_two}
    state_of_the_game['turn'] = 1                           # Player One starts
    state_of_the_game['last_move'] = None                   # None = nothing yet
    state_of_the_game['notice'] = ""                        # no red message
    return state_of_the_game


def how_many_rows_for_this_level(level_number):
    # Level 1: 2 rows on each side + the river = 5 rows.
    # Every 2 levels, 1 more row on each side (settings.py).
    rows_on_each_side = LEVEL_1_ROWS_PER_SIDE + (level_number - 1) // LEVELS_PER_EXTRA_ROW
    return rows_on_each_side + 1 + rows_on_each_side        # their side + the river + your side


def how_many_columns_for_this_level(level_number):
    # Level 1: 6 columns, then 1 more every level (settings.py)
    return LEVEL_1_COLUMNS + (level_number - 1) * EXTRA_COLUMNS_PER_LEVEL


def how_many_bombs_for_this_level(level_number):
    # 4 on level 1, then 1 more every level
    return BOMBS_ON_LEVEL_1 + (level_number - 1) * EXTRA_BOMBS_PER_LEVEL


def board_size_as_text(level_number):
    # "6x5", "7x5" ...  (columns first, then rows)
    return str(how_many_columns_for_this_level(level_number)) + "x" + str(how_many_rows_for_this_level(level_number))


# =====================================================================
#  2) HIDING TRAPS  (bombs first, then the extra life)
# =====================================================================
def let_the_player_hide_their_traps(state_of_the_game, player_number):
    # A person hides their traps, one square at a time.
    # Gives back 'done', or 'cancelled' if they typed 0.
    play_music('battle')
    the_player = state_of_the_game['players'][player_number]   # the player who is hiding
    how_many_traps_in_total = the_player['bomb_count'] + EXTRA_LIVES_COUNT   # this player's bombs + 1 extra life
    traps_hidden_so_far = 0                                 # how many traps are hidden so far

    while traps_hidden_so_far < how_many_traps_in_total:    # until all of them are hidden:
        # The first traps are bombs, the last one is the extra life
        if traps_hidden_so_far < the_player['bomb_count']:
            kind_of_trap = 'bomb'
            words_on_the_river = "ENTER " + number_with_st_nd_rd_th(traps_hidden_so_far + 1) + " BOMB"   # "ENTER 3RD BOMB"
        else:
            kind_of_trap = 'life'
            words_on_the_river = "ENTER EXTRA LIFE"
        words_on_the_top_bar = the_player['name'] + ": HIDE YOUR TRAPS  (" + str(traps_hidden_so_far + 1) + " of " + str(how_many_traps_in_total) + ")"
        # Ask for one of the player's own squares (see part 5)
        the_answer = keep_asking_until_a_good_square_is_typed(state_of_the_game, player_number, words_on_the_top_bar, the_player['header_colors'], the_player['rows'], words_on_the_river,
                                "Type one of YOUR squares (like a1)  |  0 = menu", 'hide', ['0'], 'setup')
        if the_answer == '0':                               # they typed 0:
            return 'cancelled'
        state_of_the_game['traps'][the_answer] = kind_of_trap   # hide it! (answer is the square)
        play_sound('step')
        traps_hidden_so_far = traps_hidden_so_far + 1       # one more hidden

    # All hidden: show the board with "ALL HIDDEN!" for 1 second
    lines_of_the_board = draw_the_whole_board(
        state_of_the_game,
        player_number_whose_bombs_and_life_you_can_see_because_it_is_flipped=player_number,          # this player's own traps
        show_every_trap=False,                      # not everyone's traps
        rows_you_may_pick=the_player['rows'],       # this player's rows are yellow
        words_on_the_river="ALL HIDDEN!",
        show_the_thinking_box=False,                # no "OPPONENT IS THINKING" box
    )
    show_the_battle_screen_for_a_moment(state_of_the_game, the_player['name'] + ": ALL TRAPS HIDDEN", TOP_BAR_COLORS_YELLOW, lines_of_the_board, "", 1.0)
    return 'done'


def let_the_bot_hide_its_traps(state_of_the_game):
    # The Bot hides its traps on random squares of its own side.
    squares_on_the_bot_side = every_square_in_these_rows(state_of_the_game, state_of_the_game['players'][2]['rows'])   # all the squares on the Bot's side
    random.shuffle(squares_on_the_bot_side)                 # mix them up, like shuffling cards

    place_in_the_mixed_up_list = 0                          # which square of the mixed-up list we are at
    for bomb_number in range(state_of_the_game['players'][2]['bomb_count']):   # hide every one of the Bot's bombs:
        the_square = squares_on_the_bot_side[place_in_the_mixed_up_list]
        state_of_the_game['traps'][the_square] = 'bomb'
        place_in_the_mixed_up_list = place_in_the_mixed_up_list + 1   # go to the next square
    for life_number in range(EXTRA_LIVES_COUNT):            # hide every extra life:
        the_square = squares_on_the_bot_side[place_in_the_mixed_up_list]
        state_of_the_game['traps'][the_square] = 'life'
        place_in_the_mixed_up_list = place_in_the_mixed_up_list + 1


# =====================================================================
#  3) THE BATTLE: turns go back and forth until someone wins.
#  Gives back 'player_one_won', 'player_one_lost' or 'quit'
# =====================================================================
def play_the_whole_battle(state_of_the_game):
    play_music('battle')

    while True:                                             # turn after turn:
        # Is the battle over? Then stop and say who won.
        the_winner = find_winner_of_the_game(state_of_the_game) #These two lines ask “has someone won yet?”, and stop the battle if the answer is yes.
        if the_winner == "": #nobody has won yet:
            pass             # do nothing, keep playing
        else:                #somebody has won:   
            return the_winner #stop the battle because there is a winner and somebody won

        if state_of_the_game['turn'] == 1:
            # PLAYER ONE's turn (you)
            if state_of_the_game['is_pvp'] == True:         # 1V1: Player Two must look away first
                show_the_look_away_screen("PLAYER ONE", "Player Two: look away from the screen!")
            result_of_the_turn = let_the_player_take_their_turn(state_of_the_game)
            if result_of_the_turn == 'quit':                # typed 0:
                return 'quit'
            state_of_the_game['turn'] = 2                   # now it's Player Two's turn

        else:
            # PLAYER TWO's turn (the Bot, or a person in 1V1)
            if state_of_the_game['is_pvp'] == True:         # 1V1: a person plays
                show_the_look_away_screen("PLAYER TWO", "Player One: look away from the screen!")
                result_of_the_turn = let_the_player_take_their_turn(state_of_the_game)
                if result_of_the_turn == 'quit':
                    return 'quit'
            else:                                           # campaign: the Bot plays
                play_one_turn_of_the_bot(state_of_the_game)
            state_of_the_game['turn'] = 1                   # now it's Player One's turn again


def find_winner_of_the_game(state_of_the_game):
    # Looks at the battle and says if somebody has won.
    # It gives back ONE of these 3 answers:
    #   'player_one_won'    Player One (you) won
    #   'player_one_lost'   Player Two (or the Bot) won
    #   ""                  nobody has won yet: keep playing
    #
    # A player LOSES when:
    #   - they have no HP left (all their crowns are gone), OR
    #   - every one of their safe pawns was flipped (only their traps are left)

    # First, look up everything we need to check:
    hp_of_player_one = state_of_the_game['players'][1]['hp']                # Player One's HP (3, 2, 1 or 0) and players is the player playing [1] is the player 1 [hp] is what is the current hp of the player
    hp_of_player_two = state_of_the_game['players'][2]['hp']                # Player Two's HP
    safe_pawns_of_player_one = count_the_safe_pawns_left(state_of_the_game, 1)   # Player One's safe pawns left
    safe_pawns_of_player_two = count_the_safe_pawns_left(state_of_the_game, 2)   # Player Two's safe pawns left

    # CHECK 1: did Player Two lose? Then Player One WON.
    # (<= means "less than or equal to": 0 or less = no HP left)
    if hp_of_player_two <= 0:                       # Player Two has no HP left:
        return 'player_one_won'
    if safe_pawns_of_player_two == 0:               # all of Player Two's safe pawns are flipped:
        return 'player_one_won'

    # CHECK 2: did Player One lose? Then Player One LOST.
    if hp_of_player_one <= 0:                       # Player One has no HP left:
        return 'player_one_lost'
    if safe_pawns_of_player_one == 0:               # all of Player One's safe pawns are flipped:
        return 'player_one_lost'

    # Nobody lost: the battle goes on ("" = empty text = no winner yet)
    return ""


def show_the_look_away_screen(name_of_the_player, look_away_message):
    # 1V1 only: between turns, a screen tells the other player to look away.
    #   name_of_the_player = "PLAYER ONE" or "PLAYER TWO"
    #   look_away_message  = e.g. "Player Two: look away from the screen!"
    width_of_the_screen = 120                   # the screen is 120 characters wide

    # STEP 1: the player's name in big letters
    big_name = art.big_text(name_of_the_player, art.STEEL, 2, 238)

    # STEP 2: the two lines of words, in grey
    message_line = paint(look_away_message, 250)            # the look-away message in light grey (250)
    pass_the_device_line = paint("Pass the device, then press Enter.", 244)   # paint paints the word turning the words in grey (244)

    # STEP 3: put the screen together, everything in the middle
    lines_of_the_screen = art.center_block(big_name, width_of_the_screen)   # the big name
    lines_of_the_screen.append("")                                          # an empty line
    lines_of_the_screen.append(center_line(message_line, width_of_the_screen))
    lines_of_the_screen.append(center_line(pass_the_device_line, width_of_the_screen))
    lines_of_the_screen.append("")                                          # an empty line

    # STEP 4: show it, and wait until Enter is pressed
    present(lines_of_the_screen)
    wait_for_enter()


# =====================================================================
#  4) ONE TURN
# =====================================================================
def let_the_player_take_their_turn(state_of_the_game):
    # A person's turn. Gives back 'done', or 'quit' (typed 0).
    player_number = state_of_the_game['turn']               # whose turn it is: 1 or 2

    # Who is playing this turn, and who is the enemy?
    if player_number == 1:                                  # Player One's turn:
        the_player = state_of_the_game['players'][1]        #   Player One plays ...
        the_enemy = state_of_the_game['players'][2]         #   ... against Player Two
    else:                                                   # Player Two's turn:
        the_player = state_of_the_game['players'][2]        #   Player Two plays ...
        the_enemy = state_of_the_game['players'][1]         #   ... against Player One

    while True:                                             # ask until a move is made
        # Ask for an enemy square (see part 5). 0 and 1 are commands.
        the_answer = keep_asking_until_a_good_square_is_typed(state_of_the_game, player_number, the_player['name'] + ": YOUR TURN", the_player['header_colors'],
                                the_enemy['rows'], "PICK ENEMY PAWN",
                                "Choose an enemy pawn, e.g. a1  |  1 = scan  |  0 = quit to menu",
                                'attack', ['0', '1'], 'battle')
        match the_answer:
            case '0':                                       # quit: leave the battle
                return 'quit'
            case '1':                                       # the sacrifice scan
                if do_the_sacrifice_scan(state_of_the_game, player_number) == True:   # it happened:
                    return 'done'                           # the turn is over
                # not allowed or cancelled: the loop asks again
            case _:                                         # anything else is a square: flip it!
                words_on_the_river = flip_the_pawn_and_use_the_rules(state_of_the_game, player_number, the_answer)   # the rules (part 6)
                show_the_board_after_the_move(state_of_the_game, player_number, words_on_the_river)   # show the result
                return 'done'


def play_one_turn_of_the_bot(state_of_the_game):
    # The Bot simply picks one of your unflipped pawns at random.
    squares_the_bot_may_pick = []                           # the squares the Bot may pick
    for the_square in every_square_in_these_rows(state_of_the_game, state_of_the_game['players'][1]['rows']):   # every square on your side: players is the player the number is 1 or 2 1 is you 2 is opponent rows is the list of rows you have on the side of your river rather ANO ANG MERON KANG MGA PAWNS
        if the_square not in state_of_the_game['flipped']:   # not flipped yet?
            squares_the_bot_may_pick.append(the_square)     # the Bot may pick it

    lines_of_the_board = draw_the_whole_board(
        state_of_the_game,
        player_number_whose_bombs_and_life_you_can_see_because_it_is_flipped=1,                      # your own traps (Player One)
        show_every_trap=False,                      # not the Bot's traps
        rows_you_may_pick=None,                     # no yellow rows: nobody is picking
        words_on_the_river="",                      # no words on the river
        show_the_thinking_box=True,                 # the "OPPONENT IS THINKING" box
    )
    show_the_battle_screen_for_a_moment(state_of_the_game, "BOT'S TURN", TOP_BAR_COLORS_FOR_PLAYER_TWO, lines_of_the_board, "...", 1.2)

    the_target_square = random.choice(squares_the_bot_may_pick)   # pick one at random
    state_of_the_game['last_move'] = the_target_square      # it turns yellow
    square_as_text = name_of_the_square(the_target_square, state_of_the_game)   # e.g. "b2"
        # Draw the board for the moment the Bot is about to attack,
    # with "BOT ATTACKS" across the river.
    # The square the Bot picked is already the last move, so it is drawn YELLOW.
    # The board is kept in lines_of_the_board; the next line shows it for a moment.
    lines_of_the_board = draw_the_whole_board(
        # the battle: where every pawn, trap and flipped square is
        state_of_the_game,
        # 1 = show YOUR own bombs (red squares) and extra life (green square),
        # so you can see if the Bot is about to hit one
        player_number_whose_bombs_and_life_you_can_see_because_it_is_flipped=1,
        # False = don't show the Bot's traps: they stay secret
        show_every_trap=False,
        # None = no yellow row numbers: you are not picking anything right now
        rows_you_may_pick=None,
        # write BOT ATTACKS in gold across the river
        words_on_the_river="BOT ATTACKS",
        # False = no "OPPONENT IS THINKING" box (that was the screen before this one)
        show_the_thinking_box=False,
    )
    show_the_battle_screen_for_a_moment(state_of_the_game, "BOT ATTACKS " + square_as_text.upper() + "!", TOP_BAR_COLORS_RED, lines_of_the_board, square_as_text, 0.8)

    words_on_the_river = flip_the_pawn_and_use_the_rules(state_of_the_game, 2, the_target_square)   # the rules (part 6)
    show_the_board_after_the_move(state_of_the_game, 2, words_on_the_river)   # show the result


# =====================================================================
#  5) ASKING FOR A SQUARE
#  Every question in the battle works the same way, so ONE function
#  does it for all of them:
#   - show the battle screen, let the player type in the clock box
#   - if they typed one of the 'commands' (like 0), give that back
#   - otherwise read it as a square and check it. If something is
#     wrong: show a red message and ask again.
#  Gives back the command (like '0'), or the square (like (3, 1)).
#
#  check = what the square must be:
#   'hide'     one of your own pawns without a trap yet
#   'attack'   an enemy pawn that isn't flipped yet
#   'my bomb'  one of your own hidden bombs
#   'scan'     an enemy pawn that isn't flipped yet
#  mode = 'setup' (hiding traps) or 'battle': changes the CONTROLS box
# =====================================================================
def keep_asking_until_a_good_square_is_typed(state_of_the_game, player_number, words_on_the_top_bar, colors_of_the_top_bar, rows_you_may_pick, words_on_the_river, hint_next_to_the_box, what_to_check, allowed_commands, setup_or_battle):
    while True:                                             # ask until we get a good answer
        what_was_typed = show_the_battle_screen_and_ask(state_of_the_game, words_on_the_top_bar, colors_of_the_top_bar, player_number, rows_you_may_pick, words_on_the_river, hint_next_to_the_box, setup_or_battle)
        if what_was_typed == "":
            continue                                        # nothing typed: ask again
        if what_was_typed in allowed_commands:              # a command, like '0'?
            return what_was_typed
        the_square = turn_what_was_typed_into_a_square(what_was_typed, state_of_the_game, rows_you_may_pick)   # turn "a1" into a square
        if the_square == None:                              # it isn't a square (a red message was set)
            continue                                        # ask again
        if if_mistakes_happen_in_the_tiles(state_of_the_game, the_square, what_to_check) == False:   # not allowed (a red message was set)
            continue                                        # ask again
        return the_square                                   # all good: give back the square


def turn_what_was_typed_into_a_square(what_was_typed, state_of_the_game, rows_you_may_pick):
    # What you typed -> the square (row, column).
    # The easy way: go through EVERY square you may pick, write down its
    # name (like "a1"), and check if that is what you typed.
    # "a1" and "1a" both work.
    # No square matches? Show a red message and give back None.

    for the_square in every_square_in_these_rows(state_of_the_game, rows_you_may_pick):   # every square you may pick:
        letter = LETTERS_OF_THE_COLUMNS[the_square[1]]    # the_square[1] = its column number (0, 1, 2 ...) -> its letter ("a", "b", "c" ...)           # its column letter, e.g. "a"
        number = row_number_you_type(the_square[0], state_of_the_game)   # the_square[0] = its row -> the yellow number you type for it, e.g. "1"

        if what_was_typed == letter + number:                     # you typed "a1"
            return the_square
        if what_was_typed == number + letter:                     # you typed "1a"
            return the_square

    # We looked at every square and none of them matched
    show_a_red_message(state_of_the_game, "That's not one of your squares. Type a letter and a yellow number, like a1.")
    return None

#=============================================================================================================================================================
#=============================================================================================================================================================

def if_mistakes_happen_in_the_tiles(state_of_the_game, the_square, what_to_check):
    # True if the square is fine. If not: shows a red message and gives back False.
    match what_to_check:
        case 'hide':
            if the_square in state_of_the_game['traps']:
                show_a_red_message(state_of_the_game, "You already hid a trap there! Pick another pawn.")
                return False
        case 'attack':
            if the_square in state_of_the_game['flipped']:
                show_a_red_message(state_of_the_game, "That pawn is already flipped! Pick another.")
                return False
        case 'my bomb':
            if is_this_a_hidden_bomb(state_of_the_game, the_square) == False:
                show_a_red_message(state_of_the_game, "That is not one of your hidden bombs!")
                return False
        case 'scan':
            if the_square in state_of_the_game['flipped']:
                show_a_red_message(state_of_the_game, "That pawn is already flipped!")
                return False
    return True                                             # if there's nothing wrong


# =====================================================================
#  6) FLIPPING A PAWN  -  THE RULES HAPPEN HERE
#  Gives back the words to show across the river afterwards.
# =====================================================================
def flip_the_pawn_and_use_the_rules(state_of_the_game, attacker_player_number, the_square):
    # attacker_player_number = who is flipping: 1 (you / Player One) or 2 (the Bot / Player Two)

    # Who is flipping (the attacker), and who owns the pawn (the defender)?
    if attacker_player_number == 1:                         # Player One flips:
        the_attacker_or_the_one_who_has_a_turn_to_flip_pawns = state_of_the_game['players'][1]
        the_defender = state_of_the_game['players'][2]      #   the pawn belongs to Player Two
    else:                                                   # Player Two (or the Bot) flips:
        the_attacker_or_the_one_who_has_a_turn_to_flip_pawns = state_of_the_game['players'][2]
        the_defender = state_of_the_game['players'][1]      #   the pawn belongs to Player One

    state_of_the_game['flipped'].append(the_square)         # add the square to the flipped list

    state_of_the_game['last_move'] = the_square             # it turns yellow

    square_as_text = name_of_the_square(the_square, state_of_the_game).upper()   # e.g. "B2"

    the_trap = what_trap_is_on_this_square(state_of_the_game, the_square)   # 'bomb', 'life' or 'none'

    match the_trap:
        case 'bomb':
            # RULE: BOMB -> the one who flipped it loses 1 HP
            the_attacker_or_the_one_who_has_a_turn_to_flip_pawns['hp'] = the_attacker_or_the_one_who_has_a_turn_to_flip_pawns['hp'] - 1
            play_bomb_animation(the_attacker_or_the_one_who_has_a_turn_to_flip_pawns['name'] + " HIT A BOMB ON " + square_as_text + "!   -1 HP")
            return "BOOM!"

        case 'life':
            if the_attacker_or_the_one_who_has_a_turn_to_flip_pawns['hp'] < STARTING_HEALTH:
                # RULE: EXTRA LIFE -> the one who flipped it heals 1 HP ...
                the_attacker_or_the_one_who_has_a_turn_to_flip_pawns['hp'] = the_attacker_or_the_one_who_has_a_turn_to_flip_pawns['hp'] + 1
                play_heal_animation(the_attacker_or_the_one_who_has_a_turn_to_flip_pawns['name'] + " FOUND AN EXTRA LIFE!   +1 HP")
                return "EXTRA LIFE!"
            else:
                # RULE: OVERFLOW -> ... but at full HP, the ENEMY loses 1 HP instead
                the_defender['hp'] = the_defender['hp'] - 1
                play_overflow_animation("OVERFLOW!  " + the_attacker_or_the_one_who_has_a_turn_to_flip_pawns['name'] + " WAS AT FULL HP, SO " + the_defender['name'] + " TAKES 1 DAMAGE!")
                return "OVERFLOW!"

        case _:
            # RULE: PAWN -> nothing happens, it was safe
            play_sound('flip')
            return "SAFE"


def show_the_board_after_the_move(state_of_the_game, the_player_who_moved, words_on_the_river):
    # Shows the board with "BOOM!" / "SAFE" / ... across the river.
    # In 1V1 the mover sees their own traps; against the Bot you always do.
    if state_of_the_game['is_pvp'] == True:
        whose_traps_to_show = the_player_who_moved
    else:
        whose_traps_to_show = 1
    lines_of_the_board = draw_the_whole_board(
        state_of_the_game,
        player_number_whose_bombs_and_life_you_can_see_because_it_is_flipped=whose_traps_to_show,    # the traps of the player found just above
        show_every_trap=False,                      # not everyone's traps
        rows_you_may_pick=None,                     # no yellow rows: nobody is picking
        words_on_the_river=words_on_the_river,      # "BOOM!", "SAFE" ...
        show_the_thinking_box=False,                # no "OPPONENT IS THINKING" box
    )
    show_the_battle_screen_for_a_moment(state_of_the_game, state_of_the_game['players'][the_player_who_moved]['name'] + " MOVED", TOP_BAR_COLORS_YELLOW, lines_of_the_board, "", 1.4)


# =====================================================================
#  7) SACRIFICE SCAN  (level 5 and up)
#   1) pick one of your own hidden bombs  (it is used up)
#   2) pick one enemy pawn                (it is shown, nothing happens)
#  Gives back True if the scan happened, False if not allowed / cancelled
# =====================================================================
def do_the_sacrifice_scan(state_of_the_game, player_number):
    if state_of_the_game['level'] < UNLOCK_LEVEL_FOR_SCAN:   # too early in the campaign?
        show_a_red_message(state_of_the_game, "The Sacrifice Scan unlocks at level " + str(UNLOCK_LEVEL_FOR_SCAN) + ".")
        return False
    if count_the_hidden_bombs_left(state_of_the_game, player_number) == 0:   # no bombs left to give up?
        show_a_red_message(state_of_the_game, "You have no hidden bombs left to sacrifice.")
        return False

    # Who is doing the scan, and who is the enemy?
    if player_number == 1:                                  # Player One scans:
        the_player = state_of_the_game['players'][1]        #   Player One gives up a bomb ...
        the_enemy = state_of_the_game['players'][2]         #   ... to look under Player Two's pawn
    else:                                                   # Player Two scans:
        the_player = state_of_the_game['players'][2]
        the_enemy = state_of_the_game['players'][1]

    # STEP 1: which of your bombs do you give up?
    my_bomb_square = keep_asking_until_a_good_square_is_typed(state_of_the_game, player_number, "SACRIFICE SCAN: PICK ONE OF YOUR BOMBS (red squares)",
                             TOP_BAR_COLORS_YELLOW, the_player['rows'], "SACRIFICE BOMB",
                             "Your bomb square  |  0 = cancel", 'my bomb', ['0'], 'battle')
    if my_bomb_square == '0':                               # cancelled
        return False

    # STEP 2: which enemy pawn do you look under?
    the_target_square = keep_asking_until_a_good_square_is_typed(state_of_the_game, player_number, "SACRIFICE SCAN: PICK AN ENEMY PAWN TO SCAN",
                            TOP_BAR_COLORS_YELLOW, the_enemy['rows'], "SCAN ENEMY PAWN",
                            "Enemy square  |  0 = cancel", 'scan', ['0'], 'battle')
    if the_target_square == '0':                            # cancelled
        return False

    # STEP 3: your bomb is used up, and the enemy square is shown safely
    state_of_the_game['traps'].pop(my_bomb_square)          # pop = take it out of the traps
    state_of_the_game['flipped'].append(my_bomb_square)     # your bomb's square is now an empty hole
    state_of_the_game['flipped'].append(the_target_square)   # the scanned square is turned over
    state_of_the_game['last_move'] = the_target_square
    match what_trap_is_on_this_square(state_of_the_game, the_target_square):   # what was under it?
        case 'bomb':
            what_the_scan_found = "A BOMB (safely defused)"
        case 'life':
            what_the_scan_found = "AN EXTRA LIFE (no healing on a scan)"
        case _:
            what_the_scan_found = "A SAFE PAWN"
    square_as_text = name_of_the_square(the_target_square, state_of_the_game).upper()
    play_scan_animation("SACRIFICE SCAN ON " + square_as_text + ": " + what_the_scan_found)
    show_the_board_after_the_move(state_of_the_game, player_number, "SCANNED")
    return True


# =====================================================================
#  8) THE END: the whole board shown, with the result on the river
#   e.g. "YOU WIN!" + CONTINUE, or "YOU LOSE!" + TRY AGAIN
#  Gives back what was typed (e.g. '1' = try again)
# =====================================================================
def show_the_whole_board_at_the_end(state_of_the_game, words_on_the_river, words_on_the_top_bar, colors_of_the_top_bar, text_in_the_clock_box, hint_next_to_the_box):
    state_of_the_game['last_move'] = None                   # no yellow square
    lines_of_the_board = draw_the_whole_board(
        state_of_the_game,
        player_number_whose_bombs_and_life_you_can_see_because_it_is_flipped=None,                   # (not needed: every trap is shown anyway)
        show_every_trap=True,                       # the end of the battle: show EVERY trap
        rows_you_may_pick=None,                     # no yellow rows: nobody is picking
        words_on_the_river=words_on_the_river,      # "YOU WIN!", "YOU LOSE!" ...
        show_the_thinking_box=False,                # no "OPPONENT IS THINKING" box
    )
    lines_of_the_screen = put_the_battle_screen_together(state_of_the_game, words_on_the_top_bar, colors_of_the_top_bar, lines_of_the_board, build_the_side_panel(state_of_the_game, 'battle'), text_in_the_clock_box, hint_next_to_the_box)
    present(lines_of_the_screen)
    return ask(paint(">", 230, bold=True))                  # wait for Enter (or 1 = try again)


# =====================================================================
#  9) THE BATTLE SCREEN
#   the header on top, the board on the left, the panel on the right,
#   and the chess-clock typing box at the bottom
# =====================================================================
def show_the_battle_screen_and_ask(state_of_the_game, words_on_the_top_bar, colors_of_the_top_bar, whose_traps_to_show, rows_you_may_pick, words_on_the_river, hint_next_to_the_box, setup_or_battle):
    # Shows the battle screen and lets the player type in the clock box.
    lines_of_the_board = draw_the_whole_board(
        state_of_the_game,
        player_number_whose_bombs_and_life_you_can_see_because_it_is_flipped=whose_traps_to_show,    # the traps of the player who is typing
        show_every_trap=False,                      # not everyone's traps
        rows_you_may_pick=rows_you_may_pick,        # the rows they may type are yellow
        words_on_the_river=words_on_the_river,      # "PICK ENEMY PAWN", "ENTER 1ST BOMB" ...
        show_the_thinking_box=False,                # no "OPPONENT IS THINKING" box
    )
    lines_of_the_screen = put_the_battle_screen_together(state_of_the_game, words_on_the_top_bar, colors_of_the_top_bar, lines_of_the_board, build_the_side_panel(state_of_the_game, setup_or_battle), "", hint_next_to_the_box)
    what_was_typed = ask_in_box(lines_of_the_screen, art.CLOCK_BOX_TYPING_COLUMN)   # show it, let them type
    state_of_the_game['notice'] = ""                        # the red message has been seen
    if what_was_typed == 'l':                               # the secret x-ray cheat (cheats.py)
        cheats.switch_xray()
        return ""                                           # as if nothing was typed (so it asks again)
    return what_was_typed


def show_the_battle_screen_for_a_moment(state_of_the_game, words_on_the_top_bar, colors_of_the_top_bar, lines_of_the_board, text_in_the_clock_box, how_many_seconds):
    # Shows the battle screen for a moment, without asking anything
    lines_of_the_screen = put_the_battle_screen_together(state_of_the_game, words_on_the_top_bar, colors_of_the_top_bar, lines_of_the_board, build_the_side_panel(state_of_the_game, 'battle'), text_in_the_clock_box, "")
    state_of_the_game['notice'] = ""                        # the red message has been seen
    present(lines_of_the_screen, extra_below=0)
    time.sleep(how_many_seconds)                            # wait that many seconds


def put_the_battle_screen_together(state_of_the_game, words_on_the_top_bar, colors_of_the_top_bar, lines_of_the_board, lines_of_the_panel, text_in_the_clock_box, hint_next_to_the_box):
    # Puts the whole battle screen together, as a list of text lines
    width_of_the_board = art.widest_line(lines_of_the_board)   # how wide the board is
    width_of_the_whole_screen = width_of_the_board + 4 + WIDTH_OF_THE_SIDE_PANEL   # board + gap + panel
    the_top_bar = paint("   " + words_on_the_top_bar + "   ", colors_of_the_top_bar[0], colors_of_the_top_bar[1], bold=True)
    lines_of_the_screen = [center_line(the_top_bar, width_of_the_whole_screen)]   # the bar on top

    # The board and the panel, side by side
    if len(lines_of_the_board) > len(lines_of_the_panel):   # as many lines as the taller one
        number_of_lines = len(lines_of_the_board)
    else:
        number_of_lines = len(lines_of_the_panel)
    for line_index in range(number_of_lines):
        board_line = ""                                     # empty if the board has no line here
        panel_line = ""                                     # empty if the panel has no line here
        if line_index < len(lines_of_the_board):
            board_line = lines_of_the_board[line_index]
        if line_index < len(lines_of_the_panel):
            panel_line = lines_of_the_panel[line_index]
        lines_of_the_screen.append(pad_right(board_line, width_of_the_board) + "    " + panel_line)   # board line + 4 spaces + panel line

    # The chess-clock box, with the red notice and the hint next to it
    red_message_text = ""
    if state_of_the_game['notice'] != "":                   # a red message to show?
        red_message_text = paint(state_of_the_game['notice'], 203, bold=True)
    clock_box_lines = art.clock_box(text_in_the_clock_box)   # the 4 lines of the clock box
    lines_of_the_screen.append(clock_box_lines[0])          # its buttons
    lines_of_the_screen.append(clock_box_lines[1] + "   " + red_message_text)   # its top + the red message
    lines_of_the_screen.append(clock_box_lines[2] + "   " + paint(hint_next_to_the_box, 230))   # the typing line + the hint
    lines_of_the_screen.append(clock_box_lines[3])          # its bottom
    return lines_of_the_screen


# =====================================================================
#  10) DRAWING THE BOARD
#  The whole board is ONE pixel picture (display.py PART 2): wooden
#  squares, pawns, bombs, extra lives and the river. Messages like
#  "YOU WIN!" are written across the river.
#
#  HOW BIG ARE THE SQUARES?
#  Big levels have more squares, so each square must be smaller to fit
#  the 192 x 54 screen. We pick the BIGGEST square size (SQUARE_SIZES in
#  settings.py) that fits.
# =====================================================================
def draw_the_whole_board(state_of_the_game, player_number_whose_bombs_and_life_you_can_see_because_it_is_flipped, show_every_trap, rows_you_may_pick, words_on_the_river, show_the_thinking_box):
    # The whole board as text lines: squares + frame + numbers + letters.
    # Its 6 inputs:
    #   state_of_the_game       the whole battle
    #   whose_traps_to_show     1 or 2: that player's own traps are shown (red / green squares).
    #                           None = nobody's.
    #   show_every_trap         True = show EVERY trap (at the end of a battle)
    #   rows_you_may_pick       the rows whose numbers are yellow (you may type them).
    #                           None = nobody is picking right now.
    #   words_on_the_river      words across the river, e.g. "BOOM!"   ("" = none)
    #   show_the_thinking_box   True = show the "OPPONENT IS THINKING" box
    if cheats.xray_is_on() == True:
        show_every_trap = True                              # the secret 'l' x-ray cheat (cheats.py)
    pixels_per_square = biggest_square_size_that_fits(state_of_the_game)   # how many pixels per square
    the_picture = paint_every_square_of_the_board(state_of_the_game, pixels_per_square, player_number_whose_bombs_and_life_you_can_see_because_it_is_flipped, show_every_trap)   # the squares
    if show_the_thinking_box == True:
        draw_the_opponent_is_thinking_box(the_picture)      # the "thinking" box on top
    lines_of_the_picture = picture_to_lines(the_picture)    # pixels -> text lines
    if words_on_the_river in art.BANNERS:                   # words for the river?
        write_the_words_on_the_river(state_of_the_game, lines_of_the_picture, art.BANNERS[words_on_the_river], pixels_per_square, the_picture['width'])
    return add_the_frame_numbers_and_letters(state_of_the_game, lines_of_the_picture, pixels_per_square, the_picture['width'], rows_you_may_pick)


def biggest_square_size_that_fits(state_of_the_game):
    # The biggest square size that lets this board fit the 192 x 54 screen
    lines_we_have_room_for = SCREEN_LINES - 8               # minus: header, frame, letters, typing box
    columns_we_have_room_for = SCREEN_COLUMNS - 10 - WIDTH_OF_THE_SIDE_PANEL   # minus: numbers, frame, gap, side panel
    for square_size_to_try in SQUARE_SIZES:                 # try the biggest first
        lines_of_the_board = state_of_the_game['rows'] * square_size_to_try // 2   # 2 pixels = 1 line of text
        width_of_the_board = state_of_the_game['columns'] * square_size_to_try   # pixels across = characters across
        if lines_of_the_board <= lines_we_have_room_for and width_of_the_board <= columns_we_have_room_for:   # does it fit?
            return square_size_to_try                       # yes: use this size
    return 6                                                # nothing fits: the smallest size


def paint_every_square_of_the_board(state_of_the_game, pixels_per_square, whose_traps_to_show, show_every_trap):
    # Paints every square of the board into one pixel picture
    the_picture = new_picture(state_of_the_game['columns'] * pixels_per_square, state_of_the_game['rows'] * pixels_per_square)
    for which_row in range(state_of_the_game['rows']):      # every row ...
        for which_column in range(state_of_the_game['columns']):   # ... and every square in it:
            left_edge = which_column * pixels_per_square    # where this square starts, in pixels
            top_edge = which_row * pixels_per_square
            if which_row == state_of_the_game['river_row']:   # the river row:
                paint_the_river(the_picture, left_edge, top_edge, pixels_per_square)
            else:
                paint_one_square(state_of_the_game, the_picture, which_row, which_column, left_edge, top_edge, pixels_per_square, whose_traps_to_show, show_every_trap)
    return the_picture


def paint_one_square(state_of_the_game, the_picture, which_row, which_column, left_edge, top_edge, pixels_per_square, whose_traps_to_show, show_every_trap):
    # Decides 3 things for one square, then draws it:
    #   its colour, which drawing goes on it, and the drawing's colours
    the_square = (which_row, which_column)
    the_trap = what_trap_is_on_this_square(state_of_the_game, the_square)   # 'bomb', 'life' or 'none'

    # Light and dark squares take turns, like a chessboard
    if (which_row + which_column) % 2 == 0:
        is_a_light_square = True
    else:
        is_a_light_square = False

    # May the trap be shown? (the end of the battle, or it's the viewer's own side)
    the_trap_can_be_seen = False
    if show_every_trap == True:
        the_trap_can_be_seen = True
    if whose_traps_to_show != None and which_side_owns_this_row(state_of_the_game, which_row) == whose_traps_to_show:
        the_trap_can_be_seen = True

    # The normal square colour (changed below for special squares)
    if is_a_light_square == True:
        color_of_the_square = art.LIGHT_SQUARE
    else:
        color_of_the_square = art.DARK_SQUARE

    if the_square in state_of_the_game['flipped'] and the_trap == 'bomb':   # an exploded bomb on a burnt square
        if is_a_light_square == True:
            color_of_the_square = art.BURNT_LIGHT
        else:
            color_of_the_square = art.BURNT_DARK
        which_drawing = 'bomb'
        colors_of_the_drawing = art.BOMB_COLORS
    elif the_square in state_of_the_game['flipped'] and the_trap == 'life':   # a found extra life
        which_drawing = 'life'
        colors_of_the_drawing = art.LIFE_COLORS
    elif the_square in state_of_the_game['flipped']:        # an empty hole
        which_drawing = 'hole'
        colors_of_the_drawing = art.HOLE_COLORS
    elif the_trap_can_be_seen == True and the_trap == 'bomb':   # your own bomb (red tint)
        if is_a_light_square == True:
            color_of_the_square = art.MY_BOMB_LIGHT
        else:
            color_of_the_square = art.MY_BOMB_DARK
        which_drawing = 'bomb'
        colors_of_the_drawing = art.BOMB_COLORS
    elif the_trap_can_be_seen == True and the_trap == 'life':   # your own extra life (green tint)
        if is_a_light_square == True:
            color_of_the_square = art.MY_LIFE_LIGHT
        else:
            color_of_the_square = art.MY_LIFE_DARK
        which_drawing = 'life'
        colors_of_the_drawing = art.LIFE_COLORS
    else:                                                   # a face-down pawn
        which_drawing = 'pawn'
        if which_side_owns_this_row(state_of_the_game, which_row) == 2:
            colors_of_the_drawing = art.BLACK_PIECE         # the top side has black pawns
        else:
            colors_of_the_drawing = art.WHITE_PIECE         # the bottom side has white pawns

    if state_of_the_game['last_move'] == the_square:        # the last move is yellow
        if is_a_light_square == True:
            color_of_the_square = art.LAST_MOVE_LIGHT
        else:
            color_of_the_square = art.LAST_MOVE_DARK

    # Paint the square, then the drawing in the middle of it
    fill_box(the_picture, left_edge, top_edge, pixels_per_square, pixels_per_square, color_of_the_square)
    the_sprite = art.sprite_for_square(which_drawing, pixels_per_square)
    left_edge_of_the_sprite = left_edge + (pixels_per_square - len(the_sprite[0])) // 2
    top_edge_of_the_sprite = top_edge + (pixels_per_square - len(the_sprite)) // 2
    draw_sprite(the_picture, the_sprite, left_edge_of_the_sprite, top_edge_of_the_sprite, colors_of_the_drawing)


def paint_the_river(the_picture, left_edge, top_edge, size_of_the_square):
    # Blue water, with a lighter blue stripe every 4 pixel rows (the waves)
    fill_box(the_picture, left_edge, top_edge, size_of_the_square, size_of_the_square, art.RIVER_COLOR)   # plain blue
    top_of_the_stripe = top_edge + 1
    while top_of_the_stripe < top_edge + size_of_the_square:   # a stripe every 4 rows
        fill_box(the_picture, left_edge, top_of_the_stripe, size_of_the_square, 1, art.RIVER_WAVE)
        top_of_the_stripe = top_of_the_stripe + 4


def draw_the_opponent_is_thinking_box(the_picture):
    # "OPPONENT IS THINKING..." in a white box in the middle of the board
    if the_picture['width'] >= 80:
        lines_of_words = ["OPPONENT IS", "THINKING..."]
    else:
        lines_of_words = ["OPPONENT", "IS", "THINKING"]     # a narrow board: 3 short lines
    width_of_the_box = 0                                    # as wide as the widest word line ...
    for one_line_of_words in lines_of_words:
        if art.text_width(one_line_of_words) > width_of_the_box:
            width_of_the_box = art.text_width(one_line_of_words)
    width_of_the_box = width_of_the_box + 10                # ... plus some room
    height_of_the_box = len(lines_of_words) * 9 + 6         # 9 pixels per line + some room
    left_edge_of_the_box = (the_picture['width'] - width_of_the_box) // 2   # in the middle of the board
    top_edge_of_the_box = (the_picture['height'] - height_of_the_box) // 2
    fill_box(the_picture, left_edge_of_the_box, top_edge_of_the_box, width_of_the_box, height_of_the_box, 245)   # grey edge
    fill_box(the_picture, left_edge_of_the_box + 1, top_edge_of_the_box + 1, width_of_the_box - 2, height_of_the_box - 2, 255)   # white inside
    for word_index in range(len(lines_of_words)):           # the words, one per line, centred
        one_line_of_words = lines_of_words[word_index]
        left_edge_of_the_words = (the_picture['width'] - art.text_width(one_line_of_words)) // 2
        top_edge_of_the_words = top_edge_of_the_box + 4 + word_index * 9
        art.draw_text(the_picture, one_line_of_words, left_edge_of_the_words, top_edge_of_the_words, 238)   # dark grey letters


def write_the_words_on_the_river(state_of_the_game, lines_of_the_picture, banner_drawing, pixels_per_square, width_of_the_board):
    # The banner drawing comes ready-made from art.py (BANNERS). We just
    # print its 3 lines in gold, on the blue river, in the middle of the river row.
    text_lines_per_square = pixels_per_square // 2          # how many text lines one square takes
    first_line_of_the_banner = state_of_the_game['river_row'] * text_lines_per_square + (text_lines_per_square - 3) // 2   # centred in the river
    for banner_line_number in range(3):                     # the banner's 3 lines:
        banner_text = center_line(banner_drawing[banner_line_number], width_of_the_board)
        banner_text = banner_text[0:width_of_the_board]     # never wider than the board
        lines_of_the_picture[first_line_of_the_banner + banner_line_number] = paint(banner_text, 220, art.RIVER_COLOR, bold=True)   # gold on blue


def add_the_frame_numbers_and_letters(state_of_the_game, lines_of_the_picture, pixels_per_square, width_of_the_board, rows_you_may_pick):
    # Adds the wooden frame, the row numbers on the left and the letters below
    text_lines_per_square = pixels_per_square // 2
    color_of_the_frame = art.FRAME_COLOR
    lines_of_the_screen = ["    " + paint("▄" * (width_of_the_board + 2), color_of_the_frame)]   # the top of the wooden frame
    for which_line in range(len(lines_of_the_picture)):     # every line of the board:
        which_row = which_line // text_lines_per_square     # which board row this line belongs to
        line_inside_the_square = which_line % text_lines_per_square   # which line inside that square (0, 1, 2 ...)
        row_label = "    "                                  # usually 4 spaces ...
        if line_inside_the_square == text_lines_per_square // 2 and which_row != state_of_the_game['river_row']:   # ... but on a square's middle line:
            row_number_text = pad_left(row_number_you_type(which_row, state_of_the_game), 3) + " "   # e.g. "  2 "
            if rows_you_may_pick == None or which_row in rows_you_may_pick:
                row_label = paint(row_number_text, 226, bold=True)   # yellow = you may pick this row
            else:
                row_label = paint(row_number_text, 240)     # grey = not yours to pick
        lines_of_the_screen.append(row_label + paint("█", color_of_the_frame) + lines_of_the_picture[which_line] + paint("█", color_of_the_frame))
    lines_of_the_screen.append("    " + paint("▀" * (width_of_the_board + 2), color_of_the_frame))   # the bottom of the frame

    letters_under_the_board = "     "                       # the column letters below the board
    for which_column in range(state_of_the_game['columns']):
        letters_under_the_board = letters_under_the_board + paint(center_line(LETTERS_OF_THE_COLUMNS[which_column], pixels_per_square), 223, bold=True)
    lines_of_the_screen.append(letters_under_the_board)
    return lines_of_the_screen


# =====================================================================
#  11) THE SIDE PANEL  (both players' crowns, then the CONTROLS box)
# =====================================================================
def build_the_side_panel(state_of_the_game, setup_or_battle):
    # Top: Player Two. Middle: Player One. Then the controls (controls.py).
    title_of_the_panel = state_of_the_game['title'] + "  -  " + board_size_as_text(state_of_the_game['level']) + " BOARD"   # "LEVEL 1  -  6x5 BOARD"
    lines_of_the_screen = [art.box_top(WIDTH_OF_THE_SIDE_PANEL, title_of_the_panel)]
    lines_of_the_screen = lines_of_the_screen + one_players_part_of_the_panel(state_of_the_game, 2)   # Player Two's part
    lines_of_the_screen.append(art.box_middle(WIDTH_OF_THE_SIDE_PANEL))
    lines_of_the_screen = lines_of_the_screen + one_players_part_of_the_panel(state_of_the_game, 1)   # Player One's part
    lines_of_the_screen.append(art.box_bottom(WIDTH_OF_THE_SIDE_PANEL))
    lines_of_the_screen.append("")
    lines_of_the_screen = lines_of_the_screen + controls.battle_controls(WIDTH_OF_THE_SIDE_PANEL, setup_or_battle, state_of_the_game['level'])   # the CONTROLS box
    return lines_of_the_screen


def one_players_part_of_the_panel(state_of_the_game, player_number):
    # One player's part: name, HP and crowns
    the_player = state_of_the_game['players'][player_number]
    hp_to_show = the_player['hp']
    if hp_to_show < 0:
        hp_to_show = 0                                      # never show less than 0
    name_and_hp_line = paint(the_player['name'], 231, bold=True) + paint("  " + the_player['pawn_word'], 244)
    name_and_hp_line = name_and_hp_line + paint("  HP " + str(hp_to_show) + "/" + str(STARTING_HEALTH), 252, bold=True)   # "HP 2/3"
    if state_of_the_game['turn'] == player_number:          # their turn? add a yellow ">> TURN" tag
        name_and_hp_line = pad_right(name_and_hp_line, WIDTH_OF_THE_SIDE_PANEL - 13) + paint(" >> TURN ", 16, 220, bold=True)
    lines_of_the_screen = [art.box_row(name_and_hp_line, WIDTH_OF_THE_SIDE_PANEL)]
    if player_number == 1:
        crown_lines_to_show = art.crown_lines(hp_to_show, True)   # white crowns
    else:
        crown_lines_to_show = art.crown_lines(hp_to_show, False)   # dark crowns
    for one_crown_line in crown_lines_to_show:
        lines_of_the_screen.append(art.box_row("  " + one_crown_line, WIDTH_OF_THE_SIDE_PANEL))
    return lines_of_the_screen


# =====================================================================
#  12) SMALL HELPERS
# =====================================================================
def which_side_owns_this_row(state_of_the_game, which_row):
    # Which player owns this row? 2 = above the river, 1 = below, 0 = the river
    if which_row < state_of_the_game['river_row']:
        return 2
    elif which_row > state_of_the_game['river_row']:
        return 1
    else:
        return 0


def what_trap_is_on_this_square(state_of_the_game, the_square):
    # 'bomb', 'life', or 'none' if there's no trap on this square
    if the_square in state_of_the_game['traps']:
        return state_of_the_game['traps'][the_square]
    else:
        return 'none'


def is_this_a_hidden_bomb(state_of_the_game, the_square):
    # True for a bomb that hasn't been flipped yet
    if what_trap_is_on_this_square(state_of_the_game, the_square) == 'bomb' and the_square not in state_of_the_game['flipped']:
        return True
    else:
        return False


def every_square_in_these_rows(state_of_the_game, which_rows):
    # Every square in these rows, from left to right, top to bottom
    list_of_squares = []
    for which_row in which_rows:                            # every row asked for
        for which_column in range(state_of_the_game['columns']):   # every column
            list_of_squares.append((which_row, which_column))   # the square (row, column)
    return list_of_squares


def count_the_safe_pawns_left(state_of_the_game, player_number):
    # How many unflipped pawns WITHOUT a trap this player still has
    how_many_so_far = 0
    for the_square in every_square_in_these_rows(state_of_the_game, state_of_the_game['players'][player_number]['rows']):   # every square on their side:
        if the_square not in state_of_the_game['flipped'] and the_square not in state_of_the_game['traps']:   # unflipped and no trap?
            how_many_so_far = how_many_so_far + 1
    return how_many_so_far


def count_the_hidden_bombs_left(state_of_the_game, player_number):
    # How many of this player's bombs are still hidden
    how_many_so_far = 0
    for the_square in every_square_in_these_rows(state_of_the_game, state_of_the_game['players'][player_number]['rows']):
        if is_this_a_hidden_bomb(state_of_the_game, the_square) == True:
            how_many_so_far = how_many_so_far + 1
    return how_many_so_far


def show_a_red_message(state_of_the_game, message_text):
    # A red message under the board, with a beep
    state_of_the_game['notice'] = message_text
    play_sound('error')


def row_number_you_type(which_row, state_of_the_game):
    # The row number you TYPE. On each side of the river the rows are
    # numbered 1, 2, 3 ... from the TOP down:
    #   Top player:    row 1 = the very top row of the board
    #   Bottom player: row 1 = the first row under the river
    # Gives back the number as text, e.g. "1"
    if which_row < state_of_the_game['river_row']:
        return str(which_row + 1)
    elif which_row > state_of_the_game['river_row']:
        return str(which_row - state_of_the_game['river_row'])
    else:
        return " "                                          # the river has no number


def name_of_the_square(the_square, state_of_the_game):
    # (row, column) -> "a1"
    which_row = the_square[0]                               # [0] = the row
    which_column = the_square[1]                            # [1] = the column
    return LETTERS_OF_THE_COLUMNS[which_column] + row_number_you_type(which_row, state_of_the_game)   # the column's letter + the row's number


def number_with_st_nd_rd_th(the_number):
    # 1 -> 1ST, 2 -> 2ND, 3 -> 3RD, 4 -> 4TH ...
    match the_number:
        case 1:
            return "1ST"
        case 2:
            return "2ND"
        case 3:
            return "3RD"
        case _:
            return str(the_number) + "TH"                   # 4TH, 5TH ... 13TH


# =====================================================================
#  13) THE BONUS STAGE  (pops up at random before or after a campaign level)
#
#  HOW TO PLAY
#   Your white pawn runs down the board. Bombs and coins fall toward
#   you, one row at a time, faster and faster. Press A (left) or D
#   (right) - NO Enter needed - to dodge the bombs and grab the coins.
#   Survive 20 seconds! A bomb ends the stage early, but you keep every
#   coin you already grabbed.
#
#  IN THE ORDER THINGS HAPPEN
#   1) "BONUS STAGE!" flashes                     show_the_bonus_stage_announcement
#   2) again and again, until time is up:         play_the_bonus_stage
#       a) draw the board                         draw_the_bonus_stage
#       b) for a short moment, look for A or D    which_key_was_just_pressed
#       c) everything falls down one row          move_everything_down_one_row
#       d) did a bomb or a coin land on the pawn?
#       e) a new bomb (and sometimes a coin) at the top   drop_new_bombs_and_coins
#   3) "BONUS DONE!" and the coins you earned     show_the_bonus_stage_results
#
#  LANES AND ROWS
#   The track is 5 lanes wide (0 = left ... 4 = right) and 5 rows tall
#   (0 = top ... 4 = bottom). Your pawn is always on the bottom row.
#   Every falling thing is a list of 3 things:  [row, lane, 'bomb' or 'coin']
# =====================================================================
NUMBER_OF_BONUS_LANES = 5                                   # how many lanes wide
NUMBER_OF_BONUS_ROWS = 5                                    # how many rows tall
PIXELS_PER_BONUS_SQUARE = 16                                # pixels per square
HOW_MANY_SECONDS_THE_BONUS_STAGE_LASTS = 20                 # how long the bonus stage lasts
COINS_FOR_EACH_COIN_GRABBED = 10                            # coins for each coin you grab
CHANCE_OF_A_COIN_IN_PERCENT = 45                            # % chance that a coin falls together with a bomb


def play_the_bonus_stage():
    play_music('bonus')
    show_the_bonus_stage_announcement()

    # What the bonus stage remembers
    lane_of_the_pawn = 2                    # the pawn starts in the middle lane (lanes 0 to 4)
    things_falling = []                     # the bombs and coins falling right now
    coins_grabbed_so_far = 0
    steps_so_far = 0
    hit_by_a_bomb = False
    time_when_it_ends = time.time() + HOW_MANY_SECONDS_THE_BONUS_STAGE_LASTS

    read_keys_without_enter()               # A and D work without Enter now
    try:
        # Repeat until the time is up, or a bomb hits you
        while time.time() < time_when_it_ends and hit_by_a_bomb == False:
            seconds_left_on_the_clock = int(time_when_it_ends - time.time()) + 1

            # STEP 1: how long this step lasts (0.4 seconds, a bit faster every step, never under 0.18)
            seconds_per_step = 0.4 - steps_so_far * 0.004
            if seconds_per_step < 0.18:
                seconds_per_step = 0.18

            # STEP 2: draw the board
            present(draw_the_bonus_stage(lane_of_the_pawn, things_falling, steps_so_far, coins_grabbed_so_far, seconds_left_on_the_clock), extra_below=0, clear=False)

            # STEP 3: during this step, the player may press A or D
            time_when_this_step_ends = time.time() + seconds_per_step
            while time.time() < time_when_this_step_ends:
                key_that_was_pressed = which_key_was_just_pressed()
                new_lane = move_the_pawn(lane_of_the_pawn, key_that_was_pressed)
                if new_lane != lane_of_the_pawn:          # the pawn moved:
                    lane_of_the_pawn = new_lane
                    play_sound('step')
                    present(draw_the_bonus_stage(lane_of_the_pawn, things_falling, steps_so_far, coins_grabbed_so_far, seconds_left_on_the_clock), extra_below=0, clear=False)
                time.sleep(0.02)                          # rest a tiny moment, then look again

            # STEP 4: everything falls down one row
            things_falling = move_everything_down_one_row(things_falling)

            # STEP 5: did something land on the pawn? (bottom row, same lane)
            for one_falling_thing in things_falling:
                which_row = one_falling_thing[0]
                which_lane = one_falling_thing[1]
                what_it_is = one_falling_thing[2]
                if which_row == NUMBER_OF_BONUS_ROWS - 1 and which_lane == lane_of_the_pawn:
                    if what_it_is == 'bomb':              # a bomb: the stage is over
                        hit_by_a_bomb = True
                    else:                                 # a coin: grab it
                        coins_grabbed_so_far = coins_grabbed_so_far + 1
                        play_sound('coin')

            # STEP 6: new bombs and coins appear at the top
            drop_new_bombs_and_coins(things_falling)
            steps_so_far = steps_so_far + 1
    finally:
        put_the_keyboard_back_to_normal()   # always runs, even after Ctrl+C: Enter works again

    # STEP 7: the end
    if hit_by_a_bomb == True:
        play_bomb_animation("CRASH! THE BONUS STAGE IS OVER.")
    show_the_bonus_stage_results(coins_grabbed_so_far)


def move_the_pawn(lane_of_the_pawn, key_that_was_pressed):
    # Gives back the pawn's new lane.
    if key_that_was_pressed == 'a' and lane_of_the_pawn > 0:                          # A, not at the left edge
        return lane_of_the_pawn - 1
    if key_that_was_pressed == 'd' and lane_of_the_pawn < NUMBER_OF_BONUS_LANES - 1:  # D, not at the right edge
        return lane_of_the_pawn + 1
    return lane_of_the_pawn                                                           # any other key: stay


# ---------------------------------------------------------------------
#  READING A KEY WITHOUT ENTER
#   Normally the keyboard waits for Enter before Python sees your keys.
#   For the bonus stage we switch that off, so A and D work at once.
#   Windows has a tool for this called msvcrt.
#   Mac and Linux use termios / tty (the switch) and select (the look).
# ---------------------------------------------------------------------
the_normal_keyboard_settings = None                         # the keyboard's normal settings (Mac/Linux), to put back later


def read_keys_without_enter():
    # Every key arrives the moment it is pressed (no Enter needed)
    global the_normal_keyboard_settings
    if os.name == "nt":                                     # Windows: msvcrt already works this way
        return
    try:
        import termios
        import tty
        the_normal_keyboard_settings = termios.tcgetattr(sys.stdin)   # remember the normal settings
        tty.setcbreak(sys.stdin)                            # every key at once
    except Exception:
        the_normal_keyboard_settings = None                 # it didn't work: nothing to put back


def which_key_was_just_pressed():
    # Gives back the key that was just pressed ('a', 'd' ...), or "" if none.
    # It does NOT wait: it only takes a quick look.
    if os.name == "nt":                                     # Windows:
        import msvcrt
        if msvcrt.kbhit():                                  # was a key pressed?
            key_that_was_pressed = msvcrt.getwch()          # take that key
            return key_that_was_pressed.lower()
        else:
            return ""
    else:                                                   # Mac and Linux:
        import select
        keys_waiting = select.select([sys.stdin], [], [], 0)   # is a key waiting? (0 = don't wait)
        if len(keys_waiting[0]) > 0:                        # yes:
            key_that_was_pressed = sys.stdin.read(1)        # take that key
            return key_that_was_pressed.lower()
        else:
            return ""


def put_the_keyboard_back_to_normal():
    # The keyboard waits for Enter again, and keys pressed during the
    # bonus stage are thrown away (so they don't end up in the next question)
    global the_normal_keyboard_settings
    if os.name == "nt":                                     # Windows:
        import msvcrt
        while msvcrt.kbhit():                               # as long as keys are waiting ...
            msvcrt.getwch()                                 # ... take one and throw it away
    else:                                                   # Mac and Linux:
        if the_normal_keyboard_settings != None:
            import termios
            termios.tcsetattr(sys.stdin, termios.TCSADRAIN, the_normal_keyboard_settings)   # back to normal
            termios.tcflush(sys.stdin, termios.TCIFLUSH)    # throw away waiting keys
            the_normal_keyboard_settings = None


def show_the_bonus_stage_announcement():
    # "BONUS STAGE!" flashing gold and fire, 6 times
    for flash_number in range(6):
        if flash_number % 2 == 0:                           # every other flash: gold ...
            title_colors = art.GOLD
        else:                                               # ... or fire
            title_colors = art.FIRE
        the_title = art.big_text("BONUS STAGE!", title_colors, 2, 94)
        lines_of_the_screen = []
        for one_line in the_title:
            lines_of_the_screen.append(one_line)
        lines_of_the_screen.append("")
        lines_of_the_screen.append(center_line(paint("Dodge the bombs, grab the coins!   A = left   D = right", 231, bold=True), art.widest_line(the_title)))
        present(lines_of_the_screen, extra_below=0, clear=False)
        play_sound('beep')
        time.sleep(0.35)


def draw_the_bonus_stage(lane_of_the_pawn, things_falling, steps_so_far, coins_grabbed_so_far, seconds_left_on_the_clock):
    # The running track on the left, the time and coins on the right
    width_of_the_track = NUMBER_OF_BONUS_LANES * PIXELS_PER_BONUS_SQUARE
    height_of_the_track = NUMBER_OF_BONUS_ROWS * PIXELS_PER_BONUS_SQUARE
    the_picture = new_picture(width_of_the_track, height_of_the_track)   # 5 x 5 squares of 16 pixels
    for which_row in range(NUMBER_OF_BONUS_ROWS):           # every square:
        for which_lane in range(NUMBER_OF_BONUS_LANES):
            # The checkerboard shifts every step, so it looks like you're running
            if (which_row + which_lane + steps_so_far) % 2 == 0:
                color_of_the_square = art.DARK_SQUARE
            else:
                color_of_the_square = art.LIGHT_SQUARE
            fill_box(the_picture, which_lane * PIXELS_PER_BONUS_SQUARE, which_row * PIXELS_PER_BONUS_SQUARE, PIXELS_PER_BONUS_SQUARE, PIXELS_PER_BONUS_SQUARE, color_of_the_square)
    for one_falling_thing in things_falling:                # every falling thing:
        which_row = one_falling_thing[0]
        which_lane = one_falling_thing[1]
        what_it_is = one_falling_thing[2]
        if what_it_is == 'bomb':
            draw_sprite(the_picture, art.BOMB_16, which_lane * PIXELS_PER_BONUS_SQUARE, which_row * PIXELS_PER_BONUS_SQUARE, art.BOMB_COLORS)
        else:                                               # a coin (twice as big, to fill the square)
            draw_sprite(the_picture, art.make_bigger(art.COIN_8, 2), which_lane * PIXELS_PER_BONUS_SQUARE, which_row * PIXELS_PER_BONUS_SQUARE, art.COIN_COLORS)
    draw_sprite(the_picture, art.PAWN_16, lane_of_the_pawn * PIXELS_PER_BONUS_SQUARE, (NUMBER_OF_BONUS_ROWS - 1) * PIXELS_PER_BONUS_SQUARE, art.WHITE_PIECE)   # your pawn

    # A wooden frame around the track
    the_track = [paint("▄" * (width_of_the_track + 2), art.FRAME_COLOR)]   # the top of the frame
    for one_line in picture_to_lines(the_picture):
        the_track.append(paint("█", art.FRAME_COLOR) + one_line + paint("█", art.FRAME_COLOR))   # the sides
    the_track.append(paint("▀" * (width_of_the_track + 2), art.FRAME_COLOR))   # the bottom

    # The box on the right: seconds left, coins, controls
    box_on_the_right = [art.box_top(36, "BONUS STAGE")]
    box_on_the_right.append(art.box_row(paint("SECONDS LEFT", 250), 36))
    for one_line in art.big_text(str(seconds_left_on_the_clock), art.ICE, 2, 18):   # the seconds in big numbers
        box_on_the_right.append(art.box_row(one_line, 36))
    box_on_the_right.append(art.box_row(paint("COINS GRABBED", 250), 36))
    box_on_the_right.append(art.box_row(paint(str(coins_grabbed_so_far) + " x " + str(COINS_FOR_EACH_COIN_GRABBED), 220, bold=True), 36))
    box_on_the_right.append(art.box_bottom(36))
    box_on_the_right.append("")
    box_on_the_right = box_on_the_right + controls.bonus_controls(36)   # the CONTROLS box (controls.py)

    the_title = art.big_text("BONUS STAGE", art.GOLD, 1, 94)
    track_and_box = art.side_by_side([the_track, art.empty_lines(3) + box_on_the_right], 4)   # the track left, the box right
    width_of_the_track = art.widest_line(track_and_box)
    lines_of_the_screen = art.center_block(the_title, width_of_the_track)   # the title on top
    lines_of_the_screen.append("")
    lines_of_the_screen = lines_of_the_screen + track_and_box   # then the rest
    return lines_of_the_screen


def move_everything_down_one_row(things_falling):
    # Everything moves down one row. Things that fall off the bottom are gone.
    things_after_moving = []
    for one_falling_thing in things_falling:
        row_after_moving = one_falling_thing[0] + 1         # one row lower
        if row_after_moving < NUMBER_OF_BONUS_ROWS:         # still on the board?
            things_after_moving.append([row_after_moving, one_falling_thing[1], one_falling_thing[2]])
    return things_after_moving


def drop_new_bombs_and_coins(things_falling):
    # A bomb appears in a random lane at the top; sometimes a coin too,
    # in a different lane
    lane_of_the_new_bomb = random.randint(0, NUMBER_OF_BONUS_LANES - 1)   # a random lane: 0 to 4
    things_falling.append([0, lane_of_the_new_bomb, 'bomb'])
    if random.randint(1, 100) <= CHANCE_OF_A_COIN_IN_PERCENT:   # a 45% chance of a coin:
        lane_of_the_new_coin = random.randint(0, NUMBER_OF_BONUS_LANES - 1)
        while lane_of_the_new_coin == lane_of_the_new_bomb:   # not in the bomb's lane:
            lane_of_the_new_coin = random.randint(0, NUMBER_OF_BONUS_LANES - 1)   # roll again
        things_falling.append([0, lane_of_the_new_coin, 'coin'])


def show_the_bonus_stage_results(coins_grabbed_so_far):
    coins_earned = coins_grabbed_so_far * COINS_FOR_EACH_COIN_GRABBED   # e.g. 3 coins x 10 = 30
    add_coins(coins_earned)                                 # add them to your coins
    is_a_new_best = record_best('best_bonus_stage', coins_earned)   # True if it's a new best

    the_title = art.big_text("BONUS DONE!", art.GOLD, 2, 94)
    width_of_the_screen = art.widest_line(the_title) + 10
    lines_of_the_screen = art.center_block(the_title, width_of_the_screen)
    lines_of_the_screen.append("")
    lines_of_the_screen.append(center_line(paint("You grabbed " + str(coins_grabbed_so_far) + " coins", 231, bold=True), width_of_the_screen))
    lines_of_the_screen.append(center_line(paint("YOU EARNED " + str(coins_earned) + " COINS", 220, bold=True), width_of_the_screen))
    if is_a_new_best == True:
        lines_of_the_screen.append(center_line(paint("NEW BEST SCORE!", 213, bold=True), width_of_the_screen))
    lines_of_the_screen.append("")
    lines_of_the_screen.append(center_line(art.coin_text(game_memory['coins']) + paint(" in total", 250), width_of_the_screen))
    present(lines_of_the_screen)
    wait_for_enter()