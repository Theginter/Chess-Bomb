# This game uses "match / case" (Python's "switch case"), which needs
# Python 3.10 or newer. Check that FIRST, so an older Python shows a
# clear message instead of a confusing error.
import sys                                          # sys.version_info = which Python is running
if sys.version_info < (3, 10):                      # older than 3.10?
    print("CHESS BOMB needs Python 3.10 or newer. Get it from python.org")
    sys.exit()                                      # stop here

# "import" = borrow tools that are written in another file.
# "from display import setup_window" = from the file display.py, borrow the tool called setup_window.
from display import setup_window, restore_window    # getting the terminal ready (display.py)
from sound import start_audio, stop_audio           # switch the music on / off (sound.py)
from animations import play_intro                   # the RSMRV PRODUCTIONS intro (animations.py)
from menus import launch_main_menu                  # the title screen with its 5 buttons (menus.py)

# =====================================================================
#  FILE 1 of 11:  MAIN.PY  -  START HERE.   CHESS BOMB by RSMRV PRODUCTIONS
#
#  HOW TO START THE GAME
#   Open Command Prompt, PowerShell or Windows Terminal (NOT IDLE)
#   in this folder and type:     python main.py
#   For music, install pygame once:   pip install pygame
#   The window must be at least 192 x 54 (see README.md, TROUBLESHOOTING).
#
#  WHAT THIS FILE DOES (in this order)
#   1) gets the terminal ready (colours on)               -> display.py
#   2) switches the music on                              -> sound.py
#   3) plays the RSMRV PRODUCTIONS intro                  -> animations.py
#   4) opens the main menu - the rest of the game is
#      reached from there                                 -> menus.py
#   5) when you pick [5] EXIT: switches the music off, and
#      asks if you want to go back in (type 1)
#
#  ALL THE FILES (read them in this order)
#    1  main.py          START HERE (this file)
#    2  settings.py      every number of the game + what it remembers (coins, levels)
#    3  display.py       colours, pixel pictures, showing screens, asking questions
#    4  art.py           every drawing, the big letters, boxes and buttons
#    5  animations.py    every moving picture (the intro, BOOM, victory ...)
#    6  menus.py         the main menu, the guide, the campaign, 1V1
#    7  battle.py        the board, the rules, the bonus stage
#    8  mini_games.py    the mini games menu and the 3 mini games
#    9  sound.py         music and sound effects (the sounds/ folder)
#   10  controls.py      the CONTROLS boxes
#   11  cheats.py        the secret codes l, p and 69
#
#  HOW TO READ THE COMMENTS
#   Everything after a # is a COMMENT: a note for people. Python skips it.
# =====================================================================


# "def" = define (make) a FUNCTION: a named list of steps.
# The steps only run when the function is CALLED (at the very bottom).
def start_the_game():
    setup_window()                 # 1) colours on
    start_audio()                  # 2) music + sounds (silent if pygame isn't installed)
    try:                           # "try" = run the steps below, but watch out for the "except" cases
        play_intro()               # 3) RSMRV PRODUCTIONS presents...
        keep_playing = True
        while keep_playing == True:    # repeat as long as keep_playing is True
            launch_main_menu()     # 4) THE GAME. It comes back here after [5] EXIT.
            stop_audio()           # 5) music off ...
            restore_window()       #    ... and the terminal looks normal again
            keep_playing = wants_to_go_back()   # ask "type 1 to go back": True or False
            if keep_playing == True:
                start_audio()      #    typed 1: music on again, then back to the menu
    except KeyboardInterrupt:      # someone pressed Ctrl+C ...
        restore_window()           # ... so the game simply closes, with a normal terminal
    except EOFError:               # the window was closed ...
        restore_window()           # ... so close the game too
    finally:
        # "finally" ALWAYS runs at the very end, even after Ctrl+C,
        # so the music is always switched off.
        stop_audio()


def wants_to_go_back():
    # After [5] EXIT the terminal looks normal again. Typing 1 jumps back into the game.
    print("Thanks for playing CHESS BOMB!   - RSMRV PRODUCTIONS")
    print()
    answer = input("Type 1 and press Enter to go back to the game (or just press Enter to leave): ")
    answer = answer.strip()        # strip() removes spaces typed by accident
    if answer == "1":
        return True                # go back
    else:
        return False               # leave


# Python only runs this when you start THIS file (python main.py).
# It is at the bottom because Python must read the functions above first.
if __name__ == "__main__":
    start_the_game()               # this is where the game really starts
