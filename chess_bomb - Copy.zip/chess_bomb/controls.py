from display import paint, pad_right    # colours and lining up text (display.py)
import art                               # the box pieces (art.py)
from settings import UNLOCK_LEVEL_FOR_SCAN   # the level the scan unlocks (5)

# =====================================================================
#  FILE 10 of 11:  CONTROLS.PY  -  THE CONTROLS BOXES
#
#  WHAT THIS FILE DOES
#   It builds the little CONTROLS boxes that tell you which keys to
#   type. Want to change what a box says? Change it here.
#
#   battle_controls(width, mode, level)   the box next to the battle board
#   bonus_controls(width)                 the box in the bonus stage
# =====================================================================


def battle_controls(width, mode, level):
    # The CONTROLS box next to the board.
    #   mode  = 'setup' (hiding traps) or 'battle'
    #   level = the level being played (the scan line changes at level 5)
    lines = []
    lines.append(art.box_top(width, "CONTROLS"))
    if mode == 'setup':                              # while hiding traps
        lines.append(control_row("a1", "hide a trap under that pawn", width))
        lines.append(control_row("0", "back to the menu", width))
    else:                                            # in the battle
        lines.append(control_row("a1", "flip that enemy pawn", width))
        if level >= UNLOCK_LEVEL_FOR_SCAN:
            lines.append(control_row("1", "sacrifice scan", width))
        else:
            lines.append(control_row("1", "sacrifice scan (level " + str(UNLOCK_LEVEL_FOR_SCAN) + "+)", width))
        lines.append(control_row("0", "quit & back to menu", width))
    lines.append(art.box_bottom(width))
    return lines


def bonus_controls(width):
    # The CONTROLS box in the bonus stage
    lines = []
    lines.append(art.box_top(width, "CONTROLS"))
    lines.append(control_row("A", "move left", width))
    lines.append(control_row("D", "move right", width))
    lines.append(art.box_row(paint("no Enter needed!", 244), width))
    lines.append(art.box_bottom(width))
    return lines


def control_row(key, meaning, width):
    # One line of a CONTROLS box:   a1     flip that enemy pawn
    key_text = paint(pad_right(key, 7), 222, bold=True)     # the key in yellow
    meaning_text = paint(meaning, 250)                      # what it does in grey
    return art.box_row(key_text + meaning_text, width)
