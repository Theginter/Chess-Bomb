import os    # os = files and folders (to find the sound files)

# =====================================================================
#  FILE 9 of 11:  SOUND.PY  -  MUSIC AND SOUND EFFECTS
#
#  WHAT THIS FILE DOES
#   It plays the music and the little sound effects (boom, coin, tick ...).
#   The sounds are ready-made .wav files in the "sounds" folder.
#
#  THE 5 THINGS IT CAN DO
#   start_audio()          switch the speakers on and load the sound effects
#   play_music('battle')   play a song over and over (until another song starts)
#   play_jingle('victory') play a short song just once
#   play_sound('boom')     play one sound effect
#   stop_audio()           switch the speakers off
#
#  WHAT PLAYS THE SOUND?  pygame
#   pygame is an add-on for Python. We only use its sound part (called
#   "mixer"); it never opens a window. Install it once with:
#        pip install pygame
#   No pygame? Then every function below just does nothing and the game
#   is silent. Nothing breaks.
# =====================================================================

os.environ["PYGAME_HIDE_SUPPORT_PROMPT"] = "1"    # stops pygame printing "Hello from pygame"
try:
    import pygame                                 # try to borrow pygame ...
except ImportError:
    pygame = None                                 # ... it isn't installed: we stay silent

# The "sounds" folder, right next to this file
THIS_FOLDER = os.path.dirname(os.path.abspath(__file__))   # the folder sound.py is in
SOUND_FOLDER = os.path.join(THIS_FOLDER, "sounds")        # that folder + "/sounds"

MUSIC_VOLUME = 0.45        # 0.0 = silent, 1.0 = loudest
EFFECTS_VOLUME = 0.7       # the volume of the sound effects

# Every song: the name the game uses -> its file in the sounds folder.
# Want your own music? Put a .wav file in the sounds folder and change the file name here.
SONGS = {
    'intro': "music_intro.wav",
    'menu': "music_menu.wav",
    'map': "music_map.wav",
    'battle': "music_battle.wav",
    'bonus': "music_bonus.wav",
    'race': "music_race.wav",
    'ticktock': "music_ticktock.wav",
    'flip': "music_flip.wav",
    'victory': "music_victory.wav",
    'defeat': "music_defeat.wav",
}

# Every sound effect. 'boom' is the file sounds/sfx_boom.wav, and so on.
EFFECTS = ['boom', 'heal', 'zap', 'scan', 'flip', 'select', 'error', 'beep', 'go',
           'step', 'correct', 'coin', 'tick', 'whoosh', 'thud']

# What this file remembers while the game runs
sound_is_on = False        # True once the speakers are switched on
song_playing_now = ""      # the name of the song playing right now ("" = no song)
effects = {}               # the loaded sound effects: effects['boom'] = the boom sound


def start_audio():
    # Switch the speakers on and load every sound effect (once).
    global sound_is_on
    if pygame == None:                       # no pygame:
        return                               # the game stays silent
    try:
        pygame.mixer.pre_init(22050, -16, 1, 512)   # the sound quality the .wav files were made in
        pygame.mixer.init()                         # switch the speakers on
        pygame.mixer.set_num_channels(16)           # allow up to 16 sounds at the same time
        for name in EFFECTS:                        # every effect name ('boom', 'heal' ...):
            file = os.path.join(SOUND_FOLDER, "sfx_" + name + ".wav")   # e.g. sounds/sfx_boom.wav
            if os.path.exists(file):                # only if the file is really there:
                effect = pygame.mixer.Sound(file)   # load it
                effect.set_volume(EFFECTS_VOLUME)   # set its volume
                effects[name] = effect              # keep it under its name
        sound_is_on = True                          # everything worked: sound is on
    except Exception:                               # no speakers / no sound driver:
        sound_is_on = False                         # stay silent


def play_music(name, repeat=True):
    # Start a song. repeat=True = loop it forever, repeat=False = play it once.
    # If that song is ALREADY playing, nothing happens (it doesn't restart).
    global song_playing_now
    if sound_is_on == False:                 # no sound: do nothing
        return
    if name not in SONGS:                    # a song we don't know: do nothing
        return
    if name == song_playing_now and pygame.mixer.music.get_busy():   # already playing:
        return                               # leave it playing
    song_playing_now = name                  # remember which song is on now
    file = os.path.join(SOUND_FOLDER, SONGS[name])   # where its file is
    if os.path.exists(file) == False:        # the file is missing:
        return
    try:
        pygame.mixer.music.load(file)               # load the song
        pygame.mixer.music.set_volume(MUSIC_VOLUME) # set its volume
        if repeat == True:
            pygame.mixer.music.play(-1)             # -1 = loop forever
        else:
            pygame.mixer.music.play(0)              # 0 = play it once
    except Exception:
        pass                                        # it didn't work: carry on silently


def play_jingle(name):
    # A short song played once (victory, defeat).
    # Forgetting the current song first makes sure it always starts.
    global song_playing_now
    song_playing_now = ""
    play_music(name, False)


def play_sound(name):
    # Play one sound effect, e.g. play_sound('boom')
    if sound_is_on == False:                 # no sound: do nothing
        return
    if name not in effects:                  # not loaded: do nothing
        return
    try:
        effects[name].play()                 # play it
    except Exception:
        pass                                 # it didn't work: carry on silently


def stop_audio():
    # Switch the music and the speakers off
    global sound_is_on
    if sound_is_on == True:                  # only if sound was on:
        try:
            pygame.mixer.music.fadeout(300)  # fade the music out over 0.3 seconds
            pygame.mixer.quit()              # switch the speakers off
        except Exception:
            pass
    sound_is_on = False                      # remember: sound is off now
