import random      # random = dice rolls
import time        # time = waiting, and the clock
from settings import *               # every setting + game_memory, add_coins, record_best
from display import present, ask, ask_in_box, wait_for_enter          # showing screens and asking
from display import new_picture, set_pixel, fill_box, draw_sprite, picture_to_lines   # pixel pictures
from display import paint, center_line                                 # colours and lining up text
import art                                           # every drawing (art.py)
from animations import play_racing_intro, play_tick_tock_intro, play_flip_intro, play_bomb_animation
from sound import play_music, play_sound
from battle import read_keys_without_enter, which_key_was_just_pressed, put_the_keyboard_back_to_normal   # keys without Enter (battle.py)

# =====================================================================
#  FILE 8 of 11:  MINI_GAMES.PY  -  THE MINI GAMES
#
#  PART 1: THE MINI GAMES MENU    three cards, locked ones are grey
#  PART 2: SCREENS THEY SHARE     the title screen and the guide screen
#  PART 3: RACING PIECE           bet coins on a racing knight   (level 5)
#  PART 4: TICK TOCK              find the knight before the bomb blows (level 7)
#  PART 5: FLIP THE KING          type the arrows in time         (level 9)
#
#  Every mini game works the same way:
#   open_...()   plays its intro (animations.py), then the title screen
#                with START (1) / GUIDE (2) / MENU (3)
#   play_...()   one game
# =====================================================================


# =====================================================================
#  PART 1: THE MINI GAMES MENU
# =====================================================================
def open_mini_games_menu():
    notice = ""                                            # a red message ("" = none)
    while True:                                            # until 0 = back
        play_music('menu')
        present(build_menu_screen(notice))
        notice = ""
        typed = ask(paint("Pick a mini game (1-3) or 0:", 230, bold=True))

        match typed:
            case '0':
                return                                     # back to the main menu
            case '1':
                if game_memory['highest_unlocked_level'] >= RACING_PIECE_UNLOCK:
                    open_racing_piece()
                else:
                    notice = "RACING PIECE unlocks at campaign level " + str(RACING_PIECE_UNLOCK) + "."
            case '2':
                if game_memory['highest_unlocked_level'] >= TICK_TOCK_UNLOCK:
                    open_tick_tock()
                else:
                    notice = "TICK TOCK unlocks at campaign level " + str(TICK_TOCK_UNLOCK) + "."
            case '3':
                if game_memory['highest_unlocked_level'] >= FLIP_THE_KING_UNLOCK:
                    open_flip_the_king()
                else:
                    notice = "FLIP THE KING unlocks at campaign level " + str(FLIP_THE_KING_UNLOCK) + "."
            case _:
                notice = "Type a number from the list."


def any_mini_game_unlocked():
    # True as soon as the first mini game is open (main menu button 4)
    if game_memory['highest_unlocked_level'] >= RACING_PIECE_UNLOCK:
        return True
    else:
        return False


def build_menu_screen(notice):
    # The whole MINI GAMES screen: one card per mini game
    card_1 = mini_game_card("[1] RACING PIECE", "Bet coins on a racing knight",
                            RACING_PIECE_UNLOCK, game_memory['best_racing_piece'], "biggest win")
    card_2 = mini_game_card("[2] TICK TOCK", "Read the board before the bomb blows",
                            TICK_TOCK_UNLOCK, game_memory['best_tick_tock'], "seconds left")
    card_3 = mini_game_card("[3] FLIP THE KING", "Type the arrows in time",
                            FLIP_THE_KING_UNLOCK, game_memory['best_flip_the_king'], "flips")
    row_of_cards = art.side_by_side([card_1, card_2, card_3], 3)
    width = art.widest_line(row_of_cards)

    lines = art.center_block(art.big_text("MINI GAMES", art.ICE, 2, 18), width)
    lines.append("")
    lines.append(center_line(art.coin_text(game_memory['coins']), width))
    lines.append("")
    lines = lines + art.center_block(row_of_cards, width)
    lines.append("")
    lines = lines + art.center_block(art.make_button("[0] BACK TO MENU", 22), width)
    if notice != "":
        lines.append(center_line(paint(notice, 203, bold=True), width))
    return lines


def mini_game_card(title, about, unlock_level, best, best_words):
    # One card: its name, what it is, and your best score (or LOCKED)
    if game_memory['highest_unlocked_level'] >= unlock_level:          # open:
        rows = [[about, 252], ["Best: " + str(best) + " " + best_words, 222]]
        return art.text_box(title, rows, 44, 223)                      # a gold card
    else:                                                              # still locked:
        rows = [["LOCKED", 242], ["Reach campaign level " + str(unlock_level), 242]]
        return art.text_box(title, rows, 44, 240)                      # a grey card


# =====================================================================
#  PART 2: THE SCREENS EVERY MINI GAME SHARES
# =====================================================================
def title_screen(title_lines, picture_lines, song):
    # START / GUIDE / MENU. Gives back '1', '2' or '3'.
    buttons = art.make_button("START  (1)", 22, 220)
    buttons = buttons + art.make_button("GUIDE  (2)", 22)     # + = put it below the one before
    buttons = buttons + art.make_button("MENU   (3)", 22)
    middle = art.side_by_side([picture_lines, buttons], 8)    # the picture left, the buttons right
    width = art.widest_line(middle)
    if art.widest_line(title_lines) > width:
        width = art.widest_line(title_lines)
    width = width + 4

    lines = art.center_block(title_lines, width)
    lines.append("")
    lines = lines + art.center_block(middle, width)
    lines.append("")
    lines.append(center_line(art.coin_text(game_memory['coins']), width))
    while True:                                               # ask until 1, 2 or 3
        play_music(song)
        present(lines)
        typed = ask(paint("Choose 1, 2 or 3:", 230, bold=True))
        match typed:
            case '1' | '2' | '3':
                return typed                                  # anything else: ask again


def guide_screen(rows):
    # rows = a list of guide rows (art.guide_row): a picture left, the rule right
    lines = art.center_block(art.big_text("GUIDE", art.GOLD, 2, 94), 140)
    lines.append("")
    for row in rows:
        lines = lines + row
        lines.append("")
    present(lines)
    wait_for_enter("Press Enter to go back...")


# =====================================================================
#  PART 3: RACING PIECE  (bet on a racing knight)
#
#  HOW TO PLAY
#   Four knights race across the screen. Pick the knight you think will
#   win (1-4) and bet some coins. If your knight comes 1st you win 3
#   times your bet. If not, you lose your bet.
#
#  HOW THE RACE WORKS
#   Each knight has a position (how far along the track it is). Every
#   frame, each knight moves forward a RANDOM amount (0 to 4 pixels),
#   so nobody knows who will win. The first past the finish line wins.
#   The knights run in lanes 0, 1, 2, 3; on screen they are 1, 2, 3, 4.
# =====================================================================
TRACK_LENGTH = 140      # pixels from start to finish
LANE_HEIGHT = 18        # pixels per lane
SMALLEST_BET = 10       # you must bet at least 10 coins
PAYOUT = 3              # win = 3 x your bet



def open_racing_piece():
    play_music('race')
    play_racing_intro()                                          # the intro (animations.py)
    title = art.big_text("RACING PIECE", art.GOLD, 2, 94)
    knight = art.sprite_lines(art.make_bigger(art.KNIGHT_16_RIGHT, 2), art.KNIGHT_COLORS[0])   # a big red knight
    while True:                                                  # until MENU (3)
        choice = title_screen(title, knight, 'race')
        match choice:
            case '1':                                            # START
                play_race()
            case '2':                                            # GUIDE: 3 rules, each with a picture
                rows = []
                rows.append(art.guide_row(mini_track(),
                    ["Four knights race to the checkered line. Pick the one you think will win."], 231))
                rows.append(art.guide_row(art.side_by_side([art.clock_box("3", 10), art.clock_box("BET:20", 12)], 2),
                    ["Type your knight (1-4), then how many coins to bet (at least " + str(SMALLEST_BET) + ")."], 220))
                rows.append(art.guide_row(art.big_text("1ST: 3", art.GOLD, 1, 94) + ["", art.coin_text(20 * PAYOUT)],
                    ["Your knight comes 1st?  You win " + str(PAYOUT) + "x your bet!  If not, you lose the bet."], 120))
                guide_screen(rows)
            case '3':                                            # MENU
                return


def play_race():
    start = [2, 2, 2, 2]                         # every knight starts 2 pixels from the left
    if game_memory['coins'] < SMALLEST_BET:      # not enough coins to bet?
        present(race_screen(start, "", "", "You need at least " + str(SMALLEST_BET) + " coins to bet!", ""))
        wait_for_enter("Win campaign levels or bonus stages to earn coins. Press Enter...")
        return

    # a) pick a knight (in the LEFT clock box)
    my_knight = ask_for_knight(start)
    if my_knight == 0:                           # typed 0: back
        return

    # b) pick a bet (in the RIGHT clock box). The bet is paid now.
    bet = ask_for_bet(start, my_knight)
    add_coins(-bet)
    knight_text = str(my_knight)                 # shown in the left clock box
    bet_text = "BET:" + str(bet)                 # shown in the right clock box

    # c) 3, 2, 1, GO!
    for word in ["3", "2", "1", "GO!"]:
        present(race_screen(start, knight_text, bet_text, "", word), extra_below=0)
        if word == "GO!":
            play_sound('go')
        else:
            play_sound('beep')
        time.sleep(0.6)

    # d) the race: every frame each knight moves a random bit, until one crosses the finish
    positions = [2, 2, 2, 2]
    finish = TRACK_LENGTH - 12                   # where the finish line is
    winner = -1                                  # -1 = nobody has won yet
    while winner == -1:
        for lane in range(4):                    # every knight moves 0 to 4 pixels
            positions[lane] = positions[lane] + random.randint(0, 4)
        winner = first_past_the_finish(positions, finish)
        if winner != -1:                         # someone crossed:
            positions[winner] = finish           # stop them right on the line
        present(race_screen(positions, knight_text, bet_text, "Go knight " + knight_text + "!", ""), extra_below=0, clear=False)
        time.sleep(0.07)

    # e) the result
    winner_number = winner + 1                   # lanes count from 0, knights from 1
    if winner_number == my_knight:               # your knight won!
        prize = bet * PAYOUT                     # 3 x your bet
        add_coins(bet + prize)                   # your bet back + the prize
        play_sound('coin')
        record_best('best_racing_piece', prize)  # maybe a new best
        message = "YOUR KNIGHT WON!  +" + str(prize) + " COINS"
    else:                                        # another knight won
        play_sound('thud')
        message = "Knight " + str(winner_number) + " won. You lost " + str(bet) + " coins."
    present(race_screen(positions, knight_text, "1ST: " + str(winner_number), message, "1ST: " + str(winner_number)))
    wait_for_enter()


def ask_for_knight(start):
    # Typed in the LEFT clock box. Gives back 1-4, or 0 (back)
    while True:                                  # ask until 0-4
        typed = ask_in_box(race_screen(start, "", "", "Which knight will win? Type 1, 2, 3 or 4  (0 = back)", ""),
                           art.CLOCK_BOX_TYPING_COLUMN)
        match typed:
            case '0':
                return 0
            case '1' | '2' | '3' | '4':
                return int(typed)                # int("2") -> the number 2


def ask_for_bet(start, my_knight):
    # Typed in the RIGHT clock box, after the word "BET:".
    # The left box is 18 characters wide (with its buttons), then a 6 space gap.
    right_box_column = 18 + 6 + art.CLOCK_BOX_TYPING_COLUMN + 4    # 4 = the length of "BET:"
    while True:                                  # ask until a good bet
        hint = "How many coins? " + str(SMALLEST_BET) + " to " + str(game_memory['coins']) + "  (Enter = " + str(SMALLEST_BET) + ")"
        typed = ask_in_box(race_screen(start, str(my_knight), "BET:", hint, ""), right_box_column)
        if typed == "":
            return SMALLEST_BET                  # just Enter = the smallest bet
        if typed.isdigit():                      # only digits?
            bet = int(typed)                     # the text as a number
            if bet >= SMALLEST_BET and bet <= game_memory['coins']:   # not too small, not more than you have?
                return bet


def first_past_the_finish(positions, finish):
    # Gives back the lane (0-3) of the knight that crossed the finish,
    # or -1 if nobody crossed yet. If several crossed in the same frame,
    # the one furthest along wins.
    winner = -1
    for lane in range(4):
        if positions[lane] >= finish:            # crossed the line?
            if winner == -1:                     # the first one we found
                winner = lane
            elif positions[lane] > positions[winner]:   # further along than the one we found?
                winner = lane
    return winner


def race_screen(positions, knight_text, bet_text, hint, banner):
    # The title, the race, and two clock boxes: your knight and your bet
    title = art.big_text("RACING PIECE", art.GOLD, 1, 94)
    track = draw_race(positions, banner)                         # the 4 lanes with the knights
    width = art.widest_line(track)
    lines = art.center_block(title, width)
    lines.append(center_line(art.coin_text(game_memory['coins']), width))
    lines.append("")
    lines = lines + track
    lines.append("")
    left_box = art.clock_box(knight_text, 14)                    # your knight
    right_box = art.clock_box(bet_text, 18)                      # your bet
    boxes = art.side_by_side([left_box, right_box], 6)           # the two boxes side by side
    lines.append(boxes[0])
    lines.append(boxes[1])
    lines.append(boxes[2] + "   " + paint(hint, 230))            # the hint next to the typing line
    lines.append(boxes[3])
    return lines


def draw_race(positions, banner):
    # positions = how far along each of the 4 knights is (in pixels)
    # banner    = big words across the track ("3", "GO!" ...), "" = none
    picture = new_picture(TRACK_LENGTH + 20, 4 * LANE_HEIGHT)
    for lane in range(4):                                        # every lane:
        top = lane * LANE_HEIGHT                                 # where the lane starts
        fill_box(picture, 0, top, TRACK_LENGTH + 20, LANE_HEIGHT, art.lane_color(lane))     # the ground
        fill_box(picture, 0, top + LANE_HEIGHT - 1, TRACK_LENGTH + 20, 1, 94)          # the lane line
        art.draw_finish_line(picture, TRACK_LENGTH + 4, TRACK_LENGTH + 10, top, top + LANE_HEIGHT)
        draw_sprite(picture, art.KNIGHT_16_RIGHT, positions[lane], top + 1, art.KNIGHT_COLORS[lane])
    if banner != "":
        banner_left = (picture['width'] - art.text_width(banner, 2)) // 2    # centred
        art.draw_text(picture, banner, banner_left, 2 * LANE_HEIGHT - 8, art.GOLD, 2, 94)
    return add_lane_numbers(picture_to_lines(picture), 9, 4)     # 9 text lines per lane, number on line 4


def add_lane_numbers(picture_lines, lines_per_lane, number_on_line):
    # Puts the lane numbers 1 2 3 4 on the left of the track
    lines = []
    for index in range(len(picture_lines)):
        if index % lines_per_lane == number_on_line:   # the lane's middle line:
            lane = index // lines_per_lane             # which lane this line is in
            label = paint(" " + str(lane + 1) + " ", 231, bold=True)   # its number
        else:
            label = "   "
        lines.append(label + picture_lines[index])
    return lines


def mini_track():
    # A small picture of the race, for the guide
    picture = new_picture(64, 40)
    knight_spots = [30, 44, 12, 22]                    # where each small knight stands
    for lane in range(4):
        fill_box(picture, 0, lane * 10, 64, 10, art.lane_color(lane))
        art.draw_finish_line(picture, 56, 60, lane * 10, lane * 10 + 10)
        draw_sprite(picture, art.KNIGHT_8_RIGHT, knight_spots[lane], lane * 10 + 1, art.KNIGHT_COLORS[lane])
    return add_lane_numbers(picture_to_lines(picture), 5, 2)


# =====================================================================
#  PART 4: TICK TOCK  ("CHESS CLOCK")
#
#  HOW TO PLAY
#   A bomb with a little chessboard on it is ticking (0:30). A knight
#   appears on one square. Type that square's name (like c3) and press
#   Enter. Get 4 right to finish the code and defuse it!
#   One wrong answer, or running out of time = BOOM.
#
#  HOW THE CLOCK WORKS
#   When the bomb starts, the game writes down the clock time when it
#   will explode (time.time() = the computer's clock, in seconds).
#   Every time you press Enter, it looks at the clock again: if that
#   time has passed, it's too late - BOOM.
# =====================================================================
SECONDS = 30              # the clock starts at 0:30
CODES_NEEDED = 4          # right answers needed to defuse the bomb
COINS_FOR_DEFUSING = 30   # + 1 coin for every second left
TICK_COLUMNS = "abcde"    # the little board is 5 columns ...
TICK_ROWS = 4             # ... by 4 rows
TICK_SQUARE = 10          # pixels per square


def open_tick_tock():
    play_music('ticktock')
    play_tick_tock_intro()                                       # the intro (animations.py)
    title = art.big_text("TICK TOCK", art.FIRE, 3, 52)
    title.append(center_line(paint("C H E S S    C L O C K", 222, bold=True), art.widest_line(title)))
    picture = art.sprite_lines(art.make_bigger(art.BOMB_16, 2), art.BOMB_COLORS)   # a big bomb
    while True:                                                  # until MENU (3)
        choice = title_screen(title, picture, 'ticktock')
        match choice:
            case '1':                                            # START
                play_tick_tock()
            case '2':                                            # GUIDE: 4 rules, each with a picture
                rows = []
                rows.append(art.guide_row(mini_board_with_knight(),
                    ["Find the KNIGHT. Its square is the letter on top + the number on the side."], 231))
                rows.append(art.guide_row(art.clock_box("c3", 10),
                    ["Type that square (here: c3) and press Enter."], 222))
                rows.append(art.guide_row(art.big_text("0:30", art.ICE, 2, 18),
                    ["The ticking clock. Don't let it reach 0:00!"], 203))
                rows.append(art.guide_row([code_slots(['ok', 'ok', 'ok'])],
                    ["The code. Get " + str(CODES_NEEDED) + " right to defuse the bomb. One wrong answer = BOOM!"], 46))
                guide_screen(rows)
            case '3':                                            # MENU
                return


def play_tick_tock():
    play_music('ticktock')
    results = []                  # 'ok' or 'x' for every answer
    last_answer = ""              # what you typed last time (shown in the clock box)
    knight = random_square((-1, -1))   # where the knight is: (row, column)
    message = "Where is the knight?"
    end_time = time.time() + SECONDS              # the clock time when it explodes
    seconds_left = SECONDS                        # 30 at the start

    while len(results) < CODES_NEEDED:            # until all 4 answers are right:
        present(tick_tock_screen(knight, seconds_left, results, last_answer, message, False))
        play_sound('tick')
        typed = ask(paint("Knight's square (like c3), 0 = give up  >", 230, bold=True))
        last_answer = typed

        # How many whole seconds are left now? (0.2 seconds still counts as 1)
        time_left = end_time - time.time()
        if time_left <= 0:
            seconds_left = 0
        else:
            seconds_left = int(time_left) + 1

        if typed == '0':                          # give up
            return
        elif seconds_left <= 0:                   # too late!
            show_boom(knight, 0, results, "TIME'S UP!")
            return
        elif answer_matches(typed, knight) == True:   # right!
            results.append('ok')
            play_sound('correct')
            message = "CORRECT! Next one..."
            knight = random_square(knight)        # the knight jumps somewhere else
        else:                                     # wrong!
            results.append('x')
            show_boom(knight, seconds_left, results, "WRONG SQUARE!")
            return

    # all 4 right: defused!
    coins = COINS_FOR_DEFUSING + seconds_left     # faster = more coins
    add_coins(coins)
    play_sound('coin')
    message = "DEFUSED! +" + str(coins) + " COINS"
    if record_best('best_tick_tock', seconds_left) == True:   # a new best time?
        message = message + "  NEW BEST!"
    present(tick_tock_screen((-1, -1), seconds_left, results, "", message, False))   # (-1, -1) = no knight
    wait_for_enter()


def random_square(not_this_one):
    # A random (row, column), but never the same square twice in a row
    while True:                                  # try until it's a different square
        row = random.randint(0, TICK_ROWS - 1)   # a random row: 0 to 3
        column = random.randint(0, len(TICK_COLUMNS) - 1)   # a random column: 0 to 4
        if (row, column) != not_this_one:
            return (row, column)


def answer_matches(typed, square):
    # "c3" is right for the square (2, 2). "3c" is accepted too.
    letter = TICK_COLUMNS[square[1]]         # column 2 -> "c"
    number = str(square[0] + 1)              # row 2 -> "3"
    if typed == letter + number:             # "c3"
        return True
    elif typed == number + letter:           # "3c"
        return True
    else:
        return False


def show_boom(knight, seconds_left, results, message):
    present(tick_tock_screen(knight, seconds_left, results, "", message, True))   # "YOU LOSE" on the bomb
    time.sleep(1.2)
    play_bomb_animation("TICK... TOCK... BOOM!")
    present(tick_tock_screen(knight, seconds_left, results, "", "The bomb went off. Try again!", True))
    wait_for_enter()


def tick_tock_screen(knight_square, seconds_left, results, typed, message, lose):
    # The bomb on the left; the clock, the code and your last answer on the right

    # The clock text, e.g. 0:07
    minutes = seconds_left // 60                       # whole minutes
    seconds = seconds_left % 60                        # % 60 = the seconds left over after the minutes
    if seconds < 10:
        clock_text = str(minutes) + ":0" + str(seconds)    # 0:07
    else:
        clock_text = str(minutes) + ":" + str(seconds)     # 0:25
    if seconds_left > 10:
        clock_colors = art.ICE
    else:
        clock_colors = art.BLOOD                       # red for the last 10 seconds

    side = art.big_text(clock_text, clock_colors, 3, 18)        # the big clock
    side.append("")
    side.append(paint("THE CODE", 250))
    side.append(code_slots(results))                            # [ OK ] [ OK ] [    ] ...
    side.append("")
    side = side + art.clock_box(typed, 16)                      # your last answer
    side.append("")
    side.append(paint(message, 230, bold=True))
    side.append("")
    side.append(paint("Type the knight's square, then Enter", 244))
    side.append(paint("0 = give up", 244))

    bomb = draw_bomb(knight_square, lose)
    body = art.side_by_side([bomb, art.empty_lines(12) + side], 6)   # bomb left, the rest right
    title = art.big_text("TICK TOCK", art.FIRE, 1, 52)
    width = art.widest_line(body)
    lines = art.center_block(title, width)
    lines.append("")
    lines = lines + body
    return lines


def draw_bomb(knight_square, lose):
    # knight_square = (row, column) of the knight, or (-1, -1) for no knight
    picture = new_picture(100, 94)

    # The round bomb body: a 20 x 20 drawing made 4 times bigger (80 x 80)
    draw_sprite(picture, art.make_bigger(art.BOMB_BODY_20, 4), 10, 12, {'k': 236, 'h': 242})

    # The grey cap, the fuse and the spark on top
    fill_box(picture, 42, 6, 16, 7, 244)               # the cap
    for step in range(10):                             # the fuse: 10 pixels going up to the right
        set_pixel(picture, 58 + step, 6 - step // 2, 223)
    fill_box(picture, 67, 0, 3, 3, 208)                # the spark: orange ...
    set_pixel(picture, 68, 1, 226)                     # ... with a yellow middle

    # The little chessboard (a-e across, 1-4 down), the knight's square in yellow
    left = 50 - (len(TICK_COLUMNS) * TICK_SQUARE) // 2     # centred on the bomb
    top = 52 - (TICK_ROWS * TICK_SQUARE) // 2
    for row in range(TICK_ROWS):
        for column in range(len(TICK_COLUMNS)):
            if knight_square == (row, column):         # the knight's square:
                color = 222                            # yellow
            elif (row + column) % 2 == 0:
                color = art.LIGHT_SQUARE
            else:
                color = art.DARK_SQUARE
            fill_box(picture, left + column * TICK_SQUARE, top + row * TICK_SQUARE, TICK_SQUARE, TICK_SQUARE, color)
    if knight_square != (-1, -1):                      # draw the knight on its square
        knight_left = left + knight_square[1] * TICK_SQUARE + 1
        knight_top = top + knight_square[0] * TICK_SQUARE + 1
        draw_sprite(picture, art.KNIGHT_8, knight_left, knight_top, art.BLACK_PIECE)

    # Letters above and below, numbers on both sides
    for column in range(len(TICK_COLUMNS)):
        letter = TICK_COLUMNS[column]
        art.draw_text(picture, letter, left + column * TICK_SQUARE + 2, top - 9, 252)                        # above
        art.draw_text(picture, letter, left + column * TICK_SQUARE + 2, top + TICK_ROWS * TICK_SQUARE + 2, 252)   # below
    for row in range(TICK_ROWS):
        art.draw_text(picture, str(row + 1), left - 8, top + row * TICK_SQUARE + 2, 252)                    # left
        art.draw_text(picture, str(row + 1), left + len(TICK_COLUMNS) * TICK_SQUARE + 3, top + row * TICK_SQUARE + 2, 252)   # right

    if lose == True:                                   # a red "YOU LOSE" band
        fill_box(picture, left - 4, top + TICK_SQUARE, len(TICK_COLUMNS) * TICK_SQUARE + 8, TICK_SQUARE, 124)
        art.draw_text(picture, "YOU LOSE", 50 - art.text_width("YOU LOSE") // 2, top + TICK_SQUARE + 2, 231)
    return picture_to_lines(picture)


def code_slots(results):
    # results = a list like ['ok', 'ok', 'x']  ->  [ OK ] [ OK ] [ XX ] [    ]
    text = ""
    for slot in range(CODES_NEEDED):                       # 4 slots:
        if slot >= len(results):                           # not answered yet
            text = text + paint("[    ]", 244)
        elif results[slot] == 'ok':                        # answered right
            text = text + paint("[ OK ]", 46, bold=True)
        else:                                              # answered wrong
            text = text + paint("[ XX ]", 196, bold=True)
        text = text + " "
    return text


def mini_board_with_knight():
    # The guide picture: the little a-e / 1-4 board with the knight on c3
    picture = new_picture(40, 32)                        # 5 x 4 squares of 8 pixels
    for row in range(4):
        for column in range(5):
            if row == 2 and column == 2:
                color = 222                              # the knight's square: yellow
            elif (row + column) % 2 == 0:
                color = art.LIGHT_SQUARE
            else:
                color = art.DARK_SQUARE
            fill_box(picture, column * 8, row * 8, 8, 8, color)
    draw_sprite(picture, art.KNIGHT_8, 16, 16, art.BLACK_PIECE)   # the knight on c3
    letters = "  "                                       # the letters above the board
    for letter in TICK_COLUMNS:
        letters = letters + paint(center_line(letter, 8), 252, bold=True)
    lines = [letters]
    picture_lines = picture_to_lines(picture)
    for index in range(len(picture_lines)):              # every line of the board:
        if index % 4 == 2:                               # the middle line of each square:
            label = paint(str(index // 4 + 1) + " ", 252, bold=True)   # the row number
        else:
            label = "  "
        lines.append(label + picture_lines[index])
    return lines


# =====================================================================
#  PART 5: FLIP THE KING
#
#  HOW TO PLAY
#   Arrows come one by one. Type the letter for the arrow in the big box
#   (w = up, a = left, s = down, d = right) and press Enter, before the
#   time runs out. Every right answer turns the king 45 degrees.
#   8 right answers = one full FLIP (+5 coins). You get less time after
#   every flip!  Wrong letter or too slow: the KING FELL (-10 coins).
#
#  HOW THE KING TURNS
#   art.py has a drawing of the king for every turn (KING_0, KING_45_BIG,
#   KING_90 ...). king_picture() just picks the right one.
# =====================================================================
COINS_PER_FLIP = 5              # coins for every full flip
COINS_LOST_WHEN_FALLING = 10    # coins lost when the king falls
ARROW_COLORS_BIG = {'o': 94, 'w': 229}                   # the arrow to press
GREY_ARROW_COLORS = {'o': 240, 'w': 250}                 # the arrows coming next


def open_flip_the_king():
    play_music('flip')
    play_flip_intro()                                            # the intro (animations.py)
    title = art.big_text("FLIP THE KING", art.GOLD, 2, 94)
    # The picture on the title screen: an arrow, the king, another arrow
    up_arrow = art.sprite_lines(art.make_bigger(art.ARROW_UP, 2), ARROW_COLORS_BIG)
    right_arrow = art.sprite_lines(art.make_bigger(art.ARROW_RIGHT, 2), ARROW_COLORS_BIG)
    picture = art.side_by_side([up_arrow, king_picture(0), right_arrow], 2)
    while True:                                                  # until MENU (3)
        choice = title_screen(title, picture, 'flip')
        match choice:
            case '1':                                            # START
                keep_playing = True
                while keep_playing == True:                      # keep playing while you pick RETRY
                    keep_playing = play_flip_the_king()
            case '2':                                            # GUIDE: 4 rules, each with a picture
                standing_king = art.sprite_lines(art.KING_0, art.KING_COLORS)
                fallen_king = art.sprite_lines(art.KING_90, art.KING_COLORS)
                rows = []
                rows.append(art.guide_row(small_arrow_box('right'),
                    ["The big box: press its letter (w a s d) - no Enter - before the time bar runs out."], 220))
                rows.append(art.guide_row(upcoming_row(['down', 'up', 'down', 'up']),
                    ["The upcoming arrows (they come in a random order)."], 250))
                rows.append(art.guide_row(art.picture_story([standing_king, fallen_king]),
                    ["Every right key turns the king. 8 right keys = 1 full FLIP = +" + str(COINS_PER_FLIP) + " coins."], 222))
                rows.append(art.guide_row(fallen_king + [paint("KING FELL   -" + str(COINS_LOST_WHEN_FALLING), 203, bold=True)],
                    ["Wrong key or too slow: the king falls and you lose " + str(COINS_LOST_WHEN_FALLING) + " coins."], 203))
                guide_screen(rows)
            case '3':                                            # MENU
                return


def play_flip_the_king():
    # One game. Gives back True if you pick [1] RETRY at the end.
    play_music('flip')
    # The arrows coming up: 6 random ones to start (queue[0] = the one to press now)
    queue = []
    for number in range(6):
        queue.append(random_arrow())
    degrees = 0                     # how far the king is turned (0, 45, 90 ... 315)
    flips = 0                       # full flips so far
    last_key_text = ""              # shown in the right clock box, e.g. "UP  OK"
    message = "Get ready..."

    present(flip_screen(0, queue, flips, last_key_text, message, False, 30), extra_below=0)
    time.sleep(1.2)                                               # a moment to get ready
    read_keys_without_enter()                                     # w a s d work without Enter now
    try:
        how_it_ended = keep_flipping(queue, flips, degrees, last_key_text, message)
    finally:
        put_the_keyboard_back_to_normal()                         # always runs: Enter works again
    if how_it_ended == 'quit':                # typed 0:
        return False                                              # back to the title screen
    flips = how_it_ended[0]
    last_key_text = how_it_ended[1]
    return show_the_king_fell(queue, flips, last_key_text)


def keep_flipping(queue, flips, degrees, last_key_text, message):
    # Arrow after arrow, until the king falls.
    # Gives back 'quit' (typed 0), or [flips, last_key_text] when the king fell.
    while True:                                                   # arrow after arrow:
        current = queue[0]                                        # the arrow to press now
        seconds_allowed = 3.0 - flips * 0.2                       # less time after every flip ...
        if seconds_allowed < 1.5:
            seconds_allowed = 1.5                                 # ... but never under 1.5 seconds
        answer = ask_for_arrow(seconds_allowed, degrees, queue, flips, last_key_text, message)
        if answer == 'quit':                                      # typed 0:
            return 'quit'
        if answer == 'too slow':
            return [flips, "TOO SLOW  X"]                         # the king falls
        if answer != current:                                     # the wrong letter
            return [flips, "WRONG  X"]                            # the king falls

        # The right letter! Turn the king a bit more
        degrees = degrees + 45
        last_key_text = answer.upper() + "  OK"
        play_sound('whoosh')
        message = "Nice!"
        if degrees == 360:                                        # all the way around!
            flips = flips + 1
            degrees = 0                                           # standing up again
            play_sound('coin')
            message = "FULL FLIP! +" + str(COINS_PER_FLIP) + " coins"
        queue.pop(0)                                              # remove the arrow just done ...
        queue.append(random_arrow())                              # ... and add a new one at the end


def show_the_king_fell(queue, flips, last_key_text):
    # THE KING FELL. Gives back True if you pick [1] RETRY.
    play_sound('thud')
    earned = flips * COINS_PER_FLIP                               # coins from the flips
    add_coins(earned - COINS_LOST_WHEN_FALLING)                   # + the flips, - the fall
    message = "YOU LOSE - KING FELL!   -" + str(COINS_LOST_WHEN_FALLING) + " coins"
    if earned > 0:
        message = message + "   (+" + str(earned) + " from flips)"
    if record_best('best_flip_the_king', flips) == True:
        message = message + "   NEW BEST!"
    lines = flip_screen(0, queue, flips, last_key_text, message, True, 0)
    lines.append("")
    lines.append(center_line(paint("[1] RETRY      [Enter] BACK", 220, bold=True), art.widest_line(lines)))
    present(lines)
    typed = ask(paint(">", 230, bold=True))
    if typed == '1':
        return True                                               # retry
    else:
        return False


def random_arrow():
    # 'up', 'right', 'down' or 'left', picked at random
    return random.choice(['up', 'right', 'down', 'left'])


def ask_for_arrow(seconds_allowed, degrees, queue, flips, last_key_text, message):
    # Waits for ONE key (no Enter needed) while the time bar shrinks.
    # Gives back 'up' / 'down' / 'left' / 'right', 'too slow', 'wrong' or 'quit'.
    start = time.time()                                           # the clock when the arrow appeared
    blocks_on_screen = -1                                         # how many bar blocks are drawn now (-1 = none yet)
    while True:
        seconds_taken = time.time() - start                       # how long the player is taking
        if seconds_taken > seconds_allowed:                       # the time is up:
            return 'too slow'

        # The time bar: 30 blocks when the arrow appears, 0 when the time is up.
        # Draw the screen again only when the bar got shorter.
        blocks_left = 30 - int(seconds_taken * 30 / seconds_allowed)
        if blocks_left != blocks_on_screen:
            present(flip_screen(degrees, queue, flips, last_key_text, message, False, blocks_left), extra_below=0, clear=False)
            blocks_on_screen = blocks_left

        # A quick look: was a key pressed?
        key = which_key_was_just_pressed()                        # 'w', 'a' ... or "" (no key)
        match key:
            case 'w':
                return 'up'
            case 'a':
                return 'left'
            case 's':
                return 'down'
            case 'd':
                return 'right'
            case '0':
                return 'quit'
            case '' | '\r' | '\n':                               # no key, or Enter: keep waiting
                pass
            case _:                                               # any other key
                return 'wrong'
        time.sleep(0.02)                                          # rest a tiny moment, then look again


def flip_screen(degrees, queue, flips, last_key_text, message, fallen, blocks_left):
    # blocks_left = how much of the time bar is still full (30 = all of it, 0 = none)
    # The whole Flip the King screen
    title = art.big_text("FLIP THE KING", art.GOLD, 1, 94)
    if fallen == True:
        king = king_picture(90)              # lying on its side
        box_color = 196                      # a red box
    else:
        king = king_picture(degrees)         # turned as far as you got
        box_color = 223
    # The time bar: green when there's lots of time, then yellow, then red
    if blocks_left > 15:
        bar_color = 46                       # green
    elif blocks_left > 7:
        bar_color = 220                      # yellow
    else:
        bar_color = 196                      # red
    time_bar = paint("█" * blocks_left, bar_color) + paint("░" * (30 - blocks_left), 238)
    right = [paint("PRESS IT NOW!", 222, bold=True), paint("(w = up  a = left  s = down  d = right - no Enter!)", 244)]
    right = right + arrow_box(queue[0], box_color)
    right.append("")
    right.append(time_bar)
    right.append("")
    right.append(paint(message, 231, bold=True))
    middle = art.side_by_side([king, art.empty_lines(4) + right], 10)   # the king left, the arrow right

    score_box = art.clock_box("# " + str(flips) + " FLIPS", 16)   # the flips so far
    key_box = art.clock_box(last_key_text, 16)                    # the last key pressed
    bottom = art.side_by_side([score_box, key_box], 6)

    # The arrows coming next: every arrow in the queue except the first one
    coming_next = []
    for index in range(1, len(queue)):
        coming_next.append(queue[index])

    width = art.widest_line(middle) + 4
    lines = art.center_block(title, width)
    lines.append("")
    lines.append(center_line(paint("NEXT:", 244), width))
    lines = lines + art.center_block(upcoming_row(coming_next), width)   # the grey arrows coming next
    lines.append("")
    lines = lines + art.center_block(middle, width)
    lines.append("")
    lines = lines + art.center_block(bottom, width)
    return lines


def king_picture(degrees):
    # The big king, turned by 'degrees', as text lines (the drawings are in art.py)
    return art.sprite_lines(art.king_turned(degrees), art.KING_COLORS)


def arrow_sprite(direction):
    # The drawing of the arrow for 'up', 'right', 'down' or 'left'
    match direction:
        case 'up':
            return art.ARROW_UP
        case 'right':
            return art.ARROW_RIGHT
        case 'down':
            return art.ARROW_DOWN
        case _:
            return art.ARROW_LEFT


def arrow_box(direction, color):
    # The big "press it NOW" box (its border turns red when the king falls)
    picture = new_picture(30, 30)
    fill_box(picture, 0, 0, 30, 30, color)           # the coloured border ...
    fill_box(picture, 2, 2, 26, 26, 236)             # ... with a dark inside
    draw_sprite(picture, art.make_bigger(arrow_sprite(direction), 2), 3, 3, ARROW_COLORS_BIG)   # the big arrow
    return picture_to_lines(picture)


def upcoming_row(directions):
    # The grey arrows that come next, side by side
    picture = new_picture(len(directions) * 15, 12)
    for index in range(len(directions)):             # each arrow 15 pixels further right
        draw_sprite(picture, arrow_sprite(directions[index]), index * 15, 0, GREY_ARROW_COLORS)
    return picture_to_lines(picture)


def small_arrow_box(direction):
    # A smaller copy of the arrow box, for the guide
    picture = new_picture(16, 16)
    fill_box(picture, 0, 0, 16, 16, 223)             # the border
    fill_box(picture, 1, 1, 14, 14, 236)             # the dark inside
    draw_sprite(picture, arrow_sprite(direction), 2, 2, ARROW_COLORS_BIG)
    return picture_to_lines(picture)