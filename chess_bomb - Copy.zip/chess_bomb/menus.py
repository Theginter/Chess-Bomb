import random                    # random = dice rolls (for the bonus stage chance)
from settings import *           # every setting + game_memory, add_coins
from display import present, ask                                          # showing screens and asking
from display import new_picture, fill_box, draw_sprite, picture_to_lines # pixel pictures
from display import paint, center_line, visible_length                   # colours and lining up text
import art                       # every drawing (art.py)
from animations import play_victory_animation, play_unlock_animation
from battle import make_a_new_match, let_the_player_hide_their_traps, let_the_bot_hide_its_traps, play_the_whole_battle, show_the_whole_board_at_the_end
from battle import board_size_as_text, how_many_bombs_for_this_level, how_many_rows_for_this_level, how_many_columns_for_this_level
from battle import TOP_BAR_COLORS_YELLOW, TOP_BAR_COLORS_RED, play_the_bonus_stage, show_the_look_away_screen
from mini_games import open_mini_games_menu, any_mini_game_unlocked
from sound import play_music, play_jingle
import cheats                    # the secret codes l, p and 69 (cheats.py)

# =====================================================================
#  FILE 6 of 11:  MENUS.PY  -  THE MAIN MENU, THE CAMPAIGN AND 1V1
#
#  PART 1: THE MAIN MENU   the title screen with its 5 buttons
#     [1] START        -> the campaign map            (PART 3)
#     [2] PVP          -> 1V1                         (PART 4)
#     [3] GUIDE        -> 3 pages of rules            (PART 2)
#     [4] MINI GAMES   -> unlocks at level 5          (mini_games.py)
#     [5] EXIT         -> back to main.py
#
#   SECRET CODES: l, p and 69 (they live in cheats.py)
#
#  PART 2: THE GUIDE       3 pages, with a picture next to every rule
#  PART 3: THE CAMPAIGN    the level map, playing a level, winning/losing
#  PART 4: 1V1             two players on one computer
# =====================================================================
SCREEN_WIDTH = 168               # the title screen is 168 characters wide


# =====================================================================
#  PART 1: THE MAIN MENU
#  It keeps showing the title screen until you pick [5] EXIT.
# =====================================================================
def launch_main_menu():
    notice = ""                           # a message under the buttons ("" = none)
    while True:                           # repeat forever (until "return" leaves)
        play_music('menu')                # the menu song (keeps playing if it already is)
        present(build_title_screen(notice))   # build the title screen and show it
        notice = ""                       # the message has been shown: forget it
        choice = ask(paint("Select [1] [2] [3] [4] [5]:", 230, bold=True))   # wait for a choice

        # MATCH / CASE (Python's "switch case"): look at 'choice' and run
        # the ONE case that matches it.   case 'a' | 'b'  = "a or b"
        #                                 case _          = "anything else"
        match choice:
            case '1':                                         # the campaign
                open_campaign_map()
            case '2':                                         # 1V1
                start_hotseat_pvp()
            case '3':                                         # the guide
                show_guidelines()
            case '4':                                         # mini games
                if any_mini_game_unlocked() == True:          # at least one is open:
                    open_mini_games_menu()
                else:                                         # none open yet: say when they unlock
                    notice = "Mini games unlock when you reach campaign level " + str(RACING_PIECE_UNLOCK) + "!"
            case '5':                                         # exit
                return                    # back to main.py
            case 'l' | 'p' | '69':                            # a secret code (cheats.py)
                notice = cheats.use_cheat_code(choice)
            case _:                                           # anything else:
                notice = "Type a number from 1 to 5."


def build_title_screen(notice):
    # The logo, a little scene, the 5 buttons, and a status line

    # Button 4 is grey until a mini game is unlocked
    if any_mini_game_unlocked() == True:
        button_4 = art.make_button("[4] MINI GAMES", 26)
    else:
        button_4 = art.make_button("[4] LOCKED", 26, 223, False)
    buttons = art.side_by_side([
        art.make_button("[1] START", 26, 220),        # gold border
        art.make_button("[2] PVP", 26),
        art.make_button("[3] GUIDE", 26),
        button_4,
        art.make_button("[5] EXIT", 26, 174),         # red border
    ], 2)

    # The status line: level, coins, and which cheats are on
    status = paint("CAMPAIGN LEVEL " + str(game_memory['highest_unlocked_level']) + "/10", 222, bold=True)
    status = status + paint("   |   ", 244) + art.coin_text(game_memory['coins'])
    if game_memory['cheat_active'] == True:                           # x-ray cheat on?
        status = status + paint("   |   X-RAY ON", 213, bold=True)
    if game_memory['level_before_cheat'] != 0:                        # all-levels cheat on?
        status = status + paint("   |   ALL LEVELS CHEAT ON", 213, bold=True)

    # The logo: "CHESS" in steel + "BOMB" in fire
    chess = art.big_text("CHESS", art.STEEL, 2, 238)
    bomb = art.big_text("BOMB", art.FIRE, 2, 52)
    logo = art.side_by_side([chess, bomb], 6)

    # Everything centred, top to bottom
    width = SCREEN_WIDTH
    lines = art.center_block(logo, width)                             # 1. the logo
    lines.append("")
    lines = lines + art.center_block(title_scene(), width)            # 2. the little scene
    lines.append("")
    lines.append(center_line(paint("Hide your bombs. Flip their pawns. Protect your king.", 250), width))   # 3. the slogan
    lines.append("")
    lines = lines + art.center_block(buttons, width)                  # 4. the buttons
    lines.append("")
    lines.append(center_line(status, width))                          # 5. the status line
    lines.append(center_line(paint("made by RSMRV PRODUCTIONS", 244), width))
    if notice != "":                                                  # 6. a message, if there is one
        lines.append(center_line(paint(notice, 213, bold=True), width))
    return lines


def title_scene():
    # A little row of 7 chess squares: pawn, empty, bomb, extra life, bomb, empty, enemy pawn
    picture = new_picture(7 * 16, 16)                # 7 squares of 16 pixels, side by side
    for index in range(7):                           # every square:
        if index % 2 == 0:                           # light and dark squares take turns
            color = art.LIGHT_SQUARE
        else:
            color = art.DARK_SQUARE
        fill_box(picture, index * 16, 0, 16, 16, color)
    draw_sprite(picture, art.PAWN_16, 0 * 16, 0, art.WHITE_PIECE)     # square 0: a white pawn
    draw_sprite(picture, art.BOMB_16, 2 * 16, 0, art.BOMB_COLORS)     # square 2: a bomb
    draw_sprite(picture, art.LIFE_16, 3 * 16, 0, art.LIFE_COLORS)     # square 3: an extra life
    draw_sprite(picture, art.BOMB_16, 4 * 16, 0, art.BOMB_COLORS)     # square 4: a bomb
    draw_sprite(picture, art.PAWN_16, 6 * 16, 0, art.BLACK_PIECE)     # square 6: a black pawn
    # A wooden frame around it
    frame = art.FRAME_COLOR
    lines = [paint("▄" * (7 * 16 + 2), frame)]                        # the top of the frame
    for line in picture_to_lines(picture):                            # every line of the picture:
        lines.append(paint("█", frame) + line + paint("█", frame))    # with frame on both sides
    lines.append(paint("▀" * (7 * 16 + 2), frame))                    # the bottom of the frame
    return lines


# =====================================================================
#  PART 2: THE GUIDE: 3 pages, with a picture next to every rule
#   page 1  the pieces (pawn, bomb, extra life, board, HP)
#   page 2  the rules as before -> after pictures
#   page 3  how to type a square, and how to win
# =====================================================================
def show_guidelines():
    typed = guide_page("GUIDELINES", page_pieces(), 1)
    if typed == '0':
        return                                       # 0 = back to the menu straight away
    typed = guide_page("THE RULES", page_rules(), 2)
    if typed == '0':
        return
    guide_page("HOW TO PLAY", page_typing(), 3)


def guide_page(title, rows, page_number):
    # Shows one page. Gives back what was typed ('0' = back to the menu)
    lines = art.center_block(art.big_text(title, art.GOLD, 2, 94), 160)   # the big title
    lines.append("")
    for row in rows:                                 # every row (a picture + words):
        lines = lines + row
        lines.append("")
    present(lines)
    if page_number < 3:                              # not the last page:
        return ask(paint("Page " + str(page_number) + "/3   Enter = next page   |   0 = back to the menu", 250))
    else:                                            # the last page
        return ask(paint("Page 3/3   Enter = back to the menu", 250))


def page_pieces():
    # PAGE 1: every piece of the game, with its picture
    board = new_picture(30, 12)                    # a tiny board: 3 rows x 5 squares
    for row in range(3):
        for column in range(5):
            if row == 1:
                color = art.RIVER_COLOR            # the middle row is the river
            elif (row + column) % 2 == 0:
                color = art.LIGHT_SQUARE           # light and dark take turns
            else:
                color = art.DARK_SQUARE
            fill_box(board, column * 6, row * 4, 6, 4, color)   # each square is 6 x 4 pixels
    rows = []
    rows.append(art.guide_row(art.tile(art.PAWN_10, art.WHITE_PIECE, art.LIGHT_SQUARE, 12),
                              ["PAWN", "This is where you hide your bombs and extra life."], 231))
    rows.append(art.guide_row(art.tile(art.BOMB_10, art.BOMB_COLORS, art.LIGHT_SQUARE, 12),
                              ["BOMB", "The main weapon. Whoever flips an enemy bomb loses 1 HP."], 203))
    rows.append(art.guide_row(art.tile(art.LIFE_10, art.LIFE_COLORS, art.LIGHT_SQUARE, 12),
                              ["EXTRA LIFE", "Extra HP. Whoever flips it heals 1 HP."], 120))
    rows.append(art.guide_row(picture_to_lines(board),
                              ["THE BOARD", "Your pawns are at the bottom. The enemy is across the river."], 117))
    rows.append(art.guide_row(art.crown_lines(3, True),
                              ["YOUR HP", "The KING is your main HP. The QUEENS are your extra HP."], 222))
    return rows


def page_rules():
    # PAGE 2: what happens, shown as little before -> after pictures
    enemy_pawn = art.tile(art.PAWN_16, art.BLACK_PIECE)                      # a black pawn on a square
    bomb_found = art.tile(art.BOMB_16, art.BOMB_COLORS, art.BURNT_LIGHT)     # a bomb on a burnt square
    life_found = art.tile(art.LIFE_16, art.LIFE_COLORS)                      # an extra life on a square
    my_bomb = art.tile(art.BOMB_16, art.BOMB_COLORS, art.MY_BOMB_LIGHT)      # your own bomb (red tint)
    used_up = art.tile(art.HOLE_16, art.HOLE_COLORS)                         # an empty hole
    rows = []
    rows.append(art.guide_row(art.picture_story([enemy_pawn, bomb_found, art.crown_lines(2, True)]),
                              ["BOMB", "Flip an enemy bomb and YOU lose 1 HP", "(a queen falls)."], 203, 90))
    rows.append(art.guide_row(art.picture_story([enemy_pawn, life_found, art.crown_lines(3, True)]),
                              ["EXTRA LIFE", "Flip an enemy extra life and YOU heal 1 HP", "(a queen comes back)."], 120, 90))
    rows.append(art.guide_row(art.picture_story([art.crown_lines(3, True), life_found, art.crown_lines(2, False)]),
                              ["OVERFLOW", "Find an extra life when your HP is FULL...", "...and the ENEMY loses 1 HP instead!"], 159, 90))
    rows.append(art.guide_row(art.picture_story([my_bomb, used_up, enemy_pawn, bomb_found]),
                              ["SACRIFICE SCAN  (level " + str(UNLOCK_LEVEL_FOR_SCAN) + " and up, type 1)",
                               "Blow up one of YOUR hidden bombs to look", "under one enemy pawn safely."], 222, 90))
    return rows


def page_typing():
    # PAGE 3: how to type a square, and how to win

    # A small example board (4 x 5) with the square "b2" in yellow
    board = new_picture(40, 50)                    # 4 columns, 5 rows of 10 x 10 pixels
    for row in range(5):
        for column in range(4):
            left = column * 10
            top = row * 10
            if row == 2:                           # the middle row is the river
                fill_box(board, left, top, 10, 10, art.RIVER_COLOR)
            else:
                if row == 1 and column == 1:
                    color = art.LAST_MOVE_LIGHT    # the square "b2" in yellow
                elif (row + column) % 2 == 0:
                    color = art.LIGHT_SQUARE
                else:
                    color = art.DARK_SQUARE
                fill_box(board, left, top, 10, 10, color)
                if row < 2:
                    draw_sprite(board, art.PAWN_10, left, top, art.BLACK_PIECE)   # the enemy's pawns on top
                else:
                    draw_sprite(board, art.PAWN_10, left, top, art.WHITE_PIECE)   # your pawns at the bottom
    board_lines = picture_to_lines(board)          # 25 text lines (5 per square)

    # The yellow row numbers on the left. Each square is 5 lines tall,
    # and the number goes on its middle line (line 2, 7, 12 ...).
    labelled = []
    for index in range(len(board_lines)):
        if index == 2 or index == 17:              # the 1st row of each side
            label = paint(" 1 ", 226, bold=True)
        elif index == 7 or index == 22:            # the 2nd row of each side
            label = paint(" 2 ", 226, bold=True)
        else:
            label = "   "
        labelled.append(label + board_lines[index])
    labelled.append("   " + paint("    a         b         c         d", 223, bold=True))   # the letters below

    # The words next to it, with a clock box showing "b2"
    words = []
    words.append(paint("HOW TO PICK A SQUARE", 222, bold=True))
    words.append("")
    words.append(paint("Letter = the column (letters at the bottom)", 252))
    words.append(paint("Number = the row (yellow numbers on the left)", 252))
    words.append(paint("On each side the rows count 1, 2, 3 ... from the top down.", 252))
    words.append("")
    words.append(paint("Type it in the clock box and press Enter:", 252))
    words = words + art.clock_box("b2", 14)

    # "no crowns  OR  every pawn flipped  =  YOU WIN!"
    no_crowns = art.crown_lines(0, False)          # three dark (lost) crowns
    all_flipped = art.side_by_side([art.tile(art.HOLE_16, art.HOLE_COLORS),
                                    art.tile(art.HOLE_16, art.HOLE_COLORS, art.DARK_SQUARE),
                                    art.tile(art.HOLE_16, art.HOLE_COLORS)], 0)   # three flipped squares
    win_row = art.side_by_side([no_crowns, art.empty_lines(3) + [paint("  OR  ", 231, bold=True)], all_flipped,
                                art.empty_lines(3) + [paint("  =  YOU WIN!", 220, bold=True)]], 2)
    how_to_win = [paint("HOW TO WIN: take all of the enemy's crowns, or flip every one of their safe pawns.", 231, bold=True), ""]

    rows = []
    rows.append(art.side_by_side([labelled, art.empty_lines(3) + words], 8))   # the board + how to type
    rows.append(how_to_win + win_row)                                          # how to win
    return rows


# ##############################################################################
# ##############################################################################
# ##                                                                          ##
# ##     ____    _    __  __ ____   _    ___ ____ _   _                       ##
# ##    / ___|  / \  |  \/  |  _ \ / \  |_ _/ ___| \ | |                      ##
# ##   | |     / _ \ | |\/| | |_) / _ \  | | |  _|  \| |                      ##
# ##   | |___ / ___ \| |  | |  __/ ___ \ | | |_| | |\  |                      ##
# ##    \____/_/   \_\_|  |_|_| /_/   \_\___\____|_| \_|                      ##
# ##                                                                          ##
# ##   PART 3: THE CAMPAIGN  -  every campaign function is in here,           ##
# ##   from this banner down to the "END OF CAMPAIGN" banner.                 ##
# ##                                                                          ##
# ##   THE MAP                                                                ##
# ##     open_campaign_map()      the map: type a level number                ##
# ##     build_map()              what the map looks like                     ##
# ##     level_box()              one level box (green / gold / padlock)      ##
# ##                                                                          ##
# ##   PLAYING A LEVEL                                                        ##
# ##     start_campaign_level()   THE MAIN CODE: bonus stage? -> hide traps   ##
# ##                              -> the battle -> win / lose -> try again?   ##
# ##     maybe_bonus_stage()      the 20% / 30% dice roll for a bonus stage   ##
# ##                                                                          ##
# ##   AFTER THE BATTLE                                                       ##
# ##     finish_campaign_match()  YOU LOSE (1 = try again) or YOU WIN         ##
# ##     after_a_win()            victory, +100 coins, next level opens       ##
# ##     unlock_next_level()      the next level + maybe a NEW MINI GAME      ##
# ##     show_coins_screen()      "YOU EARNED 100 COINS"                      ##
# ##                                                                          ##
# ##############################################################################
# ##############################################################################
TILE_WIDTH = 24       # width of one level box on the map


def open_campaign_map():
    notice = ""                                         # a red message under the map ("" = none)
    while True:                                         # keep showing the map (until 0 = back)
        play_music('map')
        lines = build_map()
        if notice != "":                                # a message to show?
            lines.append(center_line(paint(notice, 203, bold=True), visible_length(lines[0])))
            notice = ""
        present(lines)
        typed = ask(paint("Level >", 230, bold=True))   # ask which level

        match typed:
            case '0':
                return                                  # back to the main menu
            case 'l':                                   # the secret x-ray cheat (cheats.py)
                cheats.switch_xray()
            case '1' | '2' | '3' | '4' | '5' | '6' | '7' | '8' | '9' | '10':   # a level number
                level = int(typed)                      # int("3") -> the number 3
                if level > game_memory['highest_unlocked_level']:   # not unlocked yet?
                    notice = "Level " + typed + " is still LOCKED!"
                else:
                    start_campaign_level(level)         # play it!
            case _:                                     # anything else
                notice = "Pick a level between 1 and 10!"


def build_map():
    # A bomb + "MAP" on top, then two rows of five level boxes
    title = new_picture(16 + 4 + art.text_width("MAP", 2) + 1, 16)   # room for a bomb + the word MAP
    draw_sprite(title, art.BOMB_16, 0, 0, art.BOMB_COLORS)           # the bomb at the left
    art.draw_text(title, "MAP", 20, 1, art.GOLD, 2, 94)              # the word MAP next to it

    top_row = art.side_by_side([level_box(1), level_box(2), level_box(3), level_box(4), level_box(5)], 2)
    bottom_row = art.side_by_side([level_box(6), level_box(7), level_box(8), level_box(9), level_box(10)], 2)
    width = visible_length(top_row[0])                  # how wide a row of boxes is
    cleared = len(game_memory['cleared_levels'])        # how many levels are beaten
    subtitle = paint("CAMPAIGN", 222, bold=True) + paint("   " + str(cleared) + "/10 CLEARED   ", 250)
    subtitle = subtitle + art.coin_text(game_memory['coins'])

    lines = art.center_block(picture_to_lines(title), width)
    lines.append("")
    lines.append(center_line(subtitle, width))          # "CAMPAIGN 2/10 CLEARED ($) 250 COINS"
    lines.append("")
    lines = lines + top_row                             # levels 1 to 5
    lines.append("")
    lines = lines + bottom_row                          # levels 6 to 10
    lines.append("")
    lines.append(center_line(paint("Type a level number (1-10) and press Enter   |   0 = back", 250), width))
    return lines


def level_box(level):
    # One box on the map, as text lines.
    # It looks different when it's cleared (green), open (gold) or locked (grey).
    picture = new_picture(TILE_WIDTH, 16)
    number_left = (TILE_WIDTH - art.text_width(str(level), 2)) // 2      # the number in the middle
    if level in game_memory['cleared_levels']:                 # beaten already
        border = 71
        status = paint("* CLEARED *", 120, bold=True)
        info_color = 252
        art.draw_text(picture, str(level), number_left, 1, art.MINT, 2, 22)
    elif level <= game_memory['highest_unlocked_level']:       # open
        border = 220
        status = paint(">> PLAY NOW <<", 220, bold=True)
        info_color = 252
        art.draw_text(picture, str(level), number_left, 1, art.GOLD, 2, 94)
    else:                                                      # locked
        border = 239
        status = paint("LOCKED", 242)
        info_color = 241
        draw_sprite(picture, art.LOCK_12, (TILE_WIDTH - 12) // 2, 1, art.LOCK_COLORS)   # a padlock

    info = paint(board_size_as_text(level) + " - " + str(how_many_bombs_for_this_level(level)) + " BOMBS", info_color)   # "6x5 - 4 BOMBS"

    # Put it all in a double-line box
    lines = [paint("╔" + "═" * TILE_WIDTH + "╗", border)]                 # the top edge
    for picture_line in picture_to_lines(picture):                         # the number / padlock
        lines.append(paint("║", border) + picture_line + paint("║", border))
    lines.append(paint("║", border) + center_line(info, TILE_WIDTH) + paint("║", border))
    lines.append(paint("║", border) + center_line(status, TILE_WIDTH) + paint("║", border))
    lines.append(paint("╚" + "═" * TILE_WIDTH + "╝", border))              # the bottom edge
    return lines


# ##############################################################################
# ##############################################################################
#
#   __  __    _    ___ _   _    ____    _    __  __ ____   _    ___ ____ _   _
#  |  \/  |  / \  |_ _| \ | |  / ___|  / \  |  \/  |  _ \ / \  |_ _/ ___| \ | |
#  | |\/| | / _ \  | ||  \| | | |     / _ \ | |\/| | |_) / _ \  | | |  _|  \| |
#  | |  | |/ ___ \ | || |\  | | |___ / ___ \| |  | |  __/ ___ \ | | |_| | |\  |
#  |_|  |_/_/   \_\___|_| \_|  \____/_/   \_\_|  |_|_| /_/   \_\___\____|_| \_|
#
#   >>>  THE MAIN CODE OF THE CAMPAIGN: ONE LEVEL, FROM START TO FINISH  <<<
#
#   1) maybe a BONUS STAGE first           (20% chance)
#   2) a new battle                        make_a_new_match          (battle.py)
#   3) you hide your traps                 let_the_player_hide_their_traps
#   4) the Bot hides its traps             let_the_bot_hide_its_traps
#   5) THE BATTLE                          play_the_whole_battle
#   6) YOU WIN / YOU LOSE                  finish_campaign_match     (below)
#   7) TRY AGAIN? then everything starts again from 1)
#
# ##############################################################################
# ##############################################################################
def start_campaign_level(level):
    while True:                                         # repeats on TRY AGAIN
        maybe_bonus_stage(BONUS_CHANCE_BEFORE_LEVEL)    # 20% chance of a bonus stage first
        state = make_a_new_match(level, False, "LEVEL " + str(level))   # a brand-new battle (False = not 1V1)
        if let_the_player_hide_their_traps(state, 1) == 'cancelled':  # you hide your traps (0 = cancel)
            return                                      # cancelled: back to the map
        let_the_bot_hide_its_traps(state)                           # the Bot hides its traps
        result = play_the_whole_battle(state)                # THE BATTLE (battle.py)
        try_again = finish_campaign_match(state, result)   # win / lose screens
        if try_again == False:                          # not TRY AGAIN?
            return                                      # back to the map


def maybe_bonus_stage(chance_percent):
    # Roll a dice from 1 to 100. If it lands on the chance or under: BONUS STAGE!
    # (a 20% chance = the numbers 1 to 20 out of 100)
    dice = random.randint(1, 100)
    if dice <= chance_percent:
        play_the_bonus_stage()


def finish_campaign_match(state, result):
    # After the battle. Gives back True if the player wants to TRY AGAIN.
    match result:
        case 'player_one_lost':
            play_jingle('defeat')                       # the sad song
            typed = show_the_whole_board_at_the_end(state, "YOU LOSE!", "THE BOT WINS THIS ROUND", TOP_BAR_COLORS_RED,
                                     "TRY AGAIN", "1 = try again   |   Enter = back to the map")
            if typed == '1':
                return True                             # try again
            else:
                return False
        case 'player_one_won':
            after_a_win(state)
            return False
        case _:                                         # 'quit': you typed 0 in the battle
            return False


def after_a_win(state):
    level = state['level']                              # which level was beaten
    show_the_whole_board_at_the_end(state, "YOU WIN!", "YOU WIN THE MATCH!", TOP_BAR_COLORS_YELLOW, "CONTINUE", "Press Enter")
    play_victory_animation("VICTORY ROYALE!")

    # Remember the level as cleared
    if level not in game_memory['cleared_levels']:
        game_memory['cleared_levels'].append(level)

    # Open the next level (only if this was your newest level, and there is no level 11)
    messages = []                                       # [text, colour] messages for the coins screen
    if level == game_memory['highest_unlocked_level'] and level < 10:
        messages = unlock_next_level(level + 1)

    add_coins(COINS_FOR_WINNING_A_LEVEL)                # +100 coins
    wants_mini_games = show_coins_screen(messages)      # "YOU EARNED 100 COINS"
    maybe_bonus_stage(BONUS_CHANCE_AFTER_WIN)           # 30% chance of a bonus stage
    if wants_mini_games == True:                        # picked [2] MINI GAMES?
        open_mini_games_menu()


def unlock_next_level(new_level):
    # Opens the next level. Gives back the messages for the coins screen.
    game_memory['highest_unlocked_level'] = new_level
    messages = [[">>> LEVEL " + str(new_level) + " UNLOCKED! <<<", 220]]

    # Does a mini game open at this level?
    mini_game_name = ""
    if new_level == RACING_PIECE_UNLOCK:
        mini_game_name = "RACING PIECE"
    elif new_level == TICK_TOCK_UNLOCK:
        mini_game_name = "TICK TOCK"
    elif new_level == FLIP_THE_KING_UNLOCK:
        mini_game_name = "FLIP THE KING"
    if mini_game_name != "":
        play_unlock_animation(mini_game_name)           # "NEW MINI GAME!"
        messages.append(["NEW MINI GAME UNLOCKED: " + mini_game_name + "!", 213])

    # Does the scan open at this level?
    if new_level == UNLOCK_LEVEL_FOR_SCAN:
        messages.append(["NEW RULE: the SACRIFICE SCAN is now unlocked (type 1 in battle)", 159])
    return messages


def show_coins_screen(messages):
    # "YOU EARNED 100 COINS" with CONTINUE and MINI GAMES buttons.
    # messages = [text, colour] pairs, e.g. "LEVEL 3 UNLOCKED!"
    # Gives back True if you picked [2] MINI GAMES.
    title = art.big_text("YOU WIN", art.GOLD, 2, 94)                            # big gold letters
    coin = art.sprite_lines(art.make_bigger(art.COIN_8, 2), art.COIN_COLORS)    # a coin, twice as big
    buttons = art.side_by_side([art.make_button("[1] CONTINUE", 22, 220),
                                art.make_button("[2] MINI GAMES", 22)], 4)
    width = art.widest_line(buttons) + 10

    lines = art.center_block(title, width)
    lines.append("")
    lines = lines + art.center_block(coin, width)
    lines.append("")
    lines.append(center_line(paint("YOU EARNED " + str(COINS_FOR_WINNING_A_LEVEL) + " COINS", 220, bold=True), width))
    lines.append(center_line(art.coin_text(game_memory['coins']) + paint(" in total", 250), width))
    lines.append("")
    for message in messages:                            # every message, in its colour
        lines.append(center_line(paint(message[0], message[1], bold=True), width))
    lines.append("")
    lines = lines + art.center_block(buttons, width)
    present(lines)
    typed = ask(paint("Choose 1 or 2:", 230, bold=True))
    if typed == '2':
        return True
    else:
        return False


# ##############################################################################
# ##   _____ _   _ ____     ___  _____    ____    _    __  __ ____   _    ___ ____ _   _
# ##  | ____| \ | |  _ \   / _ \|  ___|  / ___|  / \  |  \/  |  _ \ / \  |_ _/ ___| \ | |
# ##  |  _| |  \| | | | | | | | | |_    | |     / _ \ | |\/| | |_) / _ \  | | |  _|  \| |
# ##  | |___| |\  | |_| | | |_| |  _|   | |___ / ___ \| |  | |  __/ ___ \ | | |_| | |\  |
# ##  |_____|_| \_|____/   \___/|_|      \____/_/   \_\_|  |_|_| /_/   \_\___\____|_| \_|
# ##
# ##   (the campaign part ends here - below is PART 4: 1V1)
# ##############################################################################


# =====================================================================
#  PART 4: 1V1  -  TWO PLAYERS ON ONE COMPUTER
#   1) pick a board: SMALL, MEDIUM or LARGE
#   2) Player One hides traps while Player Two looks away
#   3) Player Two hides traps while Player One looks away
#   4) take turns flipping each other's pawns (the same battle as the campaign)
#   5) the winner gets the victory animation
# =====================================================================
def start_hotseat_pvp():
    # 1) pick a board
    level = choose_board_size()                    # the campaign level whose board we copy (0 = back)
    if level == 0:
        return                                     # typed 0: back to the menu
    if level == PVP_SMALL_LEVEL:
        name = "SMALL"
    elif level == PVP_MEDIUM_LEVEL:
        name = "MEDIUM"
    else:
        name = "LARGE"
    state = make_a_new_match(level, True, "1V1 " + name)  # a new battle (True = 1V1)

    # 2) and 3) each player hides traps while the other looks away
    show_the_look_away_screen("PLAYER ONE", "Player Two: look away while Player One hides traps!")
    if let_the_player_hide_their_traps(state, 1) == 'cancelled':
        return
    show_the_look_away_screen("PLAYER TWO", "Player One: look away while Player Two hides traps!")
    if let_the_player_hide_their_traps(state, 2) == 'cancelled':
        return

    # 4) the battle
    result = play_the_whole_battle(state)

    # 5) after the battle
    match result:
        case 'player_one_won':
            show_the_whole_board_at_the_end(state, "PLAYER 1 WINS!", "PLAYER ONE WINS!", TOP_BAR_COLORS_YELLOW, "CONTINUE", "Press Enter")
            play_victory_animation("PLAYER ONE WINS!")
        case 'player_one_lost':
            show_the_whole_board_at_the_end(state, "PLAYER 2 WINS!", "PLAYER TWO WINS!", TOP_BAR_COLORS_YELLOW, "CONTINUE", "Press Enter")
            play_victory_animation("PLAYER TWO WINS!")
        case _:                                    # 'quit': straight back to the menu
            return


def choose_board_size():
    # Gives back the level to copy (1, 4 or 9), or 0 if you typed 0 (back)
    lines = build_board_size_screen()              # build the screen once
    while True:                                    # ask until 0, 1, 2 or 3
        play_music('map')
        present(lines)
        typed = ask(paint("Board >", 230, bold=True))
        match typed:
            case '0':
                return 0
            case '1':
                return PVP_SMALL_LEVEL
            case '2':
                return PVP_MEDIUM_LEVEL
            case '3':
                return PVP_LARGE_LEVEL


def build_board_size_screen():
    # Title: a white pawn, "1V1", a black pawn
    title_width = 16 + 4 + art.text_width("1V1", 3) + 4 + 16     # pawn + gap + text + gap + pawn
    title = new_picture(title_width, 22)
    draw_sprite(title, art.PAWN_16, 0, 4, art.WHITE_PIECE)               # white pawn at the left
    art.draw_text(title, "1V1", 20, 0, art.GOLD, 3, 94)                  # "1V1" in the middle
    draw_sprite(title, art.PAWN_16, title_width - 16, 4, art.BLACK_PIECE)  # black pawn at the right

    # One preview for each size, side by side
    small = board_choice("1", "SMALL", PVP_SMALL_LEVEL)
    medium = board_choice("2", "MEDIUM", PVP_MEDIUM_LEVEL)
    large = board_choice("3", "LARGE", PVP_LARGE_LEVEL)
    row_of_choices = art.side_by_side([small, medium, large], 10)
    width = art.widest_line(row_of_choices)
    if width < 100:
        width = 100

    lines = art.center_block(picture_to_lines(title), width)
    lines.append("")
    lines.append(center_line(paint("Two players, one device. Pick a board size:", 250), width))
    lines.append("")
    lines = lines + art.center_block(row_of_choices, width)
    lines.append("")
    lines.append(center_line(paint("1, 2 or 3   |   0 = back", 250), width))
    return lines


def board_choice(key, name, level):
    # A tiny checkerboard so you can SEE how big each choice is,
    # with its name and size under it
    rows = how_many_rows_for_this_level(level)
    columns = how_many_columns_for_this_level(level)
    if rows > columns:                               # pixels per square: the bigger the board,
        cell = 40 // rows                            # the smaller each square
    else:
        cell = 40 // columns
    if cell < 2:
        cell = 2                                     # at least 2
    picture = new_picture(columns * cell, rows * cell)
    for row in range(rows):                          # every square:
        for column in range(columns):
            if row == rows // 2:
                color = art.RIVER_COLOR              # the middle row is the river
            elif (row + column) % 2 == 0:
                color = art.LIGHT_SQUARE             # light and dark squares take turns
            else:
                color = art.DARK_SQUARE
            fill_box(picture, column * cell, row * cell, cell, cell, color)
    block = picture_to_lines(picture)
    block.append("")
    block.append(paint("[" + key + "] " + name, 231, bold=True))     # "[2] MEDIUM"
    block.append(paint(board_size_as_text(level) + " - " + str(how_many_bombs_for_this_level(level)) + " bombs each", 250))
    return block
