# =====================================================================
#  FILE 2 of 11:  SETTINGS.PY  -  ALL THE NUMBERS OF THE GAME
#                                + WHAT THE GAME REMEMBERS WHILE IT RUNS
#
#  PART 1: THE SETTINGS
#   Every number the game uses: how many bombs, how big the boards are,
#   how many coins you win, when mini games unlock ...
#   Change a number here, save, and run the game again.
#
#  PART 2: THE MEMORY (game_memory)
#   Your coins, your levels and your best mini-game scores.
#   There is NO save file: everything is forgotten when you close the
#   game, and the next game starts fresh.
#
#  HOW TO READ IT
#   NAME = value        means "remember this value under this name".
#   # some words        is a comment: Python ignores it, it's for people.
#   [16, 12, 10]        a list: several values in order
#   {'coins': 50}       a dictionary: a value with a label ('coins')
# =====================================================================


# =====================================================================
#  PART 1: THE SETTINGS
# =====================================================================

# ---------------------------------------------------------------------
# SCREEN SIZE
# A terminal counts in CHARACTERS. Every screen in the game is built
# to fit inside 192 characters across and 54 lines down.
# ---------------------------------------------------------------------
SCREEN_COLUMNS = 192        # the screen is 192 characters wide ...
SCREEN_LINES = 54           # ... and 54 lines tall


# ---------------------------------------------------------------------
# THE RULES
# ---------------------------------------------------------------------
STARTING_HEALTH = 3         # 3 HP = Queen, King, Queen (the King is the last one)
EXTRA_LIVES_COUNT = 1       # how many extra lives each player hides
BOMBS_ON_LEVEL_1 = 4        # level 1 starts with 4 bombs
EXTRA_BOMBS_PER_LEVEL = 1   # +1 bomb every level: level 2 = 5 ... level 10 = 13
EXTRA_BOMBS_FOR_YOU = 1     # against the Bot you hide 1 more bomb than it (level 1: you 5, Bot 4)
UNLOCK_LEVEL_FOR_SCAN = 5       # the Sacrifice Scan only works from this level up


# ---------------------------------------------------------------------
# BOARD SIZE: it starts small and grows EVERY level
#   Level 1: 2 rows on each side of the river x 6 columns = 12 pawns each
#   Every level adds 1 column.
#   Every 2nd level also adds 1 row on each side.
#
#   level:        1   2   3   4   5   6   7   8   9  10
#   pawns each:  12  14  24  27  40  44  60  65  84  90
# ---------------------------------------------------------------------
LEVEL_1_ROWS_PER_SIDE = 2   # rows each player owns on level 1
LEVEL_1_COLUMNS = 6         # columns on level 1  (2 x 6 = 12 pawns each)
EXTRA_COLUMNS_PER_LEVEL = 1 # +1 column every level
LEVELS_PER_EXTRA_ROW = 2    # +1 row on each side every 2 levels


# ---------------------------------------------------------------------
# SQUARE SIZES (in pixels) the board can use, biggest first.
# Each level uses the biggest size that fits the 192 x 54 screen.
# ---------------------------------------------------------------------
SQUARE_SIZES = [16, 12, 10, 8, 6]


# ---------------------------------------------------------------------
# 1V1 BOARD SIZES: which campaign level each size copies
# ---------------------------------------------------------------------
PVP_SMALL_LEVEL = 1         # [1] SMALL  = the same board as level 1
PVP_MEDIUM_LEVEL = 4        # [2] MEDIUM = the same board as level 4
PVP_LARGE_LEVEL = 9         # [3] LARGE  = the same board as level 9


# ---------------------------------------------------------------------
# COINS
# ---------------------------------------------------------------------
COINS_FOR_WINNING_A_LEVEL = 100   # coins you get for winning a level
STARTING_COINS = 50               # coins a new player starts with


# ---------------------------------------------------------------------
# BONUS STAGE  (pops up at random)
# ---------------------------------------------------------------------
BONUS_CHANCE_BEFORE_LEVEL = 20    # % chance before a campaign level
BONUS_CHANCE_AFTER_WIN = 30       # % chance after you win a level


# ---------------------------------------------------------------------
# MINI GAMES: the campaign level you must reach to unlock each one
# ---------------------------------------------------------------------
RACING_PIECE_UNLOCK = 5       # Racing Piece opens at level 5
TICK_TOCK_UNLOCK = 7          # Tick Tock opens at level 7
FLIP_THE_KING_UNLOCK = 9      # Flip the King opens at level 9


# =====================================================================
#  PART 2: THE MEMORY
#  game_memory is ONE dictionary with labelled boxes:
#      game_memory['coins']          -> how many coins you have
#      game_memory['coins'] = 200    -> now you have 200
#  Every file that imports game_memory looks at this SAME dictionary.
# =====================================================================
game_memory = {
    'highest_unlocked_level': 1,    # the furthest level you may play
    'cleared_levels': [],           # every level you have beaten (empty = none yet)
    'cheat_active': False,          # the 'l' x-ray cheat (False = off)
    'level_before_cheat': 0,        # your real level before the 'p' cheat (0 = the cheat is off)
    'coins': STARTING_COINS,        # you start with 50 coins
    'best_racing_piece': 0,         # best score in Racing Piece (biggest win)
    'best_tick_tock': 0,            # best score in Tick Tock (seconds left)
    'best_flip_the_king': 0,        # best score in Flip the King (flips)
    'best_bonus_stage': 0,          # best score in the Bonus Stage (coins)
}


def add_coins(amount):
    # Gives coins (or takes them away when amount is negative).
    # You never go below 0 coins.
    new_total = game_memory['coins'] + amount   # the coins you have + the amount
    if new_total < 0:                           # below zero?
        new_total = 0                           # then just 0
    game_memory['coins'] = new_total            # store the new total


def record_best(box_name, score):
    # box_name = one of the 'best_...' boxes above, e.g. 'best_tick_tock'
    # Gives back True if this score beats the old best one.
    old_best = game_memory[box_name]            # the best score so far
    if score > old_best:                        # is the new score bigger?
        game_memory[box_name] = score           # store it as the new best
        return True                             # yes, a new best!
    else:
        return False                            # no, not better


def forget_everything():
    # Secret code 69: start over like a new player.
    # Every box goes back to how it was at the start.
    game_memory['highest_unlocked_level'] = 1
    game_memory['cleared_levels'] = []
    game_memory['cheat_active'] = False
    game_memory['level_before_cheat'] = 0
    game_memory['coins'] = STARTING_COINS
    game_memory['best_racing_piece'] = 0
    game_memory['best_tick_tock'] = 0
    game_memory['best_flip_the_king'] = 0
    game_memory['best_bonus_stage'] = 0